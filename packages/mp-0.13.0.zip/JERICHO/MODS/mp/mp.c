/*
 * mp.c -- JERICHO Multiplayer: module entry, config and player registry.
 *
 * A compiled-in deep mod (no `runtime` in mod.toml) so it can read/write the
 * game's globals (GameLevel, wantedTimeOfDay, Pads[], car_data[], player[]).
 *
 * Responsibilities here:
 *   - module registration + lifecycle hooks (BOOT / SHUTDOWN)
 *   - persistent settings (JERICHO/CONFIG/mp.ini): port, player name,
 *     host name, beacon interval, lobby mod-check mode
 *   - the network-player registry: which CAR_DATA slot each participant
 *     drives, so we can tell our players apart from genuine NPC traffic
 *
 * Transport lives in mp_net.c, the frontend overlay in mp_ui.c and the
 * session sync in mp_session.c.
 */
#include "jericho.h"
#include "jer_events.h"
#include "jer_config.h"
#include "jer_frontend.h"
#include "jer_pause_menu.h"
#include "jer_colour.h"		/* a player's suit colour is a canonical JER_COLOUR */
#include "jer_ped_palette.h"	/* a player's own Tanner in their own colour */
#include "jer_npc.h"		/* JerNpc: the stand-in we drew for a remote player */

/* The chat key needs PsyX's debug-key hook, but NOT its header: PsyX_public.h and
 * SDL_scancode.h both pull in math/SDL defines that collide with the game's in
 * this TU (a C4005 'M_PI': macro redefinition). So the one symbol is declared
 * here -- matching GameDebugKeysHandlerFunc, and C-linkage because PsyX_public.h
 * wraps the declaration in extern "C" -- and the two scancodes are named
 * constants (SDL2 USB-HID indices, fixed). */
typedef void (*MpDebugKeysFn)(int nKey, char down);
typedef void (*MpTextInputFn)(const char* buf);

#ifdef __cplusplus
extern "C" {
#endif
extern MpDebugKeysFn g_dbg_gameDebugKeys;
extern MpTextInputFn g_cfg_gameOnTextInput;
#ifdef __cplusplus
}
#endif

#define MP_KEY_CHAT_OPEN	23	/* SDL_SCANCODE_T */
#define MP_KEY_CHAT_SEND	40	/* SDL_SCANCODE_RETURN */
#define MP_KEY_CHAT_SEND_KP	88	/* SDL_SCANCODE_KP_ENTER */
#define MP_KEY_CHAT_CANCEL	41	/* SDL_SCANCODE_ESCAPE */
#define MP_KEY_CHAT_PGUP	75	/* SDL_SCANCODE_PAGEUP: older chat (prompt open only) */
#define MP_KEY_CHAT_PGDN	78	/* SDL_SCANCODE_PAGEDOWN: newer chat */
#define MP_CHAT_PAGE_ROWS	(JER_CONSOLE_MAX - 1)	/* one row of overlap per page */

/* Either Enter sends the chat line.
 *
 * The keypad Enter is a SEPARATE scancode (88) and it reaches this hook like any
 * other key -- PsyX only special-cases the main RETURN, never KP_ENTER. Some
 * remotes and X11 servers deliver KP_ENTER for a key the user thinks of as
 * "Enter", so matching only scancode 40 made "Enter does not send" depend on
 * which Enter the client happened to send. Accept both; the CANCEL key (Esc) has
 * no such twin to worry about. */
static int MpIsChatSendKey(int nKey)
{
	return nKey == MP_KEY_CHAT_SEND || nKey == MP_KEY_CHAT_SEND_KP;
}

#include "driver2.h"
#include "system.h"		/* CITY_COUNT: the city registry MPCC_MAX_CITIES tracks */
#include "main.h"
#include "pause.h"	/* gJerPauseRestartAsRespawn: relabel the main menu's Restart in a session */
#include "mission.h"
#include "pad.h"
#include "players.h"
#include "cars.h"
#include "camera.h"
#include "glaunch.h"
#include "state.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "mp.h"
#include "jer_console.h"	/* jer_console_scroll: PgUp/PgDn through the chat history */
#include "mp_bot.h"	/* the test bot; testing only, inert unless MP_BOT is set */

MP_STATE gMp;
JERICHO_CONTEXT* gMpCtx;

/* The engine's map-shape boot flags (main.c, set by -mp). The host's own
 * Single Player / Multiplayer answer writes them through MpSetMapShape, and the
 * session publishes them to clients, so they are read/written here too. */
extern int gBootMpLevel;	/* 1 = a multiplayer map, 0 = the full city */
extern int gBootMpArena;	/* which multiplayer map (0/1) */

/* Is MP_DEBUG set? Resolved ONCE and cached. The module asks this from the
 * per-frame, per-poll and per-message paths (and a getenv there is a libc call
 * per ask), while the environment cannot change once the game is running. This
 * is the ONLY place that reads it -- grep for one site. */
int MpDebugOn(void)
{
	static int resolved = 0;
	static int on = 0;

	if (!resolved)
	{
		const char* dbg = getenv("MP_DEBUG");

		on = (dbg != NULL);
		resolved = 1;
	}

	return on;
}

/* Boolean test levers that the per-frame paths read (the map census in MpOnFrame,
 * the pause census in the overlay). Resolved once, for the same reason: an
 * environment value cannot change while the game runs, and these are tested every
 * frame. `cache` is a module-owned int initialised to -1. */
static int MpLeverFlag(const char* name, int* cache)
{
	if (*cache < 0)
		*cache = (getenv(name) != NULL);

	return *cache;
}

static int gTestMapOn = -1;
static int gTestPauseOn = -1;
static int gTestPanelOn = -1;

/* Set when a lost connection must land the player on the main menu; the
 * engine decides where its own exit goes, so we jump on the next frontend
 * frame instead of trusting it. */
static int gReturnToMenu;

/* mp's own in-game player list. A network session must NOT open the engine
 * pause: that freezes the whole simulation on THIS machine while everyone else
 * keeps driving, so the two states disagree the moment play resumes. The START
 * press opens this instead -- a non-freezing overlay. */
static int gMpShowPlayers;
static int gMpPauseOpened;	/* the player opened the engine PAUSE (not another menu) */

/* Leave the whole match: back to the main frontend with a notice. Used when
 * the host ends the game or the server connection is lost. */
void MpReturnToFrontend(void)
{
	/* The single choke point for "the session is over, go back to the frontend":
	 * log it here as well as at the callers, so any future path that returns to
	 * the frontend is visible in the log without having to remember to add one. */
	MpConnEvent("returning to the frontend", -1, "the session is over");

	MpSessionReset();
	MpResetPlayers();

	/* The session is over (a lost connection, a refusal, the host leaving):
	 * forget it completely, so nothing can launch into it again. Without this
	 * the player was left sitting in a menu whose START then began the DEFAULT
	 * city with no host -- the "dropped into Chicago with a vehicle" report. */
	MpClientDisconnect();
	gMp.role = MP_ROLE_NONE;
	gMp.connected = 0;
	gMp.running = 0;
	gMpShowPlayers = 0;	/* the overlay only belongs to a live match */
	gMpPauseOpened = 0;

	/* the ENGINE's own way out of a gameplay session: it tears down the level,
	 * stops the music/sfx and returns to the frontend (the same path the pause
	 * menu's Exit takes). Do NOT just SetState -- that leaves sounds playing.
	 * The engine lands where it likes (often the middle of the stock chain that
	 * launched the level), so ask for the main menu explicitly. */
	if (!gInFrontend)
	{
		gReturnToMenu = 1;
		EndGame(GAMEMODE_QUIT);
	}
	else
	{
		jer_frontend_goto(0);	/* already in a menu: back to the main one */
	}
}
void MpCameraPose(int* x, int* y, int* z, int* yaw)
{
	if (x != NULL) *x = camera_position.vx;
	if (y != NULL) *y = camera_position.vy;
	if (z != NULL) *z = camera_position.vz;
	if (yaw != NULL) *yaw = camera_angle.vy;
}

/* Engine globals the frontend flow needs, kept here so the UI file does not
 * have to pull in the engine's type preamble. */
int MpGetGameLevel(void)
{
	return GameLevel;
}

void MpSetSubGame(int n)
{
	gSubGameNumber = n;
}

/* The stock city screen was confirmed. Ask Singleplayer or Multiplayer BEFORE the
 * stock flow continues to time-of-day/car select -- for the LAN setup AND for a
 * plain singleplayer take-a-ride alike, since the answer also picks the MAP
 * (full city vs the city's multiplayer arena).
 *
 * TWO ways in, so this must be a DISJUNCTION. The GameType alone cannot carry it:
 * measured on the real host flow (Multiplayer -> LAN -> Host Game -> the city
 * screen), the confirm arrives with `gameType == GAME_MISSION` (0) -- the very
 * value the mission/cutscene screen carries. Gating on `gameType ==
 * GAME_TAKEADRIVE` alone therefore silently dropped the LAN path into single
 * player, and the guard stayed green because `MP_TEST_CITYCONFIRM` hardcodes
 * GAME_TAKEADRIVE. A session being set up is the reliable LAN signal
 * (MpBeginHost leaves `gMp.role != MP_ROLE_NONE`); a plain take-a-ride still
 * arrives as GAME_TAKEADRIVE. The mission path has neither -- no role, not
 * take-a-ride -- so it stays left alone.
 *
 * `defer` stops the stock continuation and we open our mode menu instead. */
static int MpOnFrontendConfirm(void* userdata, void* args)
{
	JER_ARGS_FRONTEND* fe = (JER_ARGS_FRONTEND*)args;

	(void)userdata;

	if ((gMp.role != MP_ROLE_NONE || fe->gameType == GAME_TAKEADRIVE) &&
	    !gMp.running && fe->defer == 0)
	{
		fe->defer = 1;

		/* NOT MpUiOpenModeMenu() from in here: an open issued from inside this hook
		 * does not survive the engine finishing the screen switch, so the prompt
		 * silently never appeared. Arm it; the next frame opens it (see
		 * gModeMenuArmed in mp_ui.c). */
		MpUiArmModeMenu();

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] city confirmed - asking Single Player / Multiplayer\n");
	}
	else if (gMpCtx != NULL)
	{
		/* Why the prompt did NOT open. Before this the only evidence was the
		 * ABSENCE of the line above -- which is the same evidence as "this hook
		 * never fired at all", and those are different bugs: a screen the hook
		 * does not serve (no session and not take-a-ride), versus a hook that is
		 * not registered. `role` is in here because it is half of the gate, and
		 * `gameType` ALONE is what made the LAN path look like a mission. */
		gMpCtx->jer_log(gMpCtx, "[mp] city confirmed - NOT asking (gameType=%d role=%d running=%d defer=%d)\n",
			fe->gameType, (int)gMp.role, (int)gMp.running, (int)fe->defer);
	}

	return JER_RESULT_CONTINUE;
}

/* A client join is live only once the host has welcomed us: without that a
 * frontend START must NOT launch a level (there would be no host to play
 * with, and it used to start the default city instead). */
static int MpClientSessionLive(void)
{
	return gMp.role == MP_ROLE_CLIENT && gMp.connected &&
		gMp.localPlayerId >= 0 && MpJoinState() == MP_JOIN_READY;
}

/* The frontend's START GAME press. When we are hosting a LAN session we take
 * it over: the stock city/map/time/car screens the host just walked through
 * have filled in the level globals, so adopt those and start the match
 * (broadcast + local launch) instead of the single-player state change. */
static int MpOnMpFrontend(void* userdata, void* args)
{
	JER_ARGS_MP_FRONTEND* fe = (JER_ARGS_MP_FRONTEND*)args;

	(void)userdata;

	if (fe->action != JER_MP_FE_START)
		return JER_RESULT_CONTINUE;

	if (gMp.role == MP_ROLE_HOST)
	{
		/* the host starts the match once; a later press has nothing to do */
		if (!gMp.running)
		{
			gMp.city = GameLevel;

			if (wantedTimeOfDay >= 0)
				gMp.timeOfDay = wantedTimeOfDay;
			if (wantedWeather >= 0)
				gMp.weather = wantedWeather;

			/* The stock per-city multiplayer level list picks the ARENA into
			 * gSubGameNumber (its buttons are SetVariable code 8, and only
			 * "Multiplayer" reaches that list). Take the arena from there so the
			 * session loads the map the player actually chose; the Single Player
			 * answer already set the shape to the full city (MpSetMapShape(0,0)),
			 * for which this is a no-op. */
			if (gBootMpLevel)
				gBootMpArena = gSubGameNumber & 1;

			MpStartMatch();
		}

		fe->claimed = 1;
		return JER_RESULT_CONTINUE;
	}

	if (gMp.role == MP_ROLE_CLIENT)
	{
		/* This must NOT be gated on !gMp.running.
		 *
		 * Joining a game that is already in progress sets running the moment the
		 * WELCOME lands -- that is what "a live game" means -- so a gate on
		 * !running refused the press, the stock start-game path ran instead, and
		 * GameType was still 0. 0 is GAME_MISSION, and glaunch.c's
		 * `case GAME_MISSION: RunMissionLadder(1)` is the mission ladder: the
		 * client launched Undercover mission 1 instead of joining the session.
		 * The session state that matters here is the JOIN state, not running. */
		if (MpClientSessionLive())
		{
			MpClientLaunch();
		}
		else
		{
			jer_error("Not connected to a server");

			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] START ignored: no live session\n");
		}

		fe->claimed = 1;
		return JER_RESULT_CONTINUE;
	}

	return JER_RESULT_CONTINUE;
}




/* ------------------------------------------------------------------ */
/* Queries                                                             */
/* ------------------------------------------------------------------ */






/* ------------------------------------------------------------------ */
/* Lifecycle hooks                                                     */
/* ------------------------------------------------------------------ */

static int gAutoHostStart;	/* MP_AUTOSTART=host: auto-launch when N players are in */
static int gAutoHostFrames;
static int gAutoHostTarget = 2;	/* players (incl. us) to wait for before starting */
static int gAutoHostSettle;	/* frames the target has been met for */
static int gHostInWorld;	/* the host actually reached the running level */

extern int gBootSuppressLevel;	/* main.c: a module takes the level launch over */
extern void MpNoteLocalPad(int pad);	/* mp_session.c: the pad driving our own car */

/* The host quit the match? Only once it has really BEEN in the world: at the
 * start of a match `running` is set a frame or two before gInFrontend clears,
 * and keying on `running && gInFrontend` alone would tear the fresh session
 * down during that transition. */
static int MpHostLeftMatch(void)
{
	if (gMp.role != MP_ROLE_HOST || !gMp.running)
	{
		gHostInWorld = 0;	/* not hosting a live match */
		return 0;
	}

	if (!gInFrontend)
	{
		gHostInWorld = 1;	/* we are in the level */
		return 0;
	}

	return gHostInWorld;		/* in the frontend AGAIN -> it left */
}

/* -host [port] / -join <ip>[:port] command-line shortcuts (JER_EVENT_CMDLINE),
 * the argv equivalent of MP_AUTOSTART. Handy for launching two instances on
 * one machine during development. */
static int MpOnCmdLine(void* userdata, void* args)
{
	JER_ARGS_CMDLINE* cl = (JER_ARGS_CMDLINE*)args;
	int i;

	(void)userdata;

	if (cl == NULL || cl->argc <= 1)
		return JER_RESULT_CONTINUE;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] cmdline: %d arg(s)\n", cl->argc);

	/* Log the whole line, not just the count: a wrong argument is invisible
	 * otherwise, and the game's own -help text (which prints on -help/-h/--help/-?)
	 * is the fastest way to see the flags it knows. */
	if (gMpCtx != NULL)
	{
		char line[256];
		int k, used = 0;

		line[0] = 0;

		for (k = 0; k < cl->argc && used < (int)sizeof(line) - 4; k++)
		{
			int wrote = snprintf(line + used, sizeof(line) - (size_t)used, "%s%s",
				k > 0 ? " " : "", cl->argv[k] != NULL ? cl->argv[k] : "(null)");

			if (wrote <= 0)
				break;

			used += wrote;
		}

		gMpCtx->jer_log(gMpCtx, "[mp] cmdline: %s\n", line);
	}


	for (i = 1; i < cl->argc; i++)
	{
		if (!strcmp(cl->argv[i], "-host"))
		{
			if (i + 1 < cl->argc && cl->argv[i + 1][0] != '-')
				gMp.config.port = atoi(cl->argv[++i]);

			if (gMp.config.port < 1024 || gMp.config.port > 65535)
				gMp.config.port = MP_DEFAULT_PORT;

			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] -host on port %d\n", gMp.config.port);

			/* -host means: bring a match up by itself, no frontend walking. The car
			 * comes from -mpcar; the CITY is adopted later, at match start. -level
			 * only stores gBootLevel (a static in main.c) and GameLevel is assigned
			 * after the argument loop -- so reading GameLevel here still sees the
			 * default and the host launched Chicago while -level said havana. */
			gMp.autoSession = 1;
			gAutoHostStart = 1;
			gAutoHostTarget = 2;

			/* Take the level launch over: the session loads the level when the
			 * match starts, so the engine's own -level entry must not fire. Booting
			 * one here and another at the start is what made a match "restart with
			 * different weather" the moment a client joined -- and let the
			 * frontend's city win over the session's. */
			gBootSuppressLevel = 1;

			MpBeginHost();
			if (gMp.timeOfDay < 0 && wantedTimeOfDay >= 0)
				gMp.timeOfDay = wantedTimeOfDay;
			if (gMp.weather < 0 && wantedWeather >= 0)
				gMp.weather = wantedWeather;
		}
		else if (!strcmp(cl->argv[i], "-mpcar"))
		{
			/* Our own vehicle for the match. The engine's -car cannot be used
			 * here: it is a dependent option that requires -level, and -level
			 * boots straight into a city -- which must never be given to a
			 * joining client. */
			if (i + 1 < cl->argc && cl->argv[i + 1][0] != '-')
			{
				const char* v = cl->argv[++i];
				const char* sel = v;
				int city = -1;

				/* Optional CITY prefix: `-mpcar 1:9` is HAVANA's model 9 (a
				 * cross-city car -- the point of the prefix, since the same number
				 * is a different vehicle in another city). Without it the pick is
				 * the session's own city. */
				{
					const char* q = v;

					while (*q >= '0' && *q <= '9')
						q++;

					if (*q == ':' && q > v)
					{
						city = atoi(v);

						if (city < 0 || city >= CITY_COUNT)
							city = -1;

						sel = q + 1;
					}
				}

				/* Accept either a raw model number or "slotN" (1..10), the
				 * frontend's own per-city slot. A slot is resolved against the
				 * session's city at launch (see MpLaunchLocal), because GameLevel is
				 * still the default here -- reading carNumLookup now would use the
				 * wrong city, the same trap the -host comment above records. */
				if (strncmp(sel, "slot", 4) == 0)
				{
					gMp.config.car = atoi(sel + 4);
					gMp.config.carIsSlot = 1;
					city = -1;	/* a slot is always the session's city */
				}
				else
				{
					gMp.config.car = atoi(sel);
					gMp.config.carIsSlot = 0;
				}

				gMp.config.carCity = city;

				/* Make the choice durable. Without this the slot-ness is never
				 * written, so on the next launch `car` would be read back as a
				 * MODEL number (see MpConfigLoad). */
				MpConfigSave();

				if (gMpCtx != NULL)
					gMpCtx->jer_log(gMpCtx, "[mp] -mpcar %s (car=%d slot=%d city=%d)\n",
						v, gMp.config.car, gMp.config.carIsSlot, gMp.config.carCity);
			}
		}
		else if (!strcmp(cl->argv[i], "-join"))
		{
			char ip[64];
			int port = gMp.config.port;

			snprintf(ip, sizeof(ip), "127.0.0.1");

			if (i + 1 < cl->argc && cl->argv[i + 1][0] != '-')
			{
				const char* s = cl->argv[++i];
				const char* colon = NULL;
				const char* q;

				/* find the LAST ':' by hand rather than with strrchr: the
				 * game's PSX string shim declares strrchr with a C++ signature,
				 * so calling it from here emits an external the CRT cannot
				 * satisfy (LNK2001 on ?strrchr@@...) */
				for (q = s; *q != '\0'; q++)
				{
					if (*q == ':')
						colon = q;
				}

				if (colon != NULL)
				{
					size_t n = (size_t)(colon - s);

					if (n > 0 && n < sizeof(ip))
					{
						memcpy(ip, s, n);
						ip[n] = '\0';
					}

					port = atoi(colon + 1);
				}
				else
				{
					snprintf(ip, sizeof(ip), "%s", s);
				}
			}

			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] -join %s:%d\n", ip, port);

			/* MP_TEST_FRONTEND_JOIN keeps the MENUS: without it a join is the
			 * unattended path ("no menus: launch as soon as we are in"), a client
			 * never reaches the vehicle select, and "does a client reach the car
			 * screen and its roster?" is unanswerable headlessly. With it the
			 * client takes the route a human takes: WELCOME -> MpUiOpenCarSelect
			 * (screen 14) -> the menu -> Ride, which hands the launch back through
			 * JER_EVENT_MP_FRONTEND. See MpTestFrontendJoin. */
			{
				const char* feJoin = MpTestFrontendJoin();
				int menuJoin = (feJoin != NULL && feJoin[0] != '\0' && feJoin[0] != '0');

				if (!menuJoin)
					gMp.autoSession = 1;	/* no menus: launch as soon as we are in */
				else if (gMpCtx != NULL)
					gMpCtx->jer_log(gMpCtx,
						"[mp] -join %s:%d WITH the menus (MP_TEST_FRONTEND_JOIN): the car screen will be offered\n",
						ip, port);
			}

			MpBeginJoinAsync(ip, port);
		}
	}

	return JER_RESULT_CONTINUE;
}

/* Headless dev affordance: MP_AUTOSTART=host[:PORT] | join[:IP[:PORT]]
 * brings a session up at boot so the transport can be exercised without
 * the frontend menus (mirrors the cainescrossfire scripted debug driver). */
static void MpAutostartFromEnv(void)
{
	const char* a = getenv("MP_AUTOSTART");

	if (a == NULL || a[0] == '\0')
		return;

	if (strncmp(a, "host", 4) == 0)
	{
		if (a[4] == ':')
			gMp.config.port = atoi(a + 5);

		if (gMp.config.port < 1024 || gMp.config.port > 65535)
			gMp.config.port = MP_DEFAULT_PORT;

		gMpCtx->jer_log(gMpCtx, "[mp] autostart host on port %d\n", gMp.config.port);
		MpBeginHost();

		if (getenv("MP_AUTOJOIN_START") != NULL)
		{
			const char* t = getenv("MP_AUTOJOIN_START");

			gAutoHostStart = 1;
			gAutoHostTarget = (t != NULL && t[0] != '\0') ? atoi(t) : 2;
			if (gAutoHostTarget < 2)
				gAutoHostTarget = 2;
		}
	}
	else if (strncmp(a, "join", 4) == 0)
	{
		char ip[64];
		int port = gMp.config.port;

		snprintf(ip, sizeof(ip), "%s", "127.0.0.1");

		if (a[4] == ':')
		{
			const char* s = a + 5;
			const char* colon = strchr(s, ':');

			if (colon != NULL)
			{
				int iplen = (int)(colon - s);

				if (iplen > 0 && iplen < (int)sizeof(ip))
				{
					memcpy(ip, s, (size_t)iplen);
					ip[iplen] = '\0';
				}

				port = atoi(colon + 1);
			}
			else if (s[0] != '\0')
			{
				snprintf(ip, sizeof(ip), "%s", s);
			}
		}

		gMpCtx->jer_log(gMpCtx, "[mp] autostart join %s:%d\n", ip, port);
		MpBeginJoinAsync(ip, port);
	}
}

/* ------------------------------------------------------------------ */
/* Chat: opening the prompt from the keyboard                         */
/* ------------------------------------------------------------------ */
/* The pad is busy driving, so chat opens on a KEYBOARD key. PsyX hands a module
 * a raw scancode through g_dbg_gameDebugKeys -- the only such hook -- and it is a
 * single slot, so we CHAIN whatever was there rather than clobber it; a module
 * that installed its own handler keeps working.
 *
 * `T` is chosen because the default PsyX keyboard map does not bind it to a pad
 * button (X/V/Z/C, LSHIFT, the arrows, SPACE and RETURN are all taken), so
 * opening chat does not also steer the car. ESCAPE closes the prompt again.
 *
 * RETURN is the SEND (MP_KEY_CHAT_SEND below), and that only works because PsyX
 * now delivers it: it used to consume RETURN in its event loop for the Alt+Enter
 * fullscreen gesture -- out of the switch, before DoDebugKeys -- so no module
 * ever saw the key. Fixed engine-side (Njurse/PsyCross d94b2d1, bumped by the
 * superproject): RETURN is consumed for that gesture only. Do not "simplify"
 * this handler on the assumption that the key arrives, and do not re-bind SEND
 * to something the pad owns. */
static MpDebugKeysFn gMpPrevDebugKeys = NULL;
static MpTextInputFn gMpPrevTextInput = NULL;

static void MpOnTextInput(const char* text);	/* our handler; defined below */

/* Take/release PsyX's single text-input slot, CHAINING whoever had it. Idempotent
 * on purpose: the frame hook re-asserts it every frame, so any path that forgot
 * to release self-heals instead of leaving the keyboard grabbed. */
static void MpChatGrabKeyboard(int on)
{
	if (on)
	{
		if (g_cfg_gameOnTextInput != MpOnTextInput)
		{
			gMpPrevTextInput = g_cfg_gameOnTextInput;
			g_cfg_gameOnTextInput = MpOnTextInput;
		}
	}
	else if (g_cfg_gameOnTextInput == MpOnTextInput)
	{
		g_cfg_gameOnTextInput = gMpPrevTextInput;
		gMpPrevTextInput = NULL;
	}
}

/* PsyX hands every typed character here while the prompt is up. NULL is the
 * BACKSPACE key (PsyX's convention for it -- there is no character). Everything
 * else appends, up to the buffer, terminator included. */
static void MpOnTextInput(const char* text)
{
	/* The manual address field first: it lives in the FRONTEND, where chat never
	 * runs, and it is the only other claimant of this slot. */
	if (MpUiManualEditing())
	{
		/* Enter can arrive here as text on some backends: treat it as done. */
		if (text != NULL && (text[0] == '\r' || text[0] == '\n'))
			MpUiManualCommit();
		else
			MpUiManualType(text);

		return;
	}

	if (!gMp.chatOpen)
	{
		/* not ours: pass it on untouched. Drop any swallow left over, so the next
		 * prompt cannot eat a real keystroke. */
		gMp.chatSwallowText = 0;

		if (gMpPrevTextInput != NULL)
			gMpPrevTextInput(text);
		return;
	}

	/* The key that OPENED the prompt is delivered as TEXT as well on this pump: a
	 * keydown and its text event are separate SDL events, in that order, so the
	 * line used to begin with the character that opened it (every message started
	 * with "t"). Drop exactly that one event -- not a keystroke meant for the line. */
	if (gMp.chatSwallowText)
	{
		gMp.chatSwallowText = 0;
		return;
	}

	if (text == NULL)		/* backspace: drop the last character */
	{
		size_t n = strlen(gMp.chatBuf);

		if (n > 0)
			gMp.chatBuf[n - 1] = '\0';
		return;
	}

	/* Enter may arrive here as text on some backends; treat it as SEND. */
	if (text[0] == '\r' || text[0] == '\n')
	{
		MpChatSendText(gMp.chatBuf);
		MpChatGrabKeyboard(0);
		return;
	}

	{
		size_t have = strlen(gMp.chatBuf);
		size_t room = sizeof(gMp.chatBuf) - 1 - have;
		size_t i;

		for (i = 0; text[i] != '\0' && i < room; i++)
			gMp.chatBuf[have + i] = text[i];

		gMp.chatBuf[have + i] = '\0';
	}
}

static void MpOnDebugKey(int nKey, char down)
{
	/* Chain to whoever held this hook BEFORE us -- the engine's own key handlers and
	 * any earlier module -- EXCEPT while the chat prompt is up. The keyboard then
	 * belongs to the line being typed, and every letter in it is also a key the
	 * engine would act on: "wasd" drives the free camera, "`" opens the console,
	 * 1/2/3/0 hit the game debug keys. Our own prompt keys (Enter/Escape) are
	 * consumed below and must not be passed on either. */
	if (!gMp.chatOpen && gMpPrevDebugKeys != NULL)
		gMpPrevDebugKeys(nKey, down);

	if (!down)
		return;

	if (nKey == MP_KEY_CHAT_CANCEL && MpRejoinActive())
		MpRejoinCancel("Esc");

	/* The manual address field is in the FRONTEND, so this sits BEFORE the in-game
	 * gate below: while it is editing it owns Enter and Escape. */
	if (MpUiManualEditing())
	{
		if (MpIsChatSendKey(nKey))
			MpUiManualCommit();
		else if (nKey == MP_KEY_CHAT_CANCEL)
			MpUiManualCancel();

		return;
	}

	/* In a live match only: while the frontend is up the engine's own text fields
	 * (and every other module) want the keyboard. */
	if (!MpIsActive() || !gMp.running)
		return;

	if (nKey == MP_KEY_CHAT_OPEN && !gMp.chatOpen)
	{
		MpChatOpen();
		MpChatGrabKeyboard(1);	/* the prompt owns the keyboard while it is up */
		jer_input_block(1);	/* from this frame: the chat key itself must not leak */
	}
	else if (MpIsChatSendKey(nKey) && gMp.chatOpen)
	{
		/* Enter sends: the owner echoes the line and the host fans it out. */
		MpChatSendText(gMp.chatBuf);
		MpChatGrabKeyboard(0);
	}
	else if (nKey == MP_KEY_CHAT_PGUP && gMp.chatOpen)
	{
		/* Only while typing: the prompt already owns the keyboard then (nothing is
		 * chained), so PgUp/PgDn cannot collide with an engine or module key. */
		jer_console_scroll(MP_CHAT_PAGE_ROWS);
	}
	else if (nKey == MP_KEY_CHAT_PGDN && gMp.chatOpen)
	{
		jer_console_scroll(-MP_CHAT_PAGE_ROWS);
	}
	else if (nKey == MP_KEY_CHAT_CANCEL && gMp.chatOpen)
	{
		gMp.chatOpen = 0;
		gMp.chatBuf[0] = '\0';
		MpChatGrabKeyboard(0);
	}
}

static int MpOnBoot(void* userdata, void* args)
{
	(void)userdata;
	(void)args;

	/* Chat needs the keyboard while the pad drives: take PsyX's one debug-key slot,
	 * CHAINING any existing handler so nothing else is starved. Guarded against a
	 * second boot (a reload): re-installing would chain MpOnDebugKey onto itself
	 * and recurse forever -- the console and the free camera share this slot now. */
	if (g_dbg_gameDebugKeys != MpOnDebugKey)
	{
		gMpPrevDebugKeys = g_dbg_gameDebugKeys;
		g_dbg_gameDebugKeys = MpOnDebugKey;
	}

	MpNetStart();

	gMpCtx->jer_log(gMpCtx, "[mp] multiplayer ready (port %d, name '%s', firstRun=%d, build %04x, mods %04x)\n",
		gMp.config.port, gMp.config.playerName, !gMp.config.firstNameSet,
		MpBuildHash(), MpModHash());

	MpAutostartFromEnv();

	return JER_RESULT_CONTINUE;
}

static int MpOnShutdown(void* userdata, void* args)
{
	(void)userdata;
	(void)args;

	MpLeaveSession();
	MpNetShutdown();

	return JER_RESULT_CONTINUE;
}

/* Service the sockets every frame (frontend and in-game both fire FRAME),
 * and again at the top of the world step for the lockstep hand-off. */
static void MpLogPlayerList(void);

/* The Player options' handlers (defined with their menu page below); the
 * MP_TEST_OPTIONS lever in the frame hook calls these same functions. */
static int MpOptToggleInvincible(void* ud, int dir);
static int MpOptToggleImmune(void* ud, int dir);
static int MpOptRepair(void* ud, int dir);
static int MpOptClearFelony(void* ud, int dir);

/* MP_WATCH=<secs> -- the FORENSICS lever for "the game froze but the link is up".
 *
 * A stalled match and a hung frame hook look identical from outside (nothing
 * moves), and they are different bugs. This logs, once every <secs>, the frame
 * hook's own tick count next to the SIM frame (gMp.frame) and the flags that
 * explain a stall. Read the two counters together:
 *   - hookTick keeps rising, simFrame stuck  -> the sim is not stepping (a pause:
 *     check pauseflag / drawPause, or running/role if the session fell over)
 *   - the watch line STOPS altogether        -> the frame hook itself is wedged
 * Unlike MP_HEARTBEAT (which lives in the sim tick and therefore stops WITH it),
 * this runs from the frame hook, which survives a frozen sim -- so it is the one
 * that can still speak at the moment of interest. Logging only; inert unless
 * MP_WATCH is set. */
extern int pauseflag;			/* declared with the other engine externs below; */
extern int gDrawPauseMenus;		/* needed here, earlier in the file */

static unsigned long gMpFrameHookTicks;

/* WHERE the frame last got to. Set at the entry and exit of the two big entry
 * points (the frame hook in mp.c, the sim tick in mp_session.c) and printed by
 * MP_WATCH. Read it as "the stage the PREVIOUS frame reached":
 *   sim        the sim tick was entered and never finished -> hung inside it
 *   sim-done   the sim tick finished
 *   frame      the frame hook was entered and never finished -> hung inside it
 *   frame-done the frame hook finished, so the hang is BETWEEN frames (engine side)
 * Non-static so mp_session.c's tick can set it; declared in mp.h. */
const char* gMpStage = "boot";

static void MpWatchTick(void)
{
	static unsigned long lastMs;
	const char* s = getenv("MP_WATCH");
	unsigned long now;
	int secs;

	if (s == NULL || gMpCtx == NULL)
		return;

	secs = atoi(s);

	if (secs <= 0)
		secs = 1;

	now = MpNowMs();

	if (lastMs != 0 && (now - lastMs) < (unsigned long)(secs * 1000))
		return;

	lastMs = now;

	gMpCtx->jer_log(gMpCtx,
		"[mp] watch: hookTick %lu simFrame %lu stage %s running %d role %d pauseflag %d drawPause %d\n",
		gMpFrameHookTicks, gMp.frame, gMpStage, gMp.running, (int)gMp.role, pauseflag, gDrawPauseMenus);
}

/* SESSION RULES, re-asserted every frame.
 *
 * NOT once at launch, and that is the whole point of this function: the LEVEL
 * sets these for itself when it comes up (level setup does
 * `CopsAllowed = (maxCopCars != 0)`), so a single write during the launch is
 * overwritten by the level's own opinion a frame later. Re-asserting each frame
 * is what makes the host's choice stick, and it is the same shape the engine's
 * own cheats already use -- main.c re-zeroes the player's damage every frame
 * while gInvincibleCar is set.
 *
 * gCopDifficultyLevel is re-asserted for the same reason: the frontend's Cop
 * Difficulty screen and mission scripts both write it.
 *
 * Silent until the rules are known (gMp.ruleSet) and only while a match is live,
 * so no pre-session or single-player frame gets a rule forced onto it that
 * nobody asked for. */
static void MpSessionRulesTick(void)
{
	/* "The menu says no cops" and "the sim is running with no cops" are
	 * different claims, and only the second one is the feature. Say it once per
	 * change of rules, with the ENGINE's own variables read back after the
	 * write, so the log proves which of the two we have. */
	static int reportedCops = -1, reportedDiff = -1, reportedInv = -1, reportedImmune = -1;

	if (!gMp.ruleSet || !gMp.running)
		return;

	CopsAllowed = gMp.ruleCops;
	gCopDifficultyLevel = gMp.ruleDiff;

	/* CopsAllowed alone is not enough: the arena missions (M498..M505) ship
	 * cops.max == 0, so LoadMission set maxCopCars = 0 and ControlNumberOfCops
	 * clamps the wanted count to it — CopsAllowed = 1 with maxCopCars = 0 still
	 * pings nothing. The police model already sits in resident slot 3
	 * (residentModels[3] == 0, the siren), so only the count gate needs
	 * overriding: re-assert the pursuit budget the way mission.c:699-725 would
	 * for a mission that carries cops. gDontPingInCops = 0 because nothing places
	 * cops in an arena — they must ping in on their own. gMinimumCops = 1 for the same
	 * reason mission.c now floors an mp map at one: RegisterFelony returns early unless a
	 * cop can SEE the player, so with no cop on the ground there is no way for the chase
	 * that raises the felony to begin - the cops would never appear at all. */
	if (gMp.ruleCops)
	{
		maxCopCars = 4;
		gMinimumCops = 1;
		gDontPingInCops = 0;
	}
	else
	{
		maxCopCars = 0;
		gMinimumCops = 0;
		gDontPingInCops = 1;
	}

	/* The two invincibility flags are a FLOOR, not an override. A rule that turns
	 * one ON grants it to everyone and cannot be switched off locally; a rule that
	 * leaves it OFF leaves each player's own pause-menu switch in charge. Forcing
	 * them back OFF would quietly delete a feature that is sitting right there in
	 * that menu -- and the host who wants it off has simply not granted it. */
	if (gMp.ruleImmune)
		gPlayerImmune = 1;

	if (gMp.ruleInvuln)
		gInvincibleCar = 1;

	if (gMp.ruleCops != reportedCops || gMp.ruleDiff != reportedDiff ||
	    gMp.ruleInvuln != reportedInv || gMp.ruleImmune != reportedImmune)
	{
		reportedCops = gMp.ruleCops;
		reportedDiff = gMp.ruleDiff;
		reportedInv = gMp.ruleInvuln;
		reportedImmune = gMp.ruleImmune;

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx,
				"[mp] session rules IN FORCE: rules cops=%d diff=%d immune=%d invuln=%d -> CopsAllowed=%d maxCopCars=%d gDontPingInCops=%d gCopDifficultyLevel=%d gPlayerImmune=%d gInvincibleCar=%d\n",
				gMp.ruleCops, gMp.ruleDiff, gMp.ruleImmune, gMp.ruleInvuln,
				CopsAllowed, maxCopCars, gDontPingInCops, gCopDifficultyLevel, gPlayerImmune, gInvincibleCar);
	}
}

static int MpOnFrame(void* userdata, void* args)
{
	(void)userdata;
	(void)args;

	gMpFrameHookTicks++;	/* one add a frame; the MP_WATCH log reads it */
	MpWatchTick();		/* prints the stage the LAST frame reached */
	gMpStage = "frame";

	/* The engine's main pause menu reads this to relabel "Restart" as "Respawn".
	 * Sync it every frame so it is always right by the time the pause opens (and
	 * cleared the frame after the session ends). */
	gJerPauseRestartAsRespawn = gMp.running ? 1 : 0;

	/* NO BACKSPACE / MAP FAST-FORWARD IN A SESSION. The engine offers it two ways:
	 * BACKSPACE (a debug/cutscene convenience, redriver2_psxpc.cpp) and the
	 * fullscreen map, which sets FastForward every frame it is open (overlay.c).
	 * A fast-forwarded sim runs at a different rate from everyone else's, which is
	 * the definition of desync.
	 *
	 * A LOCK, not a per-frame clear: clearing the flag every frame while the map
	 * re-set it every frame meant the two fought and the sim toggled fast/normal
	 * for as long as the map was up. With FastForwardLocked the engine never offers
	 * it in the first place, so nothing oscillates. */
	{
		extern int FastForward;
		extern int FastForwardLocked;

		static int lockAnnounced;

		/* The WHOLE session, not just a live match: between level load and the
		 * moment gMp.running goes up (spawn hand-off, countdown) a BACKSPACE or a
		 * map open would otherwise still step 7x before lockstep starts. */
		FastForwardLocked = (gMp.running || MpIsActive()) ? 1 : 0;

		if (FastForwardLocked != 0 && !lockAnnounced)
		{
			lockAnnounced = 1;

			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx,
					"[mp] fast-forward locked off for this session (BACKSPACE and the map screen both "
					"run the sim fast, which would desync it)\n");
		}

		if (FastForwardLocked && FastForward != 0)
			FastForward = 0;	/* a press from before the session started */
	}

	/* A Change car that asked for a car this machine does not hold yet and was told to
	 * wait (a spare slot busy for a frame or two): retry it here, once a frame, in the
	 * sim, which is where a level's resident slots mean anything. */
	MpCarChangeWaitTick();

	MpNetPoll(0);

	/* The advertisement is driven from here, not from the frontend's own tick: a
	 * match runs with no frontend on screen, and that is exactly when a listing has
	 * to keep saying the right number of players. */
	MpMasterAdvertiseCounts(gMp.playerCount, gMp.running);
	MpMasterAdvertisePoll();

	MpUiTick();

	/* The host's session rules, every frame -- the level sets these for itself
	 * when it loads, so a one-shot write at launch would not survive it. */
	MpSessionRulesTick();

	/* The test levers ride on the lockstep tick, which exists only inside a session
	 * (MpLockstepFrame returns at once when not running). Run the one lever that has
	 * a single-player meaning out here as well, so the single-player Change car path
	 * has a padless way to be exercised. Two no-ops unless MP_TEST_PAUSECAR is set
	 * AND the player is actually driving. */
	if (!gMp.running && !gInFrontend)
		MpTestPauseCarTick();

	/* MP_DEBUG: this hook runs whether or not the world is stepping, so its own
	 * counter can tell "the sim stopped" from "the module stopped". gMp.frame is
	 * incremented by the lockstep, which is exactly what is in question. */
	{
		static unsigned long ticks;

		if (MpDebugOn() && gMpCtx != NULL && (++ticks % 120) == 0)
			gMpCtx->jer_log(gMpCtx,
				"[mp] framehook: tick %lu mpframe %lu running %d connected %d frontend %d\n",
				ticks, gMp.frame, gMp.running, gMp.connected, gInFrontend);
	}

	/* MP_DEBUG: echo the engine's notice ROWS, so the WRAP can be checked from
	 * the log without eyes on the screen -- a wrapped message is several
	 * entries, one per drawn line. Log-only, so it cannot change behaviour. */
	if (MpDebugOn() && gMpCtx != NULL)
	{
		static int lastNotices = -1;
		int n = jer_error_count();

		if (n != lastNotices)
		{
			int k;

			lastNotices = n;

			for (k = 0; k < n; k++)
				gMpCtx->jer_log(gMpCtx, "[mp] notice[%d] = '%s'\n", k, jer_error_at(k));
		}
	}

	/* Deferred work, done on a FRAME rather than inside the poll that noticed it
	 * -- calling into the state machine from a message handler is re-entrant and
	 * crashed the client. FRAME and not PRE_SIM: a joining client is sitting in
	 * the FRONTEND, and PRE_SIM only runs in game, so the request was set and
	 * then never acted on. */
	/* Chat owns PsyX's single text-input slot exactly while the prompt is up.
	 * Re-asserted every frame so a missed release self-heals. */
	MpChatGrabKeyboard((gMp.chatOpen || MpUiManualEditing()) ? 1 : 0);
	jer_input_block(gMp.chatOpen);	/* typing never drives the car, horn, camera or pause */
	MpRejoinTick();		/* a server city change: rejoin, then restore our car */
	MpPlaceSelfTick();	/* a live join: off the level start, onto a road away from others */

	/* Test lever: MP_TEST_CITYCONFIRM=<secs>[,<gameType>[,<role>]] fires the
	 * take-a-ride CITY CONFIRM the way the frontend does (CutSceneCitySelectScreen
	 * on CROSS), that many seconds after the frontend comes up. A padless run
	 * cannot press X on that screen -- the frontend reads Pads[0].mapnew -- so
	 * without this the Single Player / Multiplayer prompt path is unreachable
	 * headlessly. The prompt OPENING is asserted separately: MpUiTick logs "the
	 * Single Player / Multiplayer menu did not open" on failure, so a run that
	 * REQUIRES the line below and FORBIDS that one is the regression guard for
	 * this whole flow. Inert unless set.
	 *
	 * The two optional fields exist because the gameType ALONE is a lie: measured
	 * on the real LAN host flow, this hook arrives with gameType == GAME_MISSION
	 * (0) and a session role already set, and that combination is exactly what the
	 * gate has to accept. Synthesising only GAME_TAKEADRIVE is what let the LAN
	 * path regress unnoticed, so the guard needs to be able to present the real
	 * shape. gameType 0..15 (dr2types.h), role 0=NONE 1=HOST 2=CLIENT
	 * (mp_proto.h); defaults are the old behaviour. */
	{
		static unsigned long confirmAtMs = 0;
		static int confirmDone = 0;
		const char* s = getenv("MP_TEST_CITYCONFIRM");

		if (s != NULL && !confirmDone && gInFrontend && gMpCtx != NULL)
		{
			if (confirmAtMs == 0)
				confirmAtMs = MpNowMs() + (unsigned long)(atoi(s) * 1000);

			if (MpNowMs() >= confirmAtMs)
			{
				JER_ARGS_FRONTEND fe;
				int gameType = GAME_TAKEADRIVE;
				int role = MP_ROLE_NONE;
				int roleSaved = (int)gMp.role;
				const char* comma = strchr(s, ',');

				confirmDone = 1;

				if (comma != NULL)
				{
					const char* comma2;

					gameType = atoi(comma + 1);

					comma2 = strchr(comma + 1, ',');
					if (comma2 != NULL)
						role = atoi(comma2 + 1);
				}

				fe.gameLevel = MpGetGameLevel();
				fe.gameType = (GAMETYPE)gameType;
				fe.numPlayers = 1;
				fe.defer = 0;

				/* Present the role the way the real flow does, then put it back: the
				 * lever exists to show the gate a session, not to leave a half-open
				 * one behind for the rest of the run. */
				gMp.role = role;
				jer_fire(JER_EVENT_FRONTEND, &fe);
				gMp.role = roleSaved;

				gMpCtx->jer_log(gMpCtx,
					"[mp] test: MP_TEST_CITYCONFIRM -> city confirm fired (gameType=%d role=%d defer=%d)\n",
					gameType, role, fe.defer);
			}
		}
	}

	/* Test lever: MP_TEST_CHATKEY=<secs> feeds the chat KEY into our own handler
	 * once, that many seconds after the match goes live, so the open path can be
	 * exercised with no keyboard (the harness has none). Inert unless set. */
	{
		static unsigned long fireAtMs = 0;
		const char* s = MpTestChatKey();

		if (s != NULL && gMpCtx != NULL)
		{
			if (fireAtMs == 0 && gMp.running)
				fireAtMs = MpNowMs() + (unsigned long)(atoi(s) * 1000);

			if (fireAtMs != 0 && fireAtMs != (unsigned long)-1 && MpNowMs() >= fireAtMs)
			{
				const char* comma;

				fireAtMs = (unsigned long)-1;	/* once */
				gMpCtx->jer_log(gMpCtx, "[mp] test: MP_TEST_CHATKEY -> chat key press\n");
				MpOnDebugKey(MP_KEY_CHAT_OPEN, 1);

				/* MP_TEST_CHATKEY=<secs>,<text>: type the text through the real
				 * character handler, then one BACKSPACE, and log what landed. */
				comma = strchr(s, ',');
				if (comma != NULL)
				{
					const char* t = comma + 1;

					for (; *t != '\0'; t++)
					{
						char one[2];

						one[0] = *t;
						one[1] = '\0';
						MpOnTextInput(one);
					}

					MpOnTextInput(NULL);	/* backspace */
					gMpCtx->jer_log(gMpCtx, "[mp] test: chat buffer now '%s'\n", gMp.chatBuf);

					gMpCtx->jer_log(gMpCtx, "[mp] test: chat SEND\n");
					MpOnDebugKey(MP_KEY_CHAT_SEND, 1);
				}
			}
		}
	}

	/* Test lever: MP_TEST_OPTIONS=<secs> fires the pause menu's four Player options
	 * once, that many seconds after the match goes live, by calling the SAME
	 * handlers the menu rows call -- so the toggles and the two one-shot repairs
	 * are checkable with no pad and no menu. Inert unless set. */
	{
		static unsigned long optAtMs = 0;
		const char* s = getenv("MP_TEST_OPTIONS");

		if (s != NULL && gMpCtx != NULL)
		{
			if (optAtMs == 0 && gMp.running)
				optAtMs = MpNowMs() + (unsigned long)(atoi(s) * 1000);

			if (optAtMs != 0 && optAtMs != (unsigned long)-1 && MpNowMs() >= optAtMs)
			{
				optAtMs = (unsigned long)-1;	/* once */
				gMpCtx->jer_log(gMpCtx,
					"[mp] test: MP_TEST_OPTIONS -> firing the four Player options\n");
				MpOptToggleInvincible(NULL, 0);
				MpOptToggleImmune(NULL, 0);
				MpOptRepair(NULL, 0);
				MpOptClearFelony(NULL, 0);
			}
		}
	}

	/* Test lever: MP_TEST_RESPAWN=<secs> fires the pause menu's Respawn --- the
	 * nearest-road respawn, MpRespawnOnRoad --- that many seconds in, so the
	 * repair + clear-felony side of Respawn is checkable with no pad and no menu.
	 * Inert unless set. */
	{
		static unsigned long rsAtMs = 0;
		const char* s = getenv("MP_TEST_RESPAWN");

		if (s != NULL && gMpCtx != NULL)
		{
			if (rsAtMs == 0 && gMp.running)
				rsAtMs = MpNowMs() + (unsigned long)(atoi(s) * 1000);

			if (rsAtMs != 0 && rsAtMs != (unsigned long)-1 && MpNowMs() >= rsAtMs)
			{
				MP_PLAYER* me = MpLocalPlayer();
				int hasCar = (me != NULL && me->carId >= 0 && me->carId < MAX_CARS);
				int injured = hasCar ? car_data[me->carId].totalDamage : -1;
				int before = hasCar ? car_data[me->carId].felonyRating : -1;
				int ok;

				rsAtMs = (unsigned long)-1;	/* once */
				ok = MpRespawnOnRoad();
				gMpCtx->jer_log(gMpCtx,
					"[mp] test: MP_TEST_RESPAWN -> returned %d; damage %d -> %d, felony %d -> %d\n",
					ok, injured, hasCar ? car_data[me->carId].totalDamage : -1,
					before, hasCar ? car_data[me->carId].felonyRating : -1);
			}
		}
	}

	/* Test lever: MP_TEST_FELONY=<value> sets the local car's felony rating, so a
	 * respawn's clear-felony is observable (felony otherwise needs collisions to
	 * rise, which a padless run does not cause). Inert unless set. */
	{
		static int felonyDone = 0;
		const char* s = getenv("MP_TEST_FELONY");

		if (s != NULL && !felonyDone && gMp.running && gMpCtx != NULL)
		{
			MP_PLAYER* me = MpLocalPlayer();

			if (me != NULL && me->carId >= 0 && me->carId < MAX_CARS)
			{
				felonyDone = 1;
				car_data[me->carId].felonyRating = atoi(s);
				gMpCtx->jer_log(gMpCtx,
					"[mp] test: MP_TEST_FELONY -> car felony = %d\n",
					car_data[me->carId].felonyRating);
			}
		}
	}

	/* Test lever: MP_TEST_RULES=<secs> adopts the configured session rules
	 * (mirroring MpRulesAdopt) that many seconds in, so MpSessionRulesTick's
	 * per-frame re-assertion --- and the cops count gate it opens --- is
	 * checkable without the host menu ever running. Inert unless set. */
	{
		static unsigned long rlAtMs = 0;
		const char* s = getenv("MP_TEST_RULES");

		if (s != NULL && gMpCtx != NULL)
		{
			if (rlAtMs == 0 && gMp.running)
				rlAtMs = MpNowMs() + (unsigned long)(atoi(s) * 1000);

			if (rlAtMs != 0 && rlAtMs != (unsigned long)-1 && MpNowMs() >= rlAtMs)
			{
				rlAtMs = (unsigned long)-1;	/* once */
				gMp.ruleCops = gMp.config.cops;
				gMp.ruleInvuln = gMp.config.invuln;
				gMp.ruleImmune = gMp.config.immune;
				gMp.ruleDiff = gMp.config.copDifficulty;
				gMp.ruleSet = 1;
				gMpCtx->jer_log(gMpCtx,
					"[mp] test: MP_TEST_RULES -> adopted cops=%d diff=%d\n",
					gMp.ruleCops, gMp.ruleDiff);
			}
		}
	}

	if (gMp.pendingLaunch)
	{
		gMp.pendingLaunch = 0;

		if (gMp.autoSession && MpJoinState() == MP_JOIN_READY)
			MpClientLaunch();
	}

	/* a peer with no car joined a live match: build it here, on a frame */
	if (gMp.pendingSpawn)
	{
		gMp.pendingSpawn = 0;

		/* BOTH sides: a client can also defer a remote car it could not name at
		 * level init (the level's mission header is not parsed yet) and build it
		 * here once the level is up. */
		if (gMp.running)
			MpSpawnLateJoiners();
	}

	/* Test lever: dump the player list, so the roster/player-row formatting can
	 * be exercised without a human opening any screen.
	 *
	 * MP_MAP used to force the map open -- the same mistake the pause lever made:
	 * the engine then draws a map whose state was never set up, and the screen
	 * goes red. It only logs now. */
	if (MpLeverFlag("MP_MAP", &gTestMapOn) && gMp.running)
		MpLogPlayerList();

	/* A connection loss asked for the main menu: take it as soon as the engine
	 * is back in the frontend, so the player cannot be left in the middle of
	 * the menu chain that started the match. */
	if (gReturnToMenu && gInFrontend)
	{
		gReturnToMenu = 0;
		jer_frontend_goto(0);
	}

	/* The host quit the match: it is back in the frontend while the session
	 * is still live, so tell the clients and tear everything down. */
	if (MpHostLeftMatch())
	{
		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] host left the match - notifying clients\n");

		MpHostByeAll();
		MpLeaveSession();
	}

	/* A LAN session is one player per machine. The stock frontend's
	 * multiplayer chain leaves NumPlayers at 2 for its split-screen flow,
	 * which makes the car select ask for a SECOND player's car -- hold it at
	 * 1 for the whole host/join flow (the log line tells us if this was the
	 * cause). */
	if (gMp.role != MP_ROLE_NONE && !gMp.running && NumPlayers != 1)
	{
		NumPlayers = 1;

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] LAN flow: forced NumPlayers back to 1\n");
	}

	/* MP_AUTOSTART=host: launch once MP_AUTOJOIN_START players are in (a
	 * straggler would otherwise be rejected: a running game is INPROGRESS),
	 * or after ~30 s regardless so a short-handed test still starts. */
	if (gAutoHostStart && !gMp.running)
	{
		++gAutoHostFrames;

		if (gMp.playerCount >= gAutoHostTarget)
			++gAutoHostSettle;
		else
			gAutoHostSettle = 0;

		if ((gAutoHostSettle > 60) || gAutoHostFrames > 900)
		{
			gAutoHostStart = 0;

			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] autostart: starting match with %d player(s) (target %d)\n",
					gMp.playerCount, gAutoHostTarget);

			MpStartMatch();
		}
	}

	/* diagnostic: where the module thinks every player car is, and whether the
	 * engine is actually simulating it (list= is membership of the engine's
	 * own active_car_list, which StepCars walks). MP_DEBUG-gated: it is a scan
	 * plus a 12-field line per player every 2s, for a dev only. */
	if (MpDebugOn() && gMp.running && gMpCtx != NULL && (gMp.frame % 60) == 0)
	{
		int i;

		for (i = 0; i < MP_MAX_PLAYERS; i++)
		{
			MP_PLAYER* p = &gMp.players[i];

			if (!p->active || p->carId < 0 || p->carId >= MAX_CARS)
				continue;

			{
				CAR_DATA* cd = &car_data[p->carId];
				int inList = 0, k;

				for (k = 0; k < num_active_cars; k++)
				{
					if (active_car_list[k] == cd)
						inList = 1;
				}

				gMpCtx->jer_log(gMpCtx, "[mp] pose: player %d local=%d car %d at %d,%d,%d spd=%d ct=%d pad=%d hnd=%d vy=%d list=%d/%d\n",
					p->id, p->isLocal, p->carId,
					cd->hd.where.t[0], cd->hd.where.t[1], cd->hd.where.t[2],
					cd->hd.speed,
					cd->controlType,
					cd->ai.padid != NULL ? *cd->ai.padid : -99,
					cd->hndType,
					cd->st.n.linearVelocity[1],
					inList, num_active_cars);
			}
		}
	}

	gMpStage = "frame-done";
	return JER_RESULT_CONTINUE;
}

/* In-game the DRAW_OVERLAY event fires on every drawn frame -- including while
 * the game is PAUSED, where StepSim (and so JER_EVENT_FRAME) does not run.
 * Servicing the socket here is what keeps a paused session alive: we keep
 * sending our keepalive and keep draining the peer's. */
extern void SetTextColour(unsigned char Red, unsigned char Green, unsigned char Blue);
extern int  PrintStringHiresScaledSpaced(char* string, int x, int y, float scale, float extra);
extern int  gDrawPauseMenus;

/* A live match must keep simulating while the pause menu is up, but the engine
 * freezes the world (pauseflag blocks its StepSim). StepSim is an EXPORTED
 * engine symbol, so we drive the world ourselves from the overlay hook, which
 * fires on every drawn frame including while paused. */
extern void StepSim(void);
extern int  pauseflag;
extern void UnPauseSound(void);	/* the engine pauses music/sfx with the world */

/* While the pause menu is up, list who is connected down the left side.
 *
 * The host leads the list and is cyan, because it is the one machine that owns
 * the session. Everyone else follows in ascending player id -- the same order the
 * car slots are handed out in, so the list reads the way the match is built. Each
 * row is the player's name and index, the vehicle they are in (-1 = on foot) and
 * their round trip as the host measures it. */
/* The same rows the pause menu draws, without drawing anything: enough to check
 * names, slots and ping from a log, and safe to call from anywhere. */
static void MpLogPlayerList(void)
{
	int id;

	for (id = 0; id < MP_MAX_PLAYERS; id++)
	{
		MP_PLAYER* p = MpGetPlayer(id);
		CAR_DATA* cp;
		int veh = -1;

		if (p == NULL)
			continue;

		if (p->carId >= 0 && p->carId < MAX_CARS)
		{
			cp = &car_data[p->carId];

			if (cp->controlType != CONTROL_TYPE_NONE)
				veh = cp->ap.model;
		}

		if (gMpCtx != NULL)
		{
			MP_PEER_STATS st;
			char net[72];

			if (!p->isLocal && MpPeerStats(p->id, &st) && st.linkMs > 0)
			{
				unsigned long rxS = st.rxBytes * 1000UL / st.linkMs;
				unsigned long txS = st.txBytes * 1000UL / st.linkMs;

				snprintf(net, sizeof(net), "%d ms  rx %luB/s  tx %luB/s  loss %d%%",
					st.pingMs, rxS, txS, st.lossPct);
			}
			else
			{
				snprintf(net, sizeof(net), "%d ms", p->pingMs);
			}

			gMpCtx->jer_log(gMpCtx, "[mp] list: (build %04x mods %04x) %s #%d  car %d  slot %d  %s%s\n",
				MpBuildHash(), MpModHash(),
				p->name, p->id, veh, p->carId, net, p->isHost ? "  (host)" : "");
		}
	}
}

/* ------------------------------------------------------------------ */
/* The pause panel                                                     */
/*                                                                     */
/* This readout wears its OWN colours, deliberately not the chat's:     */
/* chat is a conversation -- a speaker's name in their colour, the      */
/* message in a flat near-white -- while this is a status panel, so it  */
/* gets an accent for its title, a colour per ROLE, and dim greys for   */
/* its labels and chrome.                                              */
/*                                                                     */
/* Every value below is the colour as it should LOOK, because MpInk     */
/* halves it: the HQ font is drawn with the PSX texture filter on (x2), */
/* the same trap jer_console's jerConsoleInk handles. Without it every  */
/* grey clips to white -- which is exactly what this panel used to be:  */
/* its 200/170/150/140 were one flat white, and only the saturated cyan */
/* of the host survived.                                               */
static u_char MpInk(int v)
{
	if (v <= 0)
		return 0;
	if (v >= 255)
		return 128;		/* 128 * 2 = 256, clipped back to 255 */

	return (u_char)((v * 128) / 255);
}

#define MP_INK(r, g, b)		MpInk(r), MpInk(g), MpInk(b)

#define MP_PANEL_ACCENT_R	130	/* the title: a cool accent, so the panel reads as its own thing */
#define MP_PANEL_ACCENT_G	190
#define MP_PANEL_ACCENT_B	255
#define MP_PANEL_IDENT_R	150	/* the build/addons line */
#define MP_PANEL_IDENT_G	160
#define MP_PANEL_IDENT_B	185
#define MP_PANEL_LABEL_R	150	/* column headers and the columns that are not the point */
#define MP_PANEL_LABEL_G	150
#define MP_PANEL_LABEL_B	150
#define MP_PANEL_SELF_R		150	/* your own row */
#define MP_PANEL_SELF_G		245
#define MP_PANEL_SELF_B		170
#define MP_PANEL_HOST_R		0	/* the host, cyan, as it always was */
#define MP_PANEL_HOST_G		255
#define MP_PANEL_HOST_B		255
#define MP_PANEL_PEER_R		210	/* everyone else */
#define MP_PANEL_PEER_G		210
#define MP_PANEL_PEER_B		210
#define MP_PANEL_WARN_R		255	/* a link that is dropping frames */
#define MP_PANEL_WARN_G		190
#define MP_PANEL_WARN_B		90

/* Half size, like the status console. This is what makes ONE line per player
 * possible: at the default 0.275 only about 33 characters fit, which is why a
 * player used to take two rows -- a name row and an indented link row. */
#define MP_PANEL_SCALE		0.138f
#define MP_PANEL_TRACKING	0.75f

/* Column x positions in PSX screen units (the screen is 320 wide). A full row is
 * about 50 half-size characters, which fits with room to spare. */
#define MP_COL_NAME		6
#define MP_COL_CAR		92
#define MP_COL_PING		130
#define MP_COL_RX		164
#define MP_COL_TX		206
#define MP_COL_LOSS		250

#define MP_PANEL_Y_TITLE	6
#define MP_PANEL_Y_IDENT	15
#define MP_PANEL_Y_HEAD		26
#define MP_PANEL_Y_FIRST	36
#define MP_PANEL_Y_STEP		10

static void MpPanelText(const char* text, int x, int y)
{
	PrintStringHiresScaledSpaced((char*)text, x, y, MP_PANEL_SCALE, MP_PANEL_TRACKING);
}

/* A byte rate short enough for its column: "12.3K/s", "999B/s". The value is
 * capped so the widest string the column can ever hold is 7 characters -- the
 * column is 42 px, and a row that grew past it would run into the next one. */
static void MpFormatRate(char* out, size_t max, unsigned long bytesPerSec)
{
	if (bytesPerSec > 99999UL)
		bytesPerSec = 99999UL;

	if (bytesPerSec >= 1000UL)
		snprintf(out, max, "%.1fK/s", (double)bytesPerSec / 1000.0);
	else
		snprintf(out, max, "%luB/s", bytesPerSec);
}

/* The name, plus what the player IS. The name column is about 17 half-size
 * characters, so a long name is cut rather than allowed to run into the car
 * column. The player id stays in the log: on screen the role word is what a
 * player can act on. */
static void MpFormatPanelName(char* out, size_t max, const MP_PLAYER* p)
{
	char name[MP_NAME_MAX];

	snprintf(name, sizeof(name), "%s", (p->name[0] != '\0') ? p->name : "?");

	if (strlen(name) > 11)
		name[11] = '\0';

	snprintf(out, max, "%s%s", name,
		p->isLocal ? " (you)" : (p->isHost ? " (host)" : ""));
}

static void MpDrawPlayerList(void)
{
	char ident[80];
	int id, row = 0;

	/* TOP-LEFT corner and high up: the engine's own pause panel is centred
	 * around the middle of the screen (Bound.y = MAX(48, (SCREEN_H -
	 * (n+1)*15)/2) in pause.c), so the room is up here. Half size is what makes
	 * the room, not the corner. */
	SetTextColour(MP_INK(MP_PANEL_ACCENT_R, MP_PANEL_ACCENT_G, MP_PANEL_ACCENT_B));
	MpPanelText("PLAYERS", MP_COL_NAME, MP_PANEL_Y_TITLE);

	/* The build identity, said in plain words. These are the same numbers the
	 * startup log prints and the ones strict_version compares, and a mismatch is
	 * the single most common cause of "we cannot see each other". */
	snprintf(ident, sizeof(ident), "all players must match:  build %04x  addons %04x",
		MpBuildHash(), MpModHash());

	SetTextColour(MP_INK(MP_PANEL_IDENT_R, MP_PANEL_IDENT_G, MP_PANEL_IDENT_B));
	MpPanelText(ident, MP_COL_NAME, MP_PANEL_Y_IDENT);

	SetTextColour(MP_INK(MP_PANEL_LABEL_R, MP_PANEL_LABEL_G, MP_PANEL_LABEL_B));
	MpPanelText("PLAYER", MP_COL_NAME, MP_PANEL_Y_HEAD);
	MpPanelText("CAR",    MP_COL_CAR,  MP_PANEL_Y_HEAD);
	MpPanelText("PING",   MP_COL_PING, MP_PANEL_Y_HEAD);
	MpPanelText("RX",     MP_COL_RX,   MP_PANEL_Y_HEAD);
	MpPanelText("TX",     MP_COL_TX,   MP_PANEL_Y_HEAD);
	MpPanelText("LOSS",   MP_COL_LOSS, MP_PANEL_Y_HEAD);

	for (id = 0; id < MP_MAX_PLAYERS; id++)
	{
		MP_PLAYER* p = MpGetPlayer(id);
		CAR_DATA* cp;
		char name[MP_NAME_MAX + 12];
		char car[20];
		char ping[16];
		char rx[16];
		char tx[16];
		char loss[8];
		char net[72];
		int lossPct = -1;
		int veh = -1;
		int vehCity = -1;
		int y;

		if (p == NULL)
			continue;

		/* -1 means on foot: either we have no car slot for them, or the car is
		 * standing there with nobody driving it */
		if (p->carId >= 0 && p->carId < MAX_CARS)
		{
			cp = &car_data[p->carId];

			/* WHICH car, the way car selection names it: the city whose car list
			 * it comes from and its model number in that city (MP_CAR's model +
			 * modelCity). ap.model is only the RESIDENT SLOT the level loaded it
			 * into, which says nothing about the car itself. */
			if (cp->controlType != CONTROL_TYPE_NONE &&
			    cp->ap.model >= 0 && cp->ap.model < MAX_CAR_RESIDENT_MODELS)
			{
				veh = residentCarModels[cp->ap.model];
				vehCity = GetCarModelSourceCity(cp->ap.model);

				if (vehCity < 0)
					vehCity = GameLevel;
			}
		}

		MpFormatPanelName(name, sizeof(name), p);

		if (veh >= 0)
			snprintf(car, sizeof(car), "%d:%d", vehCity, veh);
		else
			snprintf(car, sizeof(car), "on foot");

		{
			MP_PEER_STATS st;

			if (!p->isLocal && MpPeerStats(p->id, &st) && st.linkMs > 0)
			{
				unsigned long rxS = st.rxBytes * 1000UL / st.linkMs;
				unsigned long txS = st.txBytes * 1000UL / st.linkMs;

				/* loss is the fraction of sim frames in which NOTHING arrived
				 * from them -- the closest honest proxy TCP gives us */
				lossPct = st.lossPct;

				snprintf(ping, sizeof(ping), "%dms", st.pingMs);
				MpFormatRate(rx, sizeof(rx), rxS);
				MpFormatRate(tx, sizeof(tx), txS);
				snprintf(loss, sizeof(loss), "%d%%", st.lossPct);
			}
			else
			{
				/* Nothing measured (this machine, or a link that has not
				 * reported yet): keep every column, so the table does not
				 * shift about as rows come and go. */
				snprintf(ping, sizeof(ping), "%dms", p->pingMs);
				snprintf(rx, sizeof(rx), "--");
				snprintf(tx, sizeof(tx), "--");
				snprintf(loss, sizeof(loss), "--");

				/* A row we have no link of our own to (a client looking at another
				 * client): the HOST's measurement of that player's link, when it
				 * sent one lately (MP_TAG_STATS). */
				if (!p->isLocal && p->netLastMs != 0 && MpNowMs() - p->netLastMs < 10000UL)
				{
					MpFormatRate(rx, sizeof(rx), p->netRxBps);
					MpFormatRate(tx, sizeof(tx), p->netTxBps);

					if (p->netLoss != MP_STATS_LOSS_UNKNOWN)
					{
						lossPct = p->netLoss;
						snprintf(loss, sizeof(loss), "%d%%", p->netLoss);
					}
				}
			}
		}

		y = MP_PANEL_Y_FIRST + row * MP_PANEL_Y_STEP;
		row++;

		if (p->isLocal)
			SetTextColour(MP_INK(MP_PANEL_SELF_R, MP_PANEL_SELF_G, MP_PANEL_SELF_B));
		else if (p->isHost)
			SetTextColour(MP_INK(MP_PANEL_HOST_R, MP_PANEL_HOST_G, MP_PANEL_HOST_B));
		else
			SetTextColour(MP_INK(MP_PANEL_PEER_R, MP_PANEL_PEER_G, MP_PANEL_PEER_B));

		MpPanelText(name, MP_COL_NAME, y);
		MpPanelText(car,  MP_COL_CAR,  y);
		MpPanelText(ping, MP_COL_PING, y);
		MpPanelText(rx,   MP_COL_RX,   y);
		MpPanelText(tx,   MP_COL_TX,   y);

		/* A dropping link is the one figure worth colouring; the rest is detail. */
		if (lossPct >= 5)
			SetTextColour(MP_INK(MP_PANEL_WARN_R, MP_PANEL_WARN_G, MP_PANEL_WARN_B));
		else
			SetTextColour(MP_INK(MP_PANEL_LABEL_R, MP_PANEL_LABEL_G, MP_PANEL_LABEL_B));

		MpPanelText(loss, MP_COL_LOSS, y);

		/* so the list can be checked without eyes on the screen */
		if (MpDebugOn() && gMpCtx != NULL)
		{
			static unsigned long lastListMs;

			if ((MpNowMs() - lastListMs) > 2000)
			{
				lastListMs = MpNowMs();

				if (p->isLocal)
					snprintf(net, sizeof(net), "%s  (local)", ping);
				else
					snprintf(net, sizeof(net), "%s  %s  %s  loss %s", ping, rx, tx, loss);

				gMpCtx->jer_log(gMpCtx, "[mp] list: (build %04x mods %04x) %s | %s\n",
					MpBuildHash(), MpModHash(), name, net);
			}
		}
	}
}

/* A car whose real model is still loading is drawn as the host city's car 1,
 * solid grey: the stand-in body is obvious, and the chase camera never follows a
 * slot with no mesh. Only cars marked by the reload failsafe are touched. */
static int MpOnCarDrawColor(void* userdata, void* args)
{
	JER_ARGS_CAR_DRAW_COLOR* a = (JER_ARGS_CAR_DRAW_COLOR*)args;
	CAR_DATA* cp = (CAR_DATA*)a->car;

	(void)userdata;

	if (cp != NULL && MpCarIsStandIn(cp->id))
	{
		a->flatBlack = 0;
		a->tintR = a->tintG = a->tintB = 128;	/* solid grey */
	}

	return JER_RESULT_CONTINUE;
}

static int MpOnDrawOverlay(void* userdata, void* args)
{
	(void)userdata;
	(void)args;

	if (gMp.role == MP_ROLE_NONE)
		return JER_RESULT_CONTINUE;

	MpNetPoll(0);

	/* A LIVE MATCH DOES NOT FREEZE FOR THE PAUSE MENU. The engine freezes the world
	 * while its pause menu is open (pauseflag) and does not run JER_EVENT_FRAME --
	 * where our net tick lives -- while frozen, and it pauses the audio with it.
	 * So while a session is up and paused we step the world ourselves and undo the
	 * audio pause once on the way in. The menu is still the engine's.
	 *
	 * Do NOT call MpLockstepFrame again here: StepSim() fires JER_EVENT_PRE_SIM at
	 * its top, and our MpOnPreSim handler runs the lockstep. Calling it here as
	 * well advanced gMp.frame (and ran every lockstep tick) TWICE on the paused
	 * machine while every other machine advanced once -- the pausing player was
	 * one frame ahead per frame of their own pause. */
	{
		static int wasPaused;

		if (gMp.running && pauseflag != 0)
		{
			if (!wasPaused)
			{
				wasPaused = 1;
				UnPauseSound();
			}

			StepSim();
		}
		else
		{
			wasPaused = 0;
		}
	}

	/* The player list / MP options ride on the engine's PAUSE menu -- and only on
	 * the pause menu.
	 *
	 * The two obvious signals are both wrong on their own. `gDrawPauseMenus` means
	 * "a pause-MODE menu is up", which includes the game-over, mission-complete
	 * and pad-error screens (pause.c sets it in PauseMenu(), for every mode).
	 * `pauseflag` means "the world is frozen", which the director and cutscenes
	 * raise too. Together they put this panel on screen while the player was
	 * watching a cutscene.
	 *
	 * So: the engine fires JER_EVENT_PAUSE_MENU/JER_PAUSE_OPEN for the pause
	 * itself (main.c), and when we do not claim the press the engine opens
	 * PAUSEMODE_PAUSE. MpOnPauseMenu records that as gMpPauseOpened, and here we
	 * clear it as soon as the menus stop being drawn. The panel is then shown
	 * exactly while the pause the player opened is on screen. */
	if (!gDrawPauseMenus)
		gMpPauseOpened = 0;

	gMpShowPlayers = (gMp.running && gMpPauseOpened && gDrawPauseMenus) ? 1 : 0;

	/* MP_PAUSE logs the list for a test, and deliberately does NOT force the
	 * engine's pause flag. It used to set gDrawPauseMenus = 1 every frame, which
	 * makes the engine draw pause menus whose state was never set up -- a wild
	 * pointer, and an access violation. Forcing another subsystem's state from a
	 * test lever is not a shortcut, it is a new bug.
	 *
	 *     draw  = what the player sees (needs the pause menu actually open)
	 *     log   = the rows, which is what the test is checking anyway */
	if (MpLeverFlag("MP_PAUSE", &gTestPauseOn) && gMp.running)
		MpLogPlayerList();

	/* MP_PANEL: show the panel itself, so its layout and colours can be captured
	 * from a -shot run with no pad and no engine pause. Unlike MP_PAUSE above,
	 * this sets OUR OWN flag (gMpShowPlayers) rather than reaching into the
	 * engine's pauseflag -- the point of the rule above is not to force another
	 * subsystem's state, not to avoid test levers. */
	if (MpLeverFlag("MP_PANEL", &gTestPanelOn) && gMp.running)
		gMpShowPlayers = 1;

	/* MP_OPENPAUSE=<secs>: open the pause for real, so the gating above can be
	 * checked with no pad (nothing else can open the engine pause headlessly).
	 * This does both halves of what the pad handler does: it fires the same
	 * JER_PAUSE_OPEN the engine fires -- which is what sets gMpPauseOpened -- and
	 * then calls the engine's own EnablePause, which is the SUPPORTED way to open
	 * the pause because it initialises the menu state. (The old MP_PAUSE lever set
	 * gDrawPauseMenus directly and read a menu that was never set up: a wild
	 * pointer. Calling the engine's entry point is not that.)
	 *
	 * It re-arms while the pause is closed, i.e. it HOLDS START. Without that a
	 * -shot lands on whatever frame it lands on, and a frame the pause happened to
	 * be closed on proves nothing either way. */
	if (gMp.running)
	{
		static unsigned long openAtMs = 0;
		const char* s = getenv("MP_OPENPAUSE");

		if (s != NULL)
		{
			if (openAtMs == 0)
				openAtMs = MpNowMs() + (unsigned long)(atoi(s) * 1000);

			if (openAtMs != (unsigned long)-1 && MpNowMs() >= openAtMs &&
				(!pauseflag || !gDrawPauseMenus))
			{
				JER_ARGS_PAUSE_MENU a;

				a.action = JER_PAUSE_OPEN;
				a.result = NULL;
				a.value = 0;

				if (gMpCtx != NULL)
					gMpCtx->jer_log(gMpCtx, "[mp] test: MP_OPENPAUSE -> START\n");

				if (jer_fire(JER_EVENT_PAUSE_MENU, &a) != JER_RESULT_STOP)
					EnablePause(PAUSEMODE_PAUSE);
			}
		}
	}

	if (gMpShowPlayers)
		MpDrawPlayerList();

	/* The bottom-left HOST/CLIENT tag and its two live connection lines USED to be
	 * drawn here. REMOVED: with the status console drawing the same corner, the
	 * block was a second, larger debug readout stacked under it. The same facts
	 * (the role, the peer, the handshake stage, the last event) are still in the
	 * session log -- see MpConnEvent's `[mp] conn: ...` and `[mp] conn status: ...`
	 * lines, which is what MpConnLineText exists for now. */

	return JER_RESULT_CONTINUE;
}

/* JERICHO-HOOK: the engine pause freezes the simulation -- which in a network
 * session freezes only THIS machine. Everyone else keeps driving, so the moment
 * play resumes the two disagree. In a live match the START press must therefore
 * not open it: claim the press (JER_RESULT_STOP, so the engine pause never
 * opens and pauseflag is never set) and toggle our own non-freezing player list.
 * A press while a session is only being set up, and stock single-player, keep
 * the normal pause. */
/* ------------------------------------------------------------------ */
/* The MP pause menu.                                                  */
/*                                                                     */
/* Small on purpose for now: it exists so the one thing you always      */
/* want when something goes wrong -- a written-down account of what the */
/* connection was doing -- is one button away, and so the per-player    */
/* options later have a home that is not bolted onto the engine's own   */
/* menu. jer_pause_menu_register collects this under "Modules".         */
static int MpMenuWriteDiag(void* userdata, int direction)
{
	(void)userdata;
	(void)direction;

	MpDiagDump("asked for from the pause menu");
	MpNotify("...mp_diag.txt written next to the game");

	return JER_PAUSE_QUIT_NONE;
}

/* ------------------------------------------------------------------ */
/* A player's character, in that player's colour                       */
/*                                                                    */
/* The engine recolours the CLUT rows for ONE ped at a time, and its   */
/* selection PERSISTS until it is changed -- so this has to speak for   */
/* every ped it is asked about, including saying "stock colours" for   */
/* one that is not ours. Getting that wrong is how a mod ends up       */
/* painting a civilian.                                                */
/*                                                                    */
/* `on` is off by default: off means the character keeps exactly the    */
/* colours the game gave it, which is also what a ped we do not own     */
/* gets.                                                               */
static int MpOnPedDraw(void* userdata, void* args)
{
	JER_ARGS_PED_DRAW* a = (JER_ARGS_PED_DRAW*)args;
	int i, on = 0, r = 0, g = 0, b = 0;

	(void)userdata;

	if (a == NULL)
		return JER_RESULT_CONTINUE;

	/* No ped at all: clear, because the last selection sticks. */
	if (a->ped == NULL)
	{
		jer_ped_palette_select(-1);
		return JER_RESULT_CONTINUE;
	}

	if ((void*)a->ped == MpLocalPedPtr())
	{
		/* ours: the config is the truth, not the network table */
		on = gMp.config.colorOn;
		r = gMp.config.colorR;
		g = gMp.config.colorG;
		b = gMp.config.colorB;
	}
	else
	{
		for (i = 0; i < MP_MAX_PLAYERS; i++)
		{
			MP_PLAYER* p = &gMp.players[i];

			if (!p->active || p->ped == NULL)
				continue;

			if ((void*)p->ped == a->ped)
			{
				on = p->colorOn;
				r = p->colorR;
				g = p->colorG;
				b = p->colorB;
				break;
			}
		}
	}

	if (!on)
	{
		jer_ped_palette_select(-1);
		return JER_RESULT_CONTINUE;
	}

	/* The player's suit colour in JERICHO's canonical colour space (jer_colour.h):
	 * the config / wire carries r,g,b, and jer_colour_make clamps and names it so
	 * this draw path never has to think about the engine's two packings. Each
	 * distinct colour gets its own palette rows; identical colours share them. */
	jer_ped_palette_select(jer_ped_palette_team_colour(jer_colour_make(r, g, b), MP_COLOR_STRENGTH));

	return JER_RESULT_CONTINUE;
}

/* ------------------------------------------------------------------ */
/* Player options: the colour editor                                   */
/*                                                                    */
/* One toggle and three sliders. The toggle comes first because it is  */
/* the important one: OFF (the default) keeps the game's own colours,  */
/* and a player who never touches any of this sees nothing change.     */
#define MP_COLOR_STEP 16

static void MpColorLabelOn(void* ud, char* out, int max)
{
	(void)ud;
	snprintf(out, max, "Custom colour: %s", gMp.config.colorOn ? "ON" : "OFF (original)");
}

static int MpColorToggleOn(void* ud, int dir)
{
	(void)ud;
	(void)dir;

	gMp.config.colorOn = gMp.config.colorOn ? 0 : 1;
	MpConfigSave();

	return 0;
}

static void MpColorLabelR(void* ud, char* out, int max)
{
	(void)ud;
	snprintf(out, max, "Red: %d", gMp.config.colorR);
}

static void MpColorLabelG(void* ud, char* out, int max)
{
	(void)ud;
	snprintf(out, max, "Green: %d", gMp.config.colorG);
}

static void MpColorLabelB(void* ud, char* out, int max)
{
	(void)ud;
	snprintf(out, max, "Blue: %d", gMp.config.colorB);
}

static int MpColorAdjust(int* which, int dir)
{
	*which += dir * MP_COLOR_STEP;

	if (*which < 0)
		*which = 0;
	if (*which > 255)
		*which = 255;

	MpConfigSave();

	return 0;
}

static int MpColorAdjustR(void* ud, int dir) { (void)ud; return MpColorAdjust(&gMp.config.colorR, dir); }
static int MpColorAdjustG(void* ud, int dir) { (void)ud; return MpColorAdjust(&gMp.config.colorG, dir); }
static int MpColorAdjustB(void* ud, int dir) { (void)ud; return MpColorAdjust(&gMp.config.colorB, dir); }

/* ------------------------------------------------------------------ */
/* Change car: the Multiplayer pause page's vehicle picker             */
/* ------------------------------------------------------------------ */
/* Two round-robin rows and an apply row, the same shape as mpColorMenu. A row is
 * a cycler, not a list, because the pause menu's item set is fixed when the page
 * is built and a module menu cannot nest a second level (jer_pause_menu.h) -- so
 * a long roster is reached by cycling, not by listing.
 *
 * The CARS are a city's frontend roster, read from the same two engine arrays the
 * stock car screen and carhacks' own picker use: CarAvailability[city][slot] says
 * whether the slot is offered, carNumLookup[city][slot] is its MODEL NUMBER.
 *
 * The CITIES come from carhacks when it is installed (a session can legitimately
 * mix cities' car data; that is what carhacks is for) and from the session's own
 * city alone when it is not. */
#define MPCC_MAX_CITIES	CITY_COUNT	/* JERICHO: the engine's city ROW CAPACITY (stock nine +
					 * 16 runtime bank slots), NOT the number of cities a
					 * session has: carhacks answers JER_CARQ_CITIES with the
					 * cities this install actually has (chkCityCount), and the
					 * picker TRUNCATES to this. It was 6 when only Driver 2's
					 * four cities could be offered, and the D1 cities past the
					 * first two were silently dropped. Holding it at the
					 * capacity means a runtime bank can never be the one that
					 * gets truncated away. */
#define MPCC_MAX_CARS	MP_CAR_LIST_MAX	/* NOT a literal: this is the `max` handed to
					 * MpCarListForCity, whose contract IS
					 * MP_CAR_LIST_MAX (mp.h). They must never
					 * drift -- the note above is a drift bug. */
#define MPCC_SLOTS	10		/* frontend slots per city (carNumLookup[city][0..9]) */

static int mpCcCities[MPCC_MAX_CITIES];
static int mpCcCityCount;
static int mpCcCityIdx;
static int mpCcModels[MPCC_MAX_CARS];
static int mpCcSlots[MPCC_MAX_CARS];	/* the slot each model came from, parallel to mpCcModels */
static int mpCcModelCount;
static int mpCcModelIdx;
static int mpCcLoggedCity = -1;	/* the city this picker last described */
static int mpCcLoggedCount = -1;	/* ...and how many slots it offered then */
static int mpCcLoggedCities = -1;	/* ...and how many CITIES its city row could cycle */

/* Which city the picker is showing: an index into mpCcCities. -1 (or an empty
 * list) means the session's own city. */
static int MpCcCity(void)
{
	if (mpCcCityCount <= 0)
		return gMp.city;

	if (mpCcCityIdx < 0 || mpCcCityIdx >= mpCcCityCount)
		mpCcCityIdx = 0;

	return mpCcCities[mpCcCityIdx];
}

/* Fill the roster for the currently selected city. Safe to call any time; called
 * when the page opens and after the city row changes. */
static void MpCcRebuild(void)
{
	int city, slot;

	/* The city list: carhacks' answer when it has one, else just the session
	 * city. Rebuilt every time so a carhacks set that lands mid-session shows up. */
	{
		int was = MpCcCity();
		int n;

		mpCcCityCount = 0;
		n = MpCarQueryCities(mpCcCities, MPCC_MAX_CITIES);

		if (n <= 0)
		{
			mpCcCities[0] = (gMp.city >= 0 && gMp.city < 4) ? gMp.city : 0;
			mpCcCityCount = 1;
			mpCcCityIdx = 0;
		}
		else
		{
			mpCcCityCount = (n > MPCC_MAX_CITIES) ? MPCC_MAX_CITIES : n;
			mpCcCityIdx = 0;

			/* keep showing the same city across a rebuild when we still can */
			for (slot = 0; slot < mpCcCityCount; slot++)
			{
				if (mpCcCities[slot] == was)
				{
					mpCcCityIdx = slot;
					break;
				}
			}
		}
	}

	city = MpCcCity();

	/* SAY WHICH CITIES THE ROW OFFERS, not just the one showing. "the picker only shows
	 * the host city" is a report this line answers directly: it names the list the row will
	 * cycle, so a run can tell a one-city list (nobody answered JER_CARQ_CITIES, or the car
	 * mods' roster hack is off) from the full one. Logged when it changes, like the roster
	 * line below, so a list that shrinks is as visible as one that grows. */
	if (mpCcLoggedCities != mpCcCityCount)
	{
		char names[192];
		int i;

		mpCcLoggedCities = mpCcCityCount;
		names[0] = 0;

		for (i = 0; i < mpCcCityCount; i++)
		{
			size_t used = strlen(names);

			if (used < sizeof(names) - 16)
				snprintf(names + used, sizeof(names) - used, "%s%s",
					(i > 0) ? " " : "", MpCarCityName(mpCcCities[i]));
		}

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] car select: %d city/cities on the row - %s\n",
				mpCcCityCount, (names[0] != 0) ? names : "(none)");
	}

	/* Ask the car mods, not the engine's table: in a session CarAvailability is still its
	 * initialiser (four cars a city), because the FRONTEND car screen is what writes it and
	 * -host/-join never opens that screen. MpCarListForCity asks the mods first and only
	 * falls back to that table when nobody answers. */
	mpCcModelCount = MpCarListForCity(city, mpCcSlots, mpCcModels, MPCC_MAX_CARS);

	/* EVERY CAR THE CITY HAS, loaded here or not.
	 *
	 * This used to be filtered down to what the level could build right now unless a
	 * session was running, on the reasoning that an unloaded pick could only be
	 * refused. It can't: choosing one IS the request that loads it -- MpChangeCar
	 * asks carhacks to import it, in single player exactly as in a session. So the
	 * filter never prevented a refusal, it removed the feature: out of a session every
	 * city listed nothing at all, which is what "no cars available" was. */

	/* What the picker had to leave out, logged when it changes - "I cannot pick that car" is
	 * the report this whole path exists to answer, and a silent skip is what made it need
	 * answering twice. It is computed from the roster that was actually built, so the line
	 * cannot claim something the menu does not show, whichever source answered. */
	if (mpCcLoggedCity != city || mpCcLoggedCount != mpCcModelCount)
	{
		char hidden[96];
		int h = 0;
		int seen[MPCC_SLOTS];

		mpCcLoggedCity = city;
		mpCcLoggedCount = mpCcModelCount;

		for (slot = 0; slot < MPCC_SLOTS; slot++)
			seen[slot] = 0;

		for (slot = 0; slot < mpCcModelCount; slot++)
		{
			if (mpCcSlots[slot] >= 0 && mpCcSlots[slot] < MPCC_SLOTS)
				seen[mpCcSlots[slot]] = 1;
		}

		strcpy(hidden, "; hidden:");

		for (slot = 0; slot < MPCC_SLOTS; slot++)
		{
			size_t used;

			if (seen[slot])
				continue;

			used = strlen(hidden);

			if (used < sizeof(hidden) - 16)
				snprintf(hidden + used, sizeof(hidden) - used, " [%d]", slot);

			h++;
		}

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] car select: %s offers %d of %d slot(s)%s%s\n",
				MpCarCityName(city), mpCcModelCount, MPCC_SLOTS, (h > 0) ? hidden : "",
				gMp.running ? "" : " (single player)");
	}

	if (mpCcModelIdx < 0 || mpCcModelIdx >= mpCcModelCount)
		mpCcModelIdx = 0;
}

static void MpCcLabelCity(void* ud, char* out, int max)
{
	(void)ud;
	snprintf(out, max, "City: %s", MpCarCityName(MpCcCity()));
}

static int MpCcAdjustCity(void* ud, int dir)
{
	(void)ud;

	if (mpCcCityCount > 0)
		mpCcCityIdx = (mpCcCityIdx + dir + mpCcCityCount) % mpCcCityCount;

	mpCcModelIdx = 0;
	MpCcRebuild();		/* the new city brings its own cars */

	return JER_PAUSE_QUIT_NONE;
}

static void MpCcLabelCar(void* ud, char* out, int max)
{
	(void)ud;

	if (mpCcModelCount <= 0)
	{
		snprintf(out, max, "Car: (no cars offered for this city)");
		return;
	}

	snprintf(out, max, "Car: %d/%d  (%s model %d)",
		mpCcModelIdx + 1, mpCcModelCount,
		MpCarCityName(MpCcCity()), mpCcModels[mpCcModelIdx]);
}

static int MpCcAdjustCar(void* ud, int dir)
{
	(void)ud;

	if (mpCcModelCount > 0)
		mpCcModelIdx = (mpCcModelIdx + dir + mpCcModelCount) % mpCcModelCount;

	return JER_PAUSE_QUIT_NONE;
}

static int MpCcApply(void* ud, int dir)
{
	(void)ud;
	(void)dir;

	if (mpCcModelCount <= 0)
		return JER_PAUSE_QUIT_NONE;

	MpChangeCar(MpCcCity(), mpCcModels[mpCcModelIdx]);

	return JER_PAUSE_QUIT_NONE;
}

/* PALETTE: the six colour variants every car's CLUT rows offer (civ_clut[..][..][0..5];
 * a variant a city never filled falls back to the base colours in CarClutLookup).
 * Applied to OUR car at once -- the owner's carstate carries ap.palette, so every
 * peer repaints it on the next packet -- and kept in defaultPlayerPalette, which the
 * next spawn (and the frontend car select) uses, and in mp.ini [mp] palette. */
#define MP_PALETTES	6

extern u_char defaultPlayerPalette;	/* main.c: the palette the player's car spawns in */

/* The car we are driving right now, or -1 (the menu is reachable before one exists). */
static int MpCcOwnCar(void)
{
	MP_PLAYER* me = MpLocalPlayer();

	if (me != NULL && me->carId >= 0 && me->carId < MAX_CARS)
		return me->carId;
	if (!gMp.running && player[0].playerCarId >= 0 && player[0].playerCarId < MAX_CARS)
		return player[0].playerCarId;
	return -1;
}

/* How many palettes the car SELECTED in the picker has (cars.h): the row describes
 * the car "Respawn as this car" would give you, so browsing City/Car updates it at
 * once. A Driver 1 car or a special has one, so it reads 1/1 there. */
static int MpCcPaletteCount(void)
{
	if (mpCcModelCount <= 0 || mpCcModelIdx < 0 || mpCcModelIdx >= mpCcModelCount)
	{
		int c = MpCcOwnCar();

		return (c >= 0) ? CarSlotPaletteCount(car_data[c].ap.model) : MP_PALETTES;
	}

	return CarModelPaletteCount(MpCcCity(), mpCcModels[mpCcModelIdx]);
}

/* Is the picker's selection the car we are driving? Then a palette change shows live. */
static int MpCcPickIsOwnCar(int c)
{
	if (c < 0 || mpCcModelCount <= 0 || mpCcModelIdx < 0 || mpCcModelIdx >= mpCcModelCount)
		return 0;

	return MpResidentSlotForCar(MpCcCity(), mpCcModels[mpCcModelIdx]) == car_data[c].ap.model;
}

/* The palette the row shows: the player's choice (defaultPlayerPalette) clamped to
 * what the selected car has -- the one "Respawn as this car" will paint it in. */
static int MpCcCurPalette(int n)
{
	int cur = (int)defaultPlayerPalette;

	return (cur >= 0 && cur < n) ? cur : 0;
}

static void MpCcLabelPalette(void* ud, char* out, int max)
{
	int n = MpCcPaletteCount();

	(void)ud;
	snprintf(out, max, "Palette: %d/%d", MpCcCurPalette(n) + 1, n);
}

static int MpCcAdjustPalette(void* ud, int dir)
{
	MP_PLAYER* me = MpLocalPlayer();
	int c = MpCcOwnCar(), n = MpCcPaletteCount();
	int pal = (MpCcCurPalette(n) + dir + n) % n;

	(void)ud;

	if (n <= 1)
		return JER_PAUSE_QUIT_NONE;	/* nothing to cycle on this car: keep the choice */

	defaultPlayerPalette = (u_char)pal;
	gMp.config.palette = pal;
	MpConfigSave();

	if (me != NULL)
		me->palette = pal;

	/* Live only on the car we drive, and only when it is the one selected; a palette
	 * for another car waits for "Respawn as this car". */
	if (MpCcPickIsOwnCar(c))
		car_data[c].ap.palette = (u_char)CarSlotClampPalette(car_data[c].ap.model, pal);

	return JER_PAUSE_QUIT_NONE;
}

/* Point the picker at the car we drive, so Vehicle Options opens on it (and its
 * palette) instead of the first city/car. Called once per pause open, never while
 * browsing. Not in a car (on foot, before a spawn) or a car the roster does not
 * list: leave the previous selection alone. */
static void MpCcSnapToOwnCar(void)
{
	int c = MpCcOwnCar(), slot, city, model, i;

	if (c < 0 || player[0].playerType != PLAYER_TYPE_CAR)
		return;

	slot = car_data[c].ap.model;

	if (slot < 0 || slot >= MAX_CAR_RESIDENT_MODELS)
		return;

	city = GetCarModelSourceCity(slot);
	if (city < 0)
		city = GameLevel;	/* the level's own car */
	model = residentCarModels[slot];

	for (i = 0; i < mpCcCityCount; i++)
	{
		if (mpCcCities[i] != city)
			continue;

		{
			int oldCity = mpCcCityIdx, oldModel = mpCcModelIdx, m;

			mpCcCityIdx = i;
			MpCcRebuild();		/* that city's roster */

			for (m = 0; m < mpCcModelCount; m++)
			{
				if (mpCcModels[m] == model)
				{
					mpCcModelIdx = m;
					/* the row shows the palette the car wears */
					defaultPlayerPalette = car_data[c].ap.palette;
					return;
				}
			}

			mpCcCityIdx = oldCity;	/* not offered: keep the previous pick */
			MpCcRebuild();
			mpCcModelIdx = oldModel;
			if (mpCcModelIdx < 0 || mpCcModelIdx >= mpCcModelCount)
				mpCcModelIdx = 0;
			return;
		}
	}
}

/* Defined with the player actions further down; the Change car submenu wants it
 * up here, where the CAR options live. */
static int MpOptRepair(void* ud, int dir);

static const JER_PAUSE_MENU_ITEM mpChangeCarItems[] =
{
	/* label, get_label, on_activate, userdata, submenu, adjust */
	{ NULL, MpCcLabelCity, MpCcAdjustCity, NULL, NULL, 1 },
	{ NULL, MpCcLabelCar, MpCcAdjustCar, NULL, NULL, 1 },
	{ NULL, MpCcLabelPalette, MpCcAdjustPalette, NULL, NULL, 1 },
	{ "Respawn as this car", NULL, MpCcApply, NULL, NULL, 0 },
	/* Repair belongs with the car, not under Player options: it is a car action and
	 * "Respawn as this car" next to it is the one that also MOVES you. */
	{ "Repair car", NULL, MpOptRepair, NULL, NULL, 0 },
	/* ...and so does clearing the wanted level: the pursuit follows the CAR, and
	 * this is the row a player looks for while a cop is on their bumper. It used to
	 * sit on the Multiplayer page, a submenu away from the car it is about. */
	{ "Clear felony", NULL, MpOptClearFelony, NULL, NULL, 0 },
};

/* A JER_PAUSE_MENU's item_count, taken FROM the array.
 *
 * The count is a separate field and the engine builds the submenu EAGERLY, so a
 * count larger than the array walks off its end -- the documented way opening the
 * Multiplayer page access-violates. Deriving it makes that unrepresentable rather
 * than something a later edit has to remember. */
#define MP_MENU_ITEMS(a)	(int)(sizeof(a) / sizeof((a)[0]))

static const JER_PAUSE_MENU mpChangeCarMenu =
{ "Vehicle Options", mpChangeCarItems, MP_MENU_ITEMS(mpChangeCarItems), "mp.car" };

static const JER_PAUSE_MENU_ITEM mpColorItems[] =
{
	/* label, get_label, on_activate, userdata, submenu, adjust */
	{ NULL, MpColorLabelOn, MpColorToggleOn, NULL, NULL, 0 },
	{ NULL, MpColorLabelR, MpColorAdjustR, NULL, NULL, 1 },
	{ NULL, MpColorLabelG, MpColorAdjustG, NULL, NULL, 1 },
	{ NULL, MpColorLabelB, MpColorAdjustB, NULL, NULL, 1 },
};

static const JER_PAUSE_MENU mpColorMenu =
{ "Player Color", mpColorItems, MP_MENU_ITEMS(mpColorItems), "mp.colour" };

static int MpOnPauseMenu(void* userdata, void* args)
{
	JER_ARGS_PAUSE_MENU* pm = (JER_ARGS_PAUSE_MENU*)args;

	(void)userdata;

	if (pm == NULL)
		return JER_RESULT_CONTINUE;

	/* Dying inside a session is a RESPAWN, not a game over. This is the engine asking
	 * whether to arm it, so the answer is the refusal itself: STOP leaves the pause
	 * unarmed and makes the engine drop the death fade, and by the time we answer the
	 * player is already back on the map. Refusing is the only half a module CAN do -
	 * the fade and the engine's WantPause are statics - which is why the hook exists. */
	if (pm->action == JER_PAUSE_GAMEOVER)
		return MpRespawnAfterDeath() ? JER_RESULT_STOP : JER_RESULT_CONTINUE;

	if (pm->action != JER_PAUSE_OPEN)
		return JER_RESULT_CONTINUE;

	/* While the chat prompt is up, START is the player typing RETURN -- claim it,
	 * so the engine pause does not open over the prompt. */
	if (gMp.chatOpen)
		return JER_RESULT_STOP;

	if (!gMp.running)
	{
		/* SINGLE PLAYER: there is no session and no world of ours to keep running,
		 * but the Change car page is the SAME page (it is registered
		 * unconditionally) and its roster needs the same refresh -- the city list is
		 * carhacks' answer, which may have changed since the menu was last opened. */
		MpCcRebuild();
		MpCcSnapToOwnCar();

		return JER_RESULT_CONTINUE;
	}

	/* Let the ENGINE open its pause menu -- do not claim START. The world keeps
	 * running because MpOnDrawOverlay steps it while paused, and our player list
	 * (and MP options) ride on top of the menu the player expects to see.
	 *
	 * Record that it is OUR pause that is opening: the player list is gated on this
	 * plus gDrawPauseMenus, so the other pause-MODE screens (game over, mission
	 * complete, pad error) and cutscenes cannot put it on screen. */
	gMpPauseOpened = 1;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx,
			"[mp] pause menu opened; the world keeps running\n");

	/* Refresh the Change car picker now, not while it is being drawn: the roster
	 * reads the city list (which a carhacks set may have changed since the last
	 * time the menu was opened) and the city's frontend car list. */
	MpCcRebuild();
	MpCcSnapToOwnCar();

	return JER_RESULT_CONTINUE;
}

static int MpOnPreSim(void* userdata, void* args)
{
	(void)userdata;
	(void)args;

	/* MP_DEBUG: is this hook still being called at all? A session whose sim silently
	 * stops here looks alive (polls continue on the FRAME hook, remote cars keep
	 * being adopted) while nothing owns a car any more. */
	if (MpDebugOn() && gMpCtx != NULL && (gMp.frame % 120) == 0)
		gMpCtx->jer_log(gMpCtx,
			"[mp] presim: frame %lu running %d connected %d frontend %d\n",
			gMp.frame, gMp.running, gMp.connected, gInFrontend);

	if (gMp.running)
		MpLockstepFrame();
	else if (gMp.listenersUp || gMp.connected)
		MpNetPoll(0);

	return JER_RESULT_CONTINUE;
}


/* Apply each player car's input. Our own car may be driven by the test bot
 * (mp_bot.c); a remote car gets the pad its owner replicated. */
static int MpOnNetInput(void* userdata, void* args)
{
	JER_ARGS_NET_INPUT* in = (JER_ARGS_NET_INPUT*)args;
	MP_PLAYER* p;
	int carId;

	(void)userdata;

	if (!gMp.running)
		return JER_RESULT_CONTINUE;

	carId = (int)((CAR_DATA*)in->car - car_data);
	p = MpGetPlayerByCar(carId);

	if (p != NULL)
	{
		if (p->isLocal)
		{
			if (pauseflag != 0)
			{
				/* The pause menu owns the pad: swallow it so navigating the menu
				 * (D-pad / buttons) never reaches the car. The engine keeps
				 * running StepSim while mp pauses (see MpOnPauseMenu, below) and
				 * re-reads the pad with no pause guard, so zero it and mark it
				 * handled rather than letting the stock pad leak through. */
				in->pad = 0;
				in->handled = 1;
			}
			else if (gMp.chatOpen)
			{
				/* ...and the CHAT PROMPT owns the keyboard: the pad is built from the
				 * raw keyboard state (PsyX_pad.cpp), so every letter typed into a
				 * line is also a pad button -- typing "wasd" steered and
				 * accelerated the car under the player. Swallow our own pad for as
				 * long as the prompt is up, exactly as the pause menu does. */
				in->pad = 0;
				in->handled = 1;
			}
			else if (MpBotEnabled())
			{
				if ((gMp.frame % 60) == 0 && gMpCtx != NULL)
				{
					CAR_DATA* me = &car_data[carId];
					gMpCtx->jer_log(gMpCtx,
						"[mp] both: local %d,%d,%d spd=%d | remote(1) %d,%d,%d spd=%d\n",
						me->hd.where.t[0], me->hd.where.t[1], me->hd.where.t[2], me->hd.speed,
						car_data[1].hd.where.t[0], car_data[1].hd.where.t[1], car_data[1].hd.where.t[2], car_data[1].hd.speed);
				}

				in->pad = MpBotPadForLocalCar();		/* the test bot drives OUR car (mp_bot.c) */
				in->handled = 1;
			}

			/* Whatever is driving our car -- the player's pad or the test bot's --
			 * is what we replicate. See MpLocalPad. */
			MpNoteLocalPad(in->pad);
		}
		else if (!p->isLocal)
		{
			/* The owner's per-frame state is authoritative and is ADOPTED in
			 * MpHandleCarState, so the engine must not also drive this car from a
			 * replicated pad -- the two would fight. Replicated input is kept only
			 * as a FALLBACK for a snapshot gap: if we have not adopted this car for
			 * a while, let the engine carry it on the input we last had, so a brief
			 * stall coasts instead of freezing. */
			if (gMp.frame - p->lastStateFrame > MP_INPUT_FALLBACK_FRAMES)
			{
				in->pad = MpInputForPlayer(p->id);
				in->handled = 1;

				if (MpDebugOn() && (gMp.frame % 60) == 0 && gMpCtx != NULL)
					gMpCtx->jer_log(gMpCtx, "[mp] netinput: car %d <- player %d pad %#x (fallback)\n",
						carId, p->id, in->pad);
			}
			else
			{
				in->pad = 0;	/* adopted this frame: hands off, let the owner win */
				in->handled = 1;
			}
		}
		/* local car, no bot: leave the stock pad (handled stays 0) */
	}
	else if ((gMp.frame % 300) == 0 && gMpCtx != NULL)
	{
		gMpCtx->jer_log(gMpCtx, "[mp] netinput: car %d has no player row\n", carId);
	}

	return JER_RESULT_CONTINUE;
}

/* Drive OUR OWN PEDESTRIAN with the test bot, exactly as MpOnNetInput drives our
 * car: JER_EVENT_PED_INPUT fires right before ProcessTannerPad, so writing the
 * pad here IS a pad press. It exists because the on-foot path otherwise has no
 * motion at all in a headless run -- a Tanner standing at the spawn point tests
 * the messages, not the walking, and a peer's stand-in is only ever seen
 * standing still. */
/* The pause menu's ANSWER, in a live match.
 *
 * JERICHO hands a module the action before the engine runs it (JER_EVENT_GAME_QUIT,
 * fired in main.c), and that hook is what makes a multiplayer Restart possible at
 * all: the stock one calls EndGame(GAMEMODE_RESTART) and rebuilds the level, which
 * in a match takes every OTHER player's session down with it -- one player's
 * "restart" is not theirs to do to everyone.
 *
 * So mp CLAIMS restart and turns it into a RESPAWN instead: the engine's main
 * pause menu relabels that item "Respawn" (gJerPauseRestartAsRespawn), and here the
 * claimed restart becomes "back onto the nearest road, repaired" rather than the
 * soft reset -- one player's restart must not rebuild the level under everyone.
 * Claiming means the engine runs none of its endings, so we also unpause -- the
 * pause menu has already closed itself by the time this fires.
 *
 * Quit and the rest of the codes are left alone: leaving the match is a real thing
 * a player should be able to do from the menu. */
static int MpOnGameQuit(void* userdata, void* args)
{
	JER_ARGS_GAME_QUIT* q = (JER_ARGS_GAME_QUIT*)args;

	(void)userdata;

	if (q == NULL || !gMp.running)
		return JER_RESULT_CONTINUE;

	/* The JER_PAUSE_QUIT_* values mirror the engine's menu quit codes
	 * (jer_pause_menu.h), and this event carries the engine's. */
	if (q->code != JER_PAUSE_QUIT_RESTART)
		return JER_RESULT_CONTINUE;

	if (!MpRespawnOnRoad())
		return JER_RESULT_CONTINUE;

	pauseflag = 0;
	UnPauseSound();

	return JER_RESULT_STOP;
}

/* Back in the menus FROM A MATCH (JER_EVENT_FRONTEND_ENTERED, glaunch.c): the
 * session is over for this machine, whoever we were in it.
 *
 * Only the HOST had a teardown for this (MpHostLeftMatch, polled per frame). A
 * CLIENT that chose Quit in the pause menu (MpOnGameQuit leaves Quit to the
 * engine) came back to the main menu still role CLIENT and still running, so
 * the next single-player Take a Ride was not single player: the city confirm
 * skipped the Single Player / Multiplayer question (it is gated on !running)
 * and MpOnMpFrontend's client branch claimed START -- rejoining the old session
 * or failing with "Not connected to a server" -- instead of the stock launch.
 * Leave the session here, and reset the map shape the mode question writes so
 * a later session starts from the full city. NumPlayers is left to the stock
 * frontend, which sets it per path. */
static int MpOnFrontendEntered(void* userdata, void* args)
{
	(void)userdata;
	(void)args;

	if (gMp.role == MP_ROLE_NONE || !gMp.running)
		return JER_RESULT_CONTINUE;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] back in the frontend from a match - leaving the session (role %d)\n",
			(int)gMp.role);

	if (gMp.role == MP_ROLE_HOST)
		MpHostByeAll();

	MpLeaveSession();	/* a client says its own bye in here */
	MpSetMapShape(0, 0);

	return JER_RESULT_CONTINUE;
}

static int MpOnPedInput(void* userdata, void* args)
{
	JER_ARGS_PED_INPUT* in = (JER_ARGS_PED_INPUT*)args;

	(void)userdata;

	if (in == NULL || !gMp.running)
		return JER_RESULT_CONTINUE;

	/* The pause menu owns the pad while it is up: hold the ped still too, so
	 * menu navigation never walks the player. The chat prompt owns the KEYBOARD the
	 * same way -- the ped pad comes from the same raw keyboard state -- so typing a
	 * line must not walk us either. (No `handled` field on this hook, so zeroing
	 * the bits is the swallow.) */
	if ((pauseflag != 0 || gMp.chatOpen) && (PLAYER*)in->player == &player[0])
	{
		in->pad = 0;
		return JER_RESULT_CONTINUE;
	}

	if (!MpBotEnabled())
		return JER_RESULT_CONTINUE;

	/* Only OUR player's pad. player[0] is always us -- every machine runs its one
	 * local player in engine slot 0 and the remote players live in the higher
	 * slots the module inits (see MpFollowLocalCar). */
	if ((PLAYER*)in->player != &player[0])
		return JER_RESULT_CONTINUE;

	in->pad = MpBotTannerPad();

	return JER_RESULT_CONTINUE;
}

/* After a level starts, log the player cars so the spawn is verifiable. */
/* JERICHO-HOOK: the frontend's idle timer.
 *
 * The frontend boots the attract demo after ~30 s without input, and a host
 * sitting in its lobby waiting for players is idle by definition. The demo
 * launched a level nobody asked for; that load blocks the main thread for its
 * whole duration, so every player who was joining went quiet, hit the idle
 * timeout and dropped -- leaving the host alone in a demo it never asked for.
 *
 * Suppress it for as long as a session or a lobby exists. role is NONE for stock
 * single-player and for the stock split-screen path, which keep their demo. */
static int MpOnFrontendIdle(void* userdata, void* args)
{
	JER_ARGS_FRONTEND_IDLE* idle = (JER_ARGS_FRONTEND_IDLE*)args;

	(void)userdata;

	if (idle != NULL && gMp.role != MP_ROLE_NONE)
		idle->suppress = 1;

	return JER_RESULT_CONTINUE;
}

/* JERICHO-HOOK: the frontend has drawn the current screen.
 *
 * The one place a module can put text ON a menu row: JER_EVENT_FRAME fires
 * before DrawScreen, so anything drawn there is covered by the menu box. Both
 * server browsers draw their table here. */
static int MpOnFrontendDraw(void* userdata, void* args)
{
	(void)userdata;
	(void)args;

	MpUiDrawOnline();	/* the discovery server's list */
	MpUiDrawJoin();		/* the LAN beacons' list */

	return JER_RESULT_CONTINUE;
}

/* JERICHO-HOOK: the multiplayer map.
 *
 * The blips live in mp_map.c (MpOnDrawMap) -- this file only registers it. The
 * engine's own drawer holds NumPlayers at 1 in a session, so its loop plots our
 * own car and nobody else's; the module adds the other players.
 *
 * Note the two engine externs that used to sit here are gone with the code that
 * moved: in particular WorldToMultiplayerMap is NOT the transform to use for the
 * single-player map (it returns a constant when region == 0 -- see mp_map.c). */


static int MpOnGameStart(void* userdata, void* args)
{
	int i;

	(void)userdata;
	(void)args;

	if (!MpIsActive() || gMpCtx == NULL)
		return JER_RESULT_CONTINUE;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		MP_PLAYER* p = &gMp.players[i];
		CAR_DATA* cp;

		if (!p->active || p->carId < 0 || p->carId >= MAX_CARS)
			continue;

		cp = &car_data[p->carId];
		gMpCtx->jer_log(gMpCtx, "[mp] car: player %d slot %d controlType=%d apmodel=%d carmodel=%d want=%d loaded=%d pos=%d,%d,%d\n",
			p->id, p->carId, cp->controlType, cp->ap.model,
			(cp->ap.model >= 0 && cp->ap.model < MAX_CAR_RESIDENT_MODELS) ? residentCarModels[cp->ap.model] : -1,
			(p->carId < MP_MAX_PLAYERS && PlayerStartInfo[p->carId] != NULL) ? PlayerStartInfo[p->carId]->model : -9,
			JerCarSlotUsable(cp->ap.model) ? 1 : 0,
			cp->hd.where.t[0], cp->hd.where.t[1], cp->hd.where.t[2]);
	}

	/* The host used to broadcast a "meeting point" ('JPSW') here and every
	 * machine lined up on it. RETIRED: both machines already place both cars at
	 * the engine's own deterministic spawn, and a client gathers itself beside
	 * the host in MpHandleCarState (see ARCHITECTURE section 4). */

	return JER_RESULT_CONTINUE;
}

/* Diagnostics: log inbound addon-bridge payloads when MP_DEBUG is set. */
static int MpOnNetRecv(void* userdata, void* args)
{
	JER_ARGS_NET_RECV* r = (JER_ARGS_NET_RECV*)args;

	(void)userdata;

	if (MpDebugOn() && gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] bridge recv '%s' from peer %d (%d bytes)\n",
			(r->channel != NULL) ? r->channel : "?", r->peer, r->len);

	return JER_RESULT_CONTINUE;
}

/* The level-launch hook: apply the host's time of day and weather. */
static int MpOnLevelLaunch(void* userdata, void* args)
{
	JER_ARGS_LEVEL_LAUNCH* l = (JER_ARGS_LEVEL_LAUNCH*)args;

	(void)userdata;

	if (MpIsActive())
	{
		/* Only override when the SESSION actually has a value. The engine seeds
		 * these args from the frontend's own picks (-1 = "mission default"), so
		 * writing -1 blindly would erase the host's choice on the Time of Day
		 * screen and drop the launch to the mission default. */
		if (gMp.timeOfDay >= 0)
			l->timeOfDay = gMp.timeOfDay;
		if (gMp.weather >= 0)
			l->weather = gMp.weather;
	}

	return JER_RESULT_CONTINUE;
}

/* ------------------------------------------------------------------ */
/* Kick player: a target cycler + a confirm row, the same shape as the Change
 * car page. HOST ONLY -- on a client both rows say so and do nothing, because
 * only the host owns the connection table (and MpKickPlayer is a no-op there
 * anyway; the menu says it rather than looking broken). The confirm row IS the
 * confirmation screen: a kick takes a deliberate second press on a row that
 * names who is about to go. */
static int mpKickTarget = -1;	/* registry row of the selected target, or -1 */

/* The next kickable row from `from` in `dir`: a connected player that is not us
 * and not the host. Walks the registry, so a player who leaves drops out of the
 * cycle by himself. */
static int MpKickNext(int from, int dir)
{
	int i;

	for (i = 1; i <= MP_MAX_PLAYERS; i++)
	{
		int idx = (from + dir * i + MP_MAX_PLAYERS * 2) % MP_MAX_PLAYERS;

		if (gMp.players[idx].active && gMp.players[idx].connected &&
			!gMp.players[idx].isHost && !gMp.players[idx].isLocal)
			return idx;
	}

	return -1;
}

/* The effective target, repairing a stale/never-set one. */
static int MpKickCurrent(void)
{
	if (!MpIsHost())
		return -1;

	if (mpKickTarget < 0 || mpKickTarget >= MP_MAX_PLAYERS ||
		!gMp.players[mpKickTarget].active || !gMp.players[mpKickTarget].connected)
		mpKickTarget = MpKickNext(MP_MAX_PLAYERS - 1, 1);

	return mpKickTarget;
}

static const char* MpKickName(int idx)
{
	return (idx >= 0 && gMp.players[idx].name[0] != '\0') ? gMp.players[idx].name : "?";
}

static void MpKickLabelTarget(void* ud, char* out, int max)
{
	int t = MpKickCurrent();

	(void)ud;

	if (!MpIsHost())
		snprintf(out, max, "Kick: (host only)");
	else if (t < 0)
		snprintf(out, max, "Kick: (no other players)");
	else
		snprintf(out, max, "Kick: %s", MpKickName(t));
}

static int MpKickAdjust(void* ud, int dir)
{
	int t = MpKickCurrent();

	(void)ud;

	if (t >= 0)
		mpKickTarget = MpKickNext(t, dir);

	return JER_PAUSE_QUIT_NONE;
}

static void MpKickLabelConfirm(void* ud, char* out, int max)
{
	int t = MpKickCurrent();

	(void)ud;

	if (!MpIsHost())
		snprintf(out, max, "Confirm kick (host only)");
	else if (t < 0)
		snprintf(out, max, "Confirm kick (nobody selected)");
	else
		snprintf(out, max, "Confirm kick %s", MpKickName(t));
}

static int MpKickConfirm(void* ud, int dir)
{
	int t = MpKickCurrent();

	(void)ud;
	(void)dir;

	if (t >= 0)
		MpKickPlayer(gMp.players[t].id);

	return JER_PAUSE_QUIT_NONE;
}

static const JER_PAUSE_MENU_ITEM mpKickItems[] =
{
	/* label, get_label, on_activate, userdata, submenu, adjust */
	{ NULL, MpKickLabelTarget, MpKickAdjust, NULL, NULL, 1 },
	{ NULL, MpKickLabelConfirm, MpKickConfirm, NULL, NULL, 0 },
};

static const JER_PAUSE_MENU mpKickMenu =
{ "Kick player", mpKickItems, MP_MENU_ITEMS(mpKickItems), "mp.kick" };

/* ------------------------------------------------------------------ */
/* Warp to Player: put this machine's car down near another player's, out of the
 * path they are committed to. The PLACEMENT is mp_session.c's -- it needs
 * InitCarPhysics, MapHeight and the spool call, which all live with the respawn
 * -- so all this file owns is the picker. */
static int gWarpTarget;		/* which OTHER player the row is pointing at */

static int MpWarpCount(void)
{
	int i, n = 0;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		MP_PLAYER* p = &gMp.players[i];

		if (p->active && p->id != gMp.localPlayerId)
			n++;
	}

	return n;
}

static MP_PLAYER* MpWarpPlayerAt(int index)
{
	int i, n = 0;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		MP_PLAYER* p = &gMp.players[i];

		if (!p->active || p->id == gMp.localPlayerId)
			continue;

		if (n == index)
			return p;

		n++;
	}

	return NULL;
}

/* The list is rebuilt every time it is READ rather than kept as state: a player who
 * leaves while the menu is open changes it, and an index into a stale list is how
 * a menu sends you to somebody who is no longer in the match. */
static void MpWarpLabelTarget(void* ud, char* out, int max)
{
	int n = MpWarpCount();
	MP_PLAYER* p;

	(void)ud;

	if (n == 0)
	{
		snprintf(out, max, "Target: (nobody else is here)");
		return;
	}

	if (gWarpTarget < 0 || gWarpTarget >= n)
		gWarpTarget = 0;

	p = MpWarpPlayerAt(gWarpTarget);

	snprintf(out, max, "Target: %s", (p != NULL) ? p->name : "?");
}

static int MpWarpAdjustTarget(void* ud, int dir)
{
	int n = MpWarpCount();

	(void)ud;

	if (n > 0)
		gWarpTarget = ((gWarpTarget + dir) % n + n) % n;

	return JER_PAUSE_QUIT_NONE;
}

static int MpWarpGo(void* ud, int dir)
{
	int n = MpWarpCount();
	MP_PLAYER* p;

	(void)ud;
	(void)dir;

	if (n == 0)
	{
		MpNotify("Warp: nobody else is in the match");
		return JER_PAUSE_QUIT_NONE;
	}

	if (gWarpTarget < 0 || gWarpTarget >= n)
		gWarpTarget = 0;

	p = MpWarpPlayerAt(gWarpTarget);

	if (p != NULL)
		MpWarpToPlayer(p->id);

	return JER_PAUSE_QUIT_NONE;
}

static const JER_PAUSE_MENU_ITEM mpWarpItems[] =
{
	/* label, get_label, on_activate, userdata, submenu, adjust */
	{ NULL, MpWarpLabelTarget, MpWarpAdjustTarget, NULL, NULL, 1 },
	{ "Warp to this player", NULL, MpWarpGo, NULL, NULL, 0 },
};

static const JER_PAUSE_MENU mpWarpMenu =
{ "Warp to Player", mpWarpItems, MP_MENU_ITEMS(mpWarpItems), "mp.warp" };

/* ------------------------------------------------------------------ */
/* The local player's own switches: the same engine flags the host's SESSION RULES
 * drive (gInvincibleCar / gPlayerImmune), for whoever is sitting at THIS machine,
 * plus two one-shot engine repairs. Deliberately NOT synced -- invincibility
 * belongs to the person at this keyboard, and the car/health the one-shots touch
 * is this machine's own.
 *
 * Note the two overlap on purpose: a host that turns a rule ON for the session
 * has it in force for everyone (MpSessionRulesTick forces it), while a host that
 * leaves it OFF is leaving it to each player's own switch here. That is why they
 * are on the top-level page and not one click deeper. */
/* The Respawn row: back onto the nearest road, repaired and upright. The work is
 * mp_session.c's -- it needs InitCarPhysics, MapHeight and the spool call, which
 * all live with the respawn and the warp -- so this file owns only the door. */
static int MpRespawn(void* ud, int dir)
{
	(void)ud;
	(void)dir;

	MpRespawnOnRoad();

	return JER_PAUSE_QUIT_NONE;
}

static void MpOptLabelInvincible(void* ud, char* out, int max)
{
	(void)ud;
	snprintf(out, max, "Invincibility: %s", gInvincibleCar ? "ON" : "off");
}

static int MpOptToggleInvincible(void* ud, int dir)
{
	(void)ud;
	(void)dir;

	gInvincibleCar ^= 1;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] player option: invincible car %s\n",
			gInvincibleCar ? "ON" : "off");

	return JER_PAUSE_QUIT_NONE;
}

static void MpOptLabelImmune(void* ud, char* out, int max)
{
	(void)ud;
	snprintf(out, max, "Immunity: %s", gPlayerImmune ? "ON" : "off");
}

static int MpOptToggleImmune(void* ud, int dir)
{
	(void)ud;
	(void)dir;

	gPlayerImmune ^= 1;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] player option: player immunity %s\n",
			gPlayerImmune ? "ON" : "off");

	return JER_PAUSE_QUIT_NONE;
}

static int MpOptRepair(void* ud, int dir)
{
	(void)ud;
	(void)dir;

	MpSelfRepairCar();

	return JER_PAUSE_QUIT_NONE;
}

static int MpOptClearFelony(void* ud, int dir)
{
	(void)ud;
	(void)dir;

	MpSelfClearFelony();

	return JER_PAUSE_QUIT_NONE;
}

/* Reload every car: carhacks' own per-slot rebuild (the one its verifier uses),
 * over every slot; a slot that is not an import returns 0 and is left as it is. */
int chkImportHotLoad(int slot);	/* carhacks/carimport.h */

static int MpMenuReloadCars(void* ud, int dir)
{
	int slot, n = 0;

	(void)ud; (void)dir;

	for (slot = 0; slot < 11; slot++)	/* CHK_IMPORT_MAX_SLOTS */
		if (chkImportHotLoad(slot) > 0)
			n++;

	printInfo("[mp] Reload all cars: %d slot(s) rebuilt\n", n);
	return 0;
}

static const JER_PAUSE_MENU_ITEM mpPauseItems[] =
{
	/* label, get_label, on_activate, userdata, submenu, adjust */

	/* Most used first: the car, then Respawn (second, so a stray press on the
	 * top row does not respawn you), going to somebody and their own colour;
	 * the two switches after those, and the admin/debug rows (kick,
	 * diagnostics) last. */
	{ "Vehicle Options", NULL, NULL, NULL, &mpChangeCarMenu, 0 },
	{ "Respawn", NULL, MpRespawn, NULL, NULL, 0 },
	{ "Warp To Player", NULL, NULL, NULL, &mpWarpMenu, 0 },
	{ "Player Color", NULL, NULL, NULL, &mpColorMenu, 0 },
	{ NULL, MpOptLabelInvincible, MpOptToggleInvincible, NULL, NULL, 0 },
	{ NULL, MpOptLabelImmune, MpOptToggleImmune, NULL, NULL, 0 },
	{ "Kick player", NULL, NULL, NULL, &mpKickMenu, 0 },
	{ "Reload all cars", NULL, MpMenuReloadCars, NULL, NULL, 0 },
	{ "Write diagnostics now", NULL, MpMenuWriteDiag, NULL, NULL, 0 },
};

static const JER_PAUSE_MENU mpPauseMenu =
{ "Multiplayer", mpPauseItems, MP_MENU_ITEMS(mpPauseItems), "mp.page" };

/* DEPTH PROOF, for the test harness: MP_DEEP_MENU=1 registers a page whose tree
 * nests one level PAST the bridge's cap, so the refusal path can be SEEN in a log
 * instead of reasoned about. Nothing is registered without the variable, so a
 * normal run carries these tables unused.
 *
 * A seven-level chain against a cap of five: levels 0..5 build and level 6 is the
 * one that is refused, which is exactly the boundary worth pinning -- an off-by-one
 * there would let a menu the navigation stack cannot hold be built. */
#define MP_DEEP_LEVELS 7

static const JER_PAUSE_MENU_ITEM kDeepItems6[] =
{
	{ "the last level", NULL, NULL, NULL, NULL, 0 },
};
static const JER_PAUSE_MENU kDeepMenu6 = { "Deep 6", kDeepItems6, MP_MENU_ITEMS(kDeepItems6) };

static const JER_PAUSE_MENU_ITEM kDeepItems5[] =
{
	{ "deeper", NULL, NULL, NULL, &kDeepMenu6, 0 },
};
static const JER_PAUSE_MENU kDeepMenu5 = { "Deep 5", kDeepItems5, MP_MENU_ITEMS(kDeepItems5) };

static const JER_PAUSE_MENU_ITEM kDeepItems4[] =
{
	{ "deeper", NULL, NULL, NULL, &kDeepMenu5, 0 },
};
static const JER_PAUSE_MENU kDeepMenu4 = { "Deep 4", kDeepItems4, MP_MENU_ITEMS(kDeepItems4) };

static const JER_PAUSE_MENU_ITEM kDeepItems3[] =
{
	{ "deeper", NULL, NULL, NULL, &kDeepMenu4, 0 },
};
static const JER_PAUSE_MENU kDeepMenu3 = { "Deep 3", kDeepItems3, MP_MENU_ITEMS(kDeepItems3) };

static const JER_PAUSE_MENU_ITEM kDeepItems2[] =
{
	{ "deeper", NULL, NULL, NULL, &kDeepMenu3, 0 },
};
static const JER_PAUSE_MENU kDeepMenu2 = { "Deep 2", kDeepItems2, MP_MENU_ITEMS(kDeepItems2) };

static const JER_PAUSE_MENU_ITEM kDeepItems1[] =
{
	{ "deeper", NULL, NULL, NULL, &kDeepMenu2, 0 },
};
static const JER_PAUSE_MENU kDeepMenu1 = { "Deep 1", kDeepItems1, MP_MENU_ITEMS(kDeepItems1) };

static const JER_PAUSE_MENU_ITEM kDeepItems0[] =
{
	{ "MP_DEEP_MENU: nest past the cap", NULL, NULL, NULL, &kDeepMenu1, 0 },
};
static const JER_PAUSE_MENU kDeepMenu0 = { "Deep 0", kDeepItems0, MP_MENU_ITEMS(kDeepItems0) };

JER_MODULE_ENTRY(jer_module_mp_entry)(JERICHO_CONTEXT* ctx)
{
	gMpCtx = ctx;

	/* No crash DIALOGS, process-wide.
	 *
	 * The engine already writes JERICHO.dmp when it faults, which is the useful
	 * part. What it also does is let Windows raise a modal "has stopped working"
	 * box -- and that box blocks the process from exiting. On a machine testing
	 * over the network that is worse than useless: the crash looks like a hang,
	 * anything waiting on the process waits forever, and a run that was supposed
	 * to be unattended needs a human to click OK. Same dump, no dialog. */
	MpSuppressCrashDialogs();

	ctx->jer_register_module(ctx, "mp", "Multiplayer", "0.1.0", "JERICHO",
		"LAN multiplayer: host/join, UDP discovery, JERICHO addon net bridge, "
		"owner-authoritative car sync (each machine drives its own car and "
		"broadcasts its state; peers adopt it verbatim), and in-match chat.",
		"", JERICHO_SDK_VERSION);

	memset(&gMp, 0, sizeof(gMp));
	gMp.role = MP_ROLE_NONE;
	gMp.localPlayerId = 0;

	MpConfigLoad();
	MpResetPlayers();

	/* Resolve the discovery server ONCE, at activation. MpOnlineSetMaster runs
	 * getaddrinfo, which blocks -- and this is the one moment where that is
	 * affordable (module activation, behind a loading screen, once). The browser
	 * re-resolves on entry when the address has changed, but a HOST never opens
	 * the browser, and without this a host had no master to advertise on at all:
	 * every session was LAN-only however the config was set. */
	if (gMp.config.masterUrl[0] != 0)
		MpOnlineSetMaster(gMp.config.masterUrl);

	MpUiInit();		/* register the native frontend menus */

	ctx->jer_register_hook(ctx, JER_EVENT_BOOT, MpOnBoot, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_SHUTDOWN, MpOnShutdown, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_FRAME, MpOnFrame, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_DRAW_OVERLAY, MpUiDrawOverlay, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_DRAW_OVERLAY, MpOnDrawOverlay, NULL, 10);
	ctx->jer_register_hook(ctx, JER_EVENT_CAR_DRAW_COLOR, MpOnCarDrawColor, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_MP_FRONTEND, MpOnMpFrontend, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_FRONTEND, MpOnFrontendConfirm, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_CMDLINE, MpOnCmdLine, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_PRE_SIM, MpOnPreSim, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_NET_RECV, MpOnNetRecv, NULL, 100);
	ctx->jer_register_hook(ctx, JER_EVENT_LEVEL_LAUNCH, MpOnLevelLaunch, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_NET_SPAWN, MpOnNetSpawn, NULL, 0);
	/* The engine's OWN car-to-car contact. Registered here (and not read from a
	 * proximity probe on some later frame) because this fires while the pair's
	 * pre-impact velocities are still in place, which is the only moment the
	 * closing speed can be read before our own engine absorbs it. */
	ctx->jer_register_hook(ctx, JER_EVENT_COLLISION, MpOnCarContact, NULL, 0);
	/* The resident car models: a match asks for enough distinct cars to seat every
	 * player. Registered at the default priority -- nothing else here competes for
	 * the level's spare resident slots. */
	ctx->jer_register_hook(ctx, JER_EVENT_CAR_DATA_SOURCE, MpOnCarDataSource, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_NET_INPUT, MpOnNetInput, NULL, 0);
	/* The same bot, for the on-foot player: JER_EVENT_PED_INPUT is the car's
	 * NET_INPUT for Tanner (the engine fires it right before ProcessTannerPad). */
	ctx->jer_register_hook(ctx, JER_EVENT_PED_INPUT, MpOnPedInput, NULL, 0);
	/* The pause menu's action, before the engine runs it: a live match turns
	 * Restart into a soft reset rather than a level reload (see MpOnGameQuit). */
	ctx->jer_register_hook(ctx, JER_EVENT_GAME_QUIT, MpOnGameQuit, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_GAME_START, MpOnGameStart, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_DRAW_MAP, MpOnDrawMap, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_FRONTEND_IDLE, MpOnFrontendIdle, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_FRONTEND_ENTERED, MpOnFrontendEntered, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_FRONTEND_DRAW, MpOnFrontendDraw, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_PAUSE_MENU, MpOnPauseMenu, NULL, 0);

	/* A player's own character, in their own colour -- as a DEFAULT. Priority
	 * -1000 makes us run FIRST among the ped-palette consumers, so mp selects a
	 * player's preferred colour and any mod that selects afterwards (at a normal
	 * priority) wins for the characters it claims. mp carries a preference, not a
	 * last word. */
	ctx->jer_register_hook(ctx, JER_EVENT_PED_DRAW, MpOnPedDraw, NULL, -1000);

	/* Our own page in the pause screen ("Modules" -> "Multiplayer"). NOTE: the
	 * declared item_count must equal the array length -- the engine builds the
	 * submenu eagerly, so a count that is too large reads past the end. */
	jer_pause_menu_register(&mpPauseMenu);

	/* The depth proof rides along only when asked for (see kDeepMenu0). */
	if (getenv("MP_DEEP_MENU") != NULL)
		jer_pause_menu_register(&kDeepMenu0);
}
