# JerAI — a general-purpose AI driver for the player's car

A COMPILED-IN (deep) JERICHO module that takes the player's car and drives it
with **A\* pathfinding over an engine occupancy grid**, a modular set of
behaviors (joyride/random-wander first), **in-game debug visualization** and a
small **control menu**.

It is compiled into the exe (no `runtime = "dll"` in `mod.toml`) because it uses
the engine's **compiled-in** road graph (`JerRoadInfoAt`) and the depth-sorted
world line (`Debug_AddLineDepth`), and reads/writes the car and player data
globals directly — the same reason the `mp` module (which the AI search code is
lifted from) is compiled in.

## How it drives

The car stays **the player's own car** (`CONTROL_TYPE_PLAYER`). JerAI produces a
`CAR_PAD_*` bitmask each frame and hands it to the engine through
`JER_EVENT_CAR_PAD`, so the engine's normal input path turns it into pedals and
steering — the same approach `mp`'s bot uses.

Two engine details that cost real time and are load-bearing:

- the injected pad must set `useAnalogue = 0`; steering from `CAR_PAD_LEFT/RIGHT`
  is only read when the analogue flag is clear (`handling.c`), so leaving the
  physical pad's flag set gives a car that accelerates but never turns;
- **`CAR_PAD_LEFT` DECREASES the heading.** `diff = want - dir`, so a positive
  error needs `CAR_PAD_RIGHT`. Getting this backwards makes the car steer away
  from its target, wind the error up to +/-180 deg and U-turn - which reads as
  "it keeps turning the wrong way";
- `CAR_PAD_HANDBRAKE` must never be emitted as a **pad bit**: the stock handler
  cycles `g_PlayerControlMode` on a handbrake press edge and would hand the car
  back to the engine AI. The wall-evasion handbrake below is applied through the
  `JER_EVENT_CAR_PAD` `handled` path instead (writing `cp->handbrake` with
  `handled = 1` skips the stock block, so the mode is never touched).

Driving is governed by:

- **pure-pursuit** path tracking: the car is projected onto the plan polyline and
  aims a distance further ALONG it, so it tracks the line instead of cutting to a
  far corner (and can never point at a waypoint it has already passed). The
  look-ahead **stretches with speed** (`JERAI_AIM_SPEED_GAIN`): a fast car looks
  further up the plan rather than chasing every wiggle and sawing at the wheel;
- a **directional guide**: the aim walk takes the first point that is both far
  enough ahead AND not behind the car (cos > -0.35 ~= within 110 deg, so a
  perpendicular intersection turn still counts), and the joyride goal picker skips
  destinations behind the car. Both exist to stop the car targeting something it
  has passed and turning back for it;
- **feelers** - short, FRESH, thin `CellEmpty` probes fanned in front of the car,
  which bias the aim around scenery the coarse (512-unit) and up-to-a-replan-old
  A\* grid cannot see. A wall on one side pushes the aim to the other; a street
  with walls both sides cancels out. The centre feeler brakes when the nose is
  genuinely blocked;
- a steering dead-band **with hysteresis** (start at 70, keep turning to 30) so
  it does not flip sides on noise, and a lift-off when a car is close ahead (no
  braking for traffic - that made the car crawl past oncoming vehicles);
- a **stuck recovery** that backs out of a wedge (and asks the behavior for a new
  destination) after ~1.3 s at a standstill, plus an **early reverse** the moment
  scenery is right on the nose while barely moving (backing off sooner grinds
  less than waiting out the timer). **The steer bit in a burst is INVERTED**: while
  backing up, turning the wheel the way forward steering would swings the NOSE the
  other way, so the forward sign used to drive the nose *away* from the aim and
  every burst left the error worse than it found it - which is why a wedged car
  could sit in a reverse loop for fifteen seconds.

## Car dynamics (speed, grip, corners)

Walking a line is not driving: a car carries momentum and its velocity can point
somewhere other than its nose. JerAI reads that (`JERAI_CARSTATE.slip`, the angle
between `st.n.linearVelocity` and the heading) and drives to a **grip budget**:

- `JerAiScanCurve` finds the sharpest turn on the plan within `corner_lookahead`
  (its heading change, how far off it is, and the arc it happens over);
- `JerAiSpeedTarget` turns that into a speed the car may carry now: the grip limit
  for the corner radius (`sqrt(corner_g * r)`), backed off by the braking distance
  to it (`sqrt(vCorner^2 + 2*brake_gain*dist)`) so the car lifts BEFORE the
  corner instead of at it. `speed_scale` is an overall aggression dial.
- the pad then brakes over that target, lifts slightly over, and powers out under;
- a **wall-evasion handbrake** tight-turns when scenery is close ahead;
- `grip` (100 = hooked up) falls with the slide, and is on the HUD.

The A\* cost model hugs the middle hard (a squared clearance penalty), so it
routes around a block rather than squeezing a short gap past a building.

## Behaviors (`mode`)

| id | name | what it does |
|----|------|--------------|
| 0  | Manual  | no pad injection — the car is the player's |
| 1  | Joyride | picks a random road sample nearby and drives to it, then repeats |

Adding a behavior is one function (`CAR_DATA* -> pad`) plus one row in
`jerai_behavior.c`'s table; the menu and config pick it up automatically.

## Multiplayer: follow and flee

With a session live the joyride behavior does **not** pick a random road sample.
Each machine plays its half:

- a **CLIENT** drives to the **host's car** and holds a **clearance**, so it tails
the host around the map while a match is being tested instead of ramming them;
- the **HOST** runs FROM the nearest other player, so the cars that joined to
follow have something to chase. Its bolt-hole is scored on the occupancy grid,
so it is a place the car can actually DRIVE to and not a straight line away
through a building.

The session state comes from the SDK (`jer_net_is_active` / `jer_net_is_host`) and
the cars from the compiled-in `mp` module (`MpGetPlayer(i)->carId`); see
`jerai_follow.c`. Both halves answer 0 when they do not apply, so single player,
and a session with nobody else in it, keep the plain random wander.

Within `follow_clearance` the car stops and holds instead of closing the last
stretch. That hold goes through `JerAiDriveHoldPad`, **not** the steering pad, so
the stuck recovery that lives in the steering pad cannot mistake a
parked-on-purpose car for a wedged one and reverse into the host. Between the
clearance and twice the clearance the throttle is dropped, for a coast-and-brake
approach rather than a lunge.

`follow_car` is a **test lever**: it names a `car_data` index to follow with no
session at all, so the approach, the clearance and the idle can be exercised in
single player.

**Range: unlimited by default.** `follow_range` is 0, and 0 means *no limit* - the
chase is CHUNKED, not truncated. The A\* window is centred on the car and is only
~12,000 units across, so a host on the far side of a city cannot be planned to
directly. The goal is therefore **clamped to the window edge in the host's
direction** and re-planned as the car closes, which is what lets it cross a whole
map to rendezvous. Set a non-zero `follow_range` to make the AI give the target up
(and go back to wandering) once it is farther away than that.

A script does the whole thing for you: host a match as usual, then run
`tools/follow_host.py` (or `tools/follow_host.bat`) to bring in a joining follower.
It gives the follower its own run directory, so its log and `mp.ini` cannot
collide with the host's; `--clearance`, `--range`, `--yaw-lead` and `--client-car`
override the defaults, and `--dry` prints the command instead of launching.

**Enable JerAI only on a machine whose car nobody is driving**, here and on the
LAN: with `mode = 1` JerAI substitutes the pad, so on YOUR instance it would take
the wheel from you (set `mode = 0`, or turn JerAI off in the mods menu). The
follower the script starts is configured for you, with the host's own port in its
`mp.ini` so the two cannot disagree about where the session is.

## What the planner will and will not route through

The A\* runs on an occupancy grid of `CellEmpty` probes - and **`CellEmpty`
deliberately ignores smashable scenery** (light posts, chairs, a lot of fencing),
so the grid used to route straight through props the car then grinds into.
`jerai_map.c` now runs **both** tests: the engine's own, and the same one with the
smashable branch kept (`JerAiMapCellHasSmashable`, shared with the steering
feelers). A sample with either in it is BLOCKED, and the planner never expands a
blocked sample - so it routes AROUND the scenery rather than through it.

The road network is a **preference, never a wall**: an off-road sample costs
`offroad_cost` more than an on-road one (90 vs the base 100), so the planner
takes the roads when they go the same way as the target, and still leaves them to
reach a goal that is not on one. At 0 there is no road preference at all.

## Measuring the steering loop

The once-a-second `[JerAI] drive` line **cannot show a saw**: it samples 30 frames
apart while the wheel is turned on and off in ones and twos. Set `steer_trace = N`
and the module instead logs a `[JerAI] steer` line every N frames carrying the pad,
the heading error, the **damped** error the steer decision actually used, the feeler
bias, the speed, the corner-speed target, the **real front wheel angle** (`wa` - the
number that shows the engine integrating the pad), the look-ahead asked for vs where
the aim landed, the cross-track offset, the aim point, the plan's own bearing, and
the stuck/recover counters.

```
python JERICHO/MODS/JerAI/tools/jerai_steer_stats.py <log>
```

### What that measurement has established

A fixed-aim run (`aim_test = 0`, so the steering loop is driven by a *stable*
setpoint and nothing else) tracks cleanly: mean heading error in the tens, a wheel
angle around 41 (nowhere near the 352 lock), steering engaged 14% of the time,
**zero** direction reversals, and speed up to 181. So the pad law, the hysteresis
and the engine's 32/frame build vs 64/frame centring are **not** what makes the car
weave. Do not "fix" them on a hunch.

With a real destination the car instead runs a persistent heading error in the
hundreds (20-30 degrees) at partial-to-full lock while its cross-track error grows
against a plan that is usually a **2-waypoint straight run** (the goal only changes
every few seconds, so the line is stable, and `JerAiStarLineClear` refuses any line
crossing a blocked sample, so the straight run is genuinely clear). The fault is
therefore in **the destination/aim the behaviour supplies**, not in the driver - and
`pdir` plus `ax`/`az` in the trace are what the next pass needs to pin it down.

## Running from the police

When the engine says the cops are after this car - `copsAreInPursuit` or
`CopsCanSeePlayer` - the police outrank EVERYTHING else, the follow included. The
car runs from the nearest `CONTROL_TYPE_PURSUER_AI` car, and unlike the other
behaviours it does so with the corner-speed model and the aggression dial bypassed
(`panicFlee` in the driver: `JerAiSpeedTarget` returns the whole top speed), then
goes back to following or wandering the moment the pursuit ends.

`flee_police` (default 1) turns it off. **It needs `immune = 0`**: immunity pins
the wanted level at zero, so with the default immunity no pursuit ever starts and
this can never trigger.

A closing pursuer covers `replan_move` almost instantly, so the plain "the threat
moved" trigger used to redraw the bolt-hole every ~12 frames. A destination
redrawn 2.5 times a second is never DRIVEN TO: the aim swings, the heading error
stays huge, and the car reads as lazy while it thrashes. The police case now waits
**six times** as long before reconsidering - a fleeing car commits to a direction.
Measured effect: goal changes fell from 34 to 18 over a 700-frame survival run.

### Being chased: letting go of the road

Under a chase the pull back to the road is a liability - a car that keeps snapping
onto the road loses whatever line it had, and its speed with it. Two knobs answer
that, both applied only while panicking:

- `panic_offroad` (default 30, against the normal `offroad_cost` 90) weakens the
  road preference, so the planner will take a direct line across open ground;
- `panic_lookahead` (default 1600) is ADDED to the aim's look-ahead, so the aim
  sits much further down the road and the car commits to the line instead of
  correcting short and often.

Measured: the look-ahead does take effect (la rose from ~2194 to ~3508 in a
survival run). What has NOT changed yet is the headline number - the heading error
still averages ~950 game units and the car still sits at full lock over half the
time - so these knobs are necessary but not sufficient. The remaining cause is the
one the steer trace points at everywhere: the destination/aim the behaviour picks,
not the driver's hold on it.

### Wheelspin, and why it is currently inert

`panic_wheelspin` (default 1) lets the car use the engine's wheelspin (the Circle
bind) rather than plain throttle to get off the line: `CAR_PAD_WHEELSPIN` makes
wheelforces apply maximum thrust regardless of the pedal. It pays for that by
loading the front tyre force and starving the rear (`*rearFS = 0x780 - *frontFS`),
so a wheelspun car has little rear grip and spins out the moment it is asked to
turn - which is why the guard is the FRONT WHEEL ANGLE and the heading error,
not the pad bits (the bits lead the wheel by a frame or two, so requiring "no
steering bit" as well asked for something that almost never holds).

**Measured: it fired on 0 of 110 sampled frames** in a HAVANA survival run. The
car's heading error averaged ~966 game units (about 85 degrees) and it sat at full
lock half the time, so it was essentially never straight and accelerating and the
guard never opened. That is the same fault the steer trace found everywhere else:
the car cannot track the destination it is given, so it spends its life at full
lock wrestling a bearing it never reaches - and anything that rewards being
straight (a clean launch, real corner-exit speed) never happens. The wheelspin
path is kept because it is correct and guarded, but it is **unverified in
practice** until the aim problem is fixed.

## Visualization (`viz_*`)

Drawn in `JER_EVENT_DRAW_WORLD` with `Debug_AddLineDepth` (buildings occlude the
lines):

- `viz_road` — the engine road graph: nodes as crosses (yellow straight / orange
  curve / green junction) and the `ConnectIdx` edges as blue lines;
- `viz_grid` — the occupancy grid: blocked samples (walls) in red, road samples
  in green, within ~6,000 units of the car;
- `viz_path` — the current A\* plan (red), the goal cross (yellow) and the aim
  line (green);
- `viz_hud` — a one-line text readout (mode, speed, waypoints, graph size, lines).

## Immunity

While JerAI is driving (and `immune = 1`, the default) the player's car is
invulnerable: `JER_EVENT_GET_BUDDHA` clamps its damage below the totaled
threshold, and the frame hook keeps the wanted level at zero
(`felonyRating`/`copsAreInPursuit`/`CopsCanSeePlayer`/`pedestrianFelony`), so no
cop sirens chase the test drive. Manual play (`mode = 0`) is left untouched.

## Control menu

**L2** opens a small `jer_menu` list over the game: the behaviors, the four
visualization layers, *Dump road graph now*, and *Close*. It reads the PHYSICAL
pad (in the frame hook) while the car gets the synthetic one, so it works while
JerAI is driving. Every change is written to the config immediately.

## Road-graph dump

Set `dump_now = 1` (or pick *Dump road graph now*) and the module writes, into
the working directory:

- `JerAI_roadgraph.json` — nodes (surfId, kind, world x/y/z, lanes, speed limit)
  and edges (node index pairs);
- `JerAI_roadgraph.obj` — the same graph as geometry (world/4096, X mirrored).

## Layout

| File | Purpose |
|------|---------|
| `jerai.c/.h` | module entry, config, the CAR_PAD injection and the HUD |
| `jerai_internal.h` | shared state + file map (glue between this module's files) |
| `jerai_map.*` | the occupancy grid (engine probes: `CellEmpty`, `JerRoadAt`, `MapHeight`) |
| `jerai_mapgrid.c` | the pure grid queries + cost model |
| `jerai_star.*` | A\* over the grid |
| `jerai_local.*` | the local search ("get back to a road") |
| `jerai_road.*` | the engine road graph (surfaces + `ConnectIdx`) as nodes/edges |
| `jerai_dump.c` | the offline road-graph export |
| `jerai_drive.*` | pad injection + waypoint following |
| `jerai_behavior.*` | the modular behavior table |
| `jerai_follow.*` | who the AI chases in multiplayer (the mp host) + the clearance |
| `jerai_viz.c` | debug drawing |
| `jerai_menu.c` | the control menu |
| `tools/follow_host.*` | join a match on localhost as an extra player that follows the host |
| `tools/jerai_steer_stats.py` | summarise a `steer_trace` log (the steering loop's own numbers) |

The search library (`jerai_map` / `jerai_mapgrid` / `jerai_star` / `jerai_local`)
is a namespaced copy of `mp`'s `ai/` — both modules are compiled into the same
exe, so the symbols must not collide. The pure half is exercised engine-free by
`src_rebuild/Game/C/JERICHO/test/test_jerai_path.c`.

## Tunables (`JERICHO/CONFIG/JerAI.ini`, namespace `[JerAI]`, read live)

See `jerai.h` for the key names and defaults. The car-dynamics knobs:

| key | default | meaning |
|-----|---------|---------|
| `corner_g` | 2 | lateral-g budget; bigger = more speed through the same curve |
| `brake_gain` | 1 | braking authority for the braking-distance term |
| `corner_lookahead` | 6000 | how far ahead the plan is scanned for corners (world units) |
| `speed_scale` | 100 | overall aggression: the corner target as a percentage |
| `avoid_dist` | 1200 | start avoiding a car ahead within this range (**capped at `JERAI_AVOID_MAX` = 1200**; a larger value is logged, not silently ignored) |
| `steer_trace` | 0 | log a compact steering-loop line every N frames (0 = off) - see *Measuring the steering loop* |
| `yaw_lead` | 4 | steering damper: frames of the car's own yaw the aim leads by. **Lower steers harder**; higher straightens the wheel earlier (the old fixed value was 8, which read as steering far too slowly) |

`brake_gain` is in speed^2 per world unit; 40 swamps the term (the target never
drops), so keep it near 1.

The multiplayer-follow knobs (see *Following the host*):

| key | default | meaning |
|-----|---------|---------|
| `follow` | 1 | retarget joyride at the host's car while a session is live (0 = never) |
| `follow_clearance` | 1500 | world units held from the followed car before stopping |
| `follow_range` | 0 | give the target up past this distance; **0 = unlimited** (a chunked chase across the whole map) |
| `follow_car` | -1 | TEST LEVER: a `car_data` index to follow with no session |
| `flee` | 1 | while the HOST in a session, run from the nearest other player (0 = never) |
| `flee_police` | 1 | run from the police FLAT OUT when they are after us (needs `immune = 0`) |
| `panic_wheelspin` | 1 | may use the wheelspin launch while fleeing the police (straight-line only) |
| `panic_offroad` | 30 | the road preference to use WHILE CHASED, replacing `offroad_cost` (0 = take the direct line) |
| `panic_lookahead` | 1600 | added to the aim's look-ahead while chased, to hold speed down a longer line |
| `flee_car` | -1 | TEST LEVER: a `car_data` index to run from with no session |
| `offroad_cost` | 90 | extra A* cost for an off-road sample (on-road is 100); 0 = no road preference |

### Not built, on purpose

An **apex / racing-line bias** (offsetting the aim toward the inside of a corner
to use the full road width) was proposed and deliberately NOT built. The A* cost
model already hugs the middle of the road hard, and this car's recurring failure
is grinding along walls, not leaving time on the table - pulling the aim off the
centreline toward an apex is exactly the change that would put it back into the
scenery. The feelers (which push the aim AWAY from a wall) are the safer
line-shaping lever and are what is used.

A grip-budget **steer-authority cap** was also dropped: the injected steering is a
digital pad, so authority cannot be scaled smoothly, and the analog channel is
neutered by `handling.c`'s return-to-centre block (it zeroes any analog angle
below ~65). Steering is damped with hysteresis plus the speed-scaled look-ahead
instead.

## Build

```
JERICHO\build_game.bat        (the game exe; the module is compiled in)
```

Enable it from Options → JERICHO (mods menu), or set `JerAI = 1` in
`JERICHO/CONFIG/modlist.ini`.
