/*
 * mp_proto.h -- JERICHO Multiplayer wire protocol.
 *
 * The single source of truth for the binary schema exchanged between the
 * game instances over the network. Same conventions as gaildrv2_proto.h:
 * all multi-byte fields are LITTLE-ENDIAN and every struct is
 * #pragma pack(1) with a compile-time layout check in C++.
 *
 * Two transports:
 *   - TCP (default port 1318) carries the session: handshake, lobby,
 *     per-frame input, state-resync snapshots and the addon channel.
 *   - UDP MP_DISCOVERY_PORT (broadcast) carries discovery beacons only, and
 *     names the host's session port in the payload.
 *
 * TCP framing (identical shape to gaildrv2):
 *
 *     u32 len          -- number of bytes that follow this field (>= 8)
 *     char tag[4]      -- message type (MP_TAG_*)
 *     u8  version      -- MP_PROTO_VERSION
 *     u8  flags        -- per-message flags (MP_FLAG_*)
 *     u16 spare        -- reserved, zero
 *     ... payload      -- depends on tag
 *
 * A message is read by first recv()ing the envelope (12 bytes), then `len`
 * more bytes (the payload, which includes nothing of the envelope). The
 * stream has no framing otherwise: both sides must tolerate partial reads
 * and coalesced writes.
 *
 * Bump MP_PROTO_VERSION on any incompatible change; a peer with a
 * different version is rejected with MP_REJECT_VERSION.
 */
#ifndef MP_PROTO_H
#define MP_PROTO_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MP_PROTO_VERSION	20	/* 20: MP_ROSTER_ENTRY carries the car a player
				 *     got OUT of (leftModel/leftModelCity), so a late
				 *     joiner's roster snapshot names abandoned cars and
				 *     marks on-foot players before the first carstate.
				 *     MP_ROSTER_ENTRY is 32 bytes (was 30).
				 * 19: dynamic on-foot characters. Id 0 is Tanner,
				 *     1 is JMPPED entry 0, and 2.. are the archive's
				 *     later entries; the id is the same byte in
				 *     JPCL/roster/JPPD. The retired COP/CIVILIAN
				 *     ids are no longer wire meanings.
				 * 18: the preferred on-foot character rides with the
				 *     player identity: MP_COLOR_ENTRY's first spare byte
				 *     (JPCL), a new MP_ROSTER_ENTRY byte, and
				 *     MP_PEDSTATE_ENTRY.spare (JPPD). One id, three
				 *     chances to learn it, so a late joiner has it
				 *     before the first pose and a mid-match change
				 *     reaches every peer. MP_ROSTER_ENTRY is 30 bytes.
				 * 17: MP_CARSTATE_ENTRY carries `crushScale`, so the
				 *     owner's per-car body-crush multiplier is applied
				 *     on every machine simulating that car. 57 bytes
				 *     (was 56).
				 * 16: MP_CARSTATE_ENTRY carries `hubcaps`, so a
				 *     peer's missing hubcap is drawn on the other machines
				 *     too. 56 bytes (was 55).
				 * 15: MP_CARSTATE carries leftModel/leftModelCity so a late
				 *     joiner can materialize the parked car a player left.
				 *     MP_CARSTATE_ENTRY is 55 bytes (was 53).
				 * 14: MP_HIT carries targetFrame + tgtPos, so a contact can be
				 *     validated against the target's own pose timeline instead
				 *     of being applied on arrival. MP_HIT is 32 bytes (was 16).
				 * 13: Driver 1 adds IVIEW (9) and TRAIN (10); runtime bank cities move from 9+N to 11+N.
				 * 12: MP_MAX_PLAYERS is 16, so MP_ROSTER and every
					 * per-player wire row grew by sizeof -- an 8-player
					 * build must REFUSE a 16-player session rather than
					 * copy a bigger roster into its smaller buffer.
					 * (11: MP_WELCOME.rules, 10: MP_TAG_KICK) */

/* Default UDP+TCP port. 1318 is IANA-unassigned (the neighbour 1319 is
 * amx-icsp), so it is a safe, non-reserved choice for a game. Configurable
 * per instance via JERICHO/CONFIG/mp.ini (`port`). */
#define MP_DEFAULT_PORT		1318
/* UDP beacon port. FIXED and shared by every instance: it is the address a
 * browser listens on and a host beacons to, so neither side can be moved by
 * changing the session port. The session port travels in the beacon payload
 * (MP_BEACON.port), which is why a host that overrides its port stays
 * discoverable. */
#define MP_DISCOVERY_PORT	1318

/* Capacity. The engine renders at most 2 local player views, but a session
 * carries more remote players as world cars, one engine player slot each
 * (MAX_PLAYERS is 16 on PC, so 16 is "host + 15 clients" with no room to spare).
 *
 * This is ALSO a car_data capacity: every player is one slot out of the
 * JERICHO-managed pool reserved in dr2limits.h (JER_SLOT_PLAYERS_FIRST..),
 * which is deliberately separate from the traffic pool so a full lobby does not
 * eat the map's civilians. */
#define MP_MAX_PLAYERS		16

/* A car's model number alone is ambiguous: every city ships CARMODEL_0..12 and
 * the same number is a DIFFERENT vehicle in each. A row that names a car
 * therefore carries its CITY too. MP_CAR_CITY_SESSION (0xFF) = the session's
 * city, i.e. the level's own (the ordinary case); 0..3 = that city's data (a
 * cross-city import). Mirrors carhacks' CHK_CITY_NATIVE. */
#define MP_CAR_CITY_SESSION	0xFF

/* Fixed field widths for the handshake manifest. */
#define MP_MOD_ID_MAX		24
#define MP_MOD_VER_MAX		16
#define MP_MAX_MODS		32
#define MP_NAME_MAX		32
#define MP_REJECT_TEXT_MAX	64
#define MP_NOTIFY_MAX		6	/* lines kept in the lower-left info log (6 rows from
					 * y=178 fit the 240-high screen) */
#define MP_NOTIFY_TEXT_MAX	96
#define MP_NOTIFY_WRAP		34	/* chars that fit on one overlay row; a longer notice
					 * WRAPS into several log lines. Keep in step with
					 * JER_ERROR_WRAP (jer_system.c). */
#define MP_NOTIFY_MS		6000	/* how long a line stays on screen (ms) */
#define MP_CHANNEL_NAME_MAX	16
/* The most payload a channel frame may carry. Also the bound MpBridgeAccept uses, so a
 * receiver can build a relay copy of the header + payload on the stack. */
#define MP_CHANNEL_MAX_PAYLOAD	1024

/* ------------------------------------------------------------------ */
/* Tags                                                                */
/* ------------------------------------------------------------------ */
#define MP_TAG_HELLO	"JPHL"	/* client -> host: identity + mod manifest */
#define MP_TAG_WELCOME	"JPWL"	/* host -> client: accepted (id + lobby) */
#define MP_TAG_REJECT	"JPRJ"	/* host -> client: refused (reason text) */
/* 'JPSS' was RETIRED here. It was reserved for a standalone session/lobby
 * broadcast that nothing ever sent or handled (the launch config rides in
 * MP_START, 'JPST'). The spelling is dead: do not reuse it. */
#define MP_TAG_START	"JPST"	/* host -> client: begin the level launch */
#define MP_TAG_INPUT	"JPIN"	/* client -> host, host -> client: input set */
#define MP_TAG_CARSTATE	"JPCS"	/* host -> client: resync snapshot */
#define MP_TAG_PING	"JPPN"
#define MP_TAG_PONG	"JPPO"
#define MP_TAG_CHANNEL	"JPCH"	/* addon net bridge payload */
#define MP_TAG_LEAVE	"JPLV"	/* either side: leaving the session */
#define MP_TAG_KICK	"JPKK"	/* host -> client: you are being removed */
#define MP_TAG_ROSTER	"JPRS"	/* host -> all: who is in the match */
#define MP_TAG_HIT	"JPHI"	/* either side: "my car bumped yours, you push yourself" */
#define MP_TAG_PED	"JPPD"	/* owner -> peers: an ON-FOOT player's pose */
#define MP_TAG_COLOR	"JPCL"	/* either side: a player's chosen colour */
#define MP_TAG_CAR	"JPCC"	/* client -> host: the car this player picked */
#define MP_TAG_TRAFFIC	"JPTF"	/* either side: replicated traffic/police car state (owner -> peers) */

/* The on-foot character a player has chosen. Wire values are STABLE: they are
 * stored in mp.ini and compared across machines, so never renumber one.
 *
 * TANNER is the engine's default. Every other id is a JMPPED archive entry:
 * id 1 is entry 0 (the Jericho set) and id 2.. are the later entries, using the
 * same Tanner skeleton and bind transforms. The archive's own eight-entry cap
 * keeps the id byte small. */
enum
{
	MP_PED_MODEL_TANNER = 0,	/* pmTannerModels[], the default */
	MP_PED_MODEL_JERICHO = 1,	/* JMPPED entry 0; native on Havana */
	MP_PED_MODEL_CUSTOM_FIRST = 2,	/* JMPPED entries 1.. */
	MP_PED_MODEL_MAX = 9		/* 1 + JER_PED_MAX_ENTRIES (8); wire byte range */
};

/* The 'JPSW' meeting-point message (MP_SPAWN) has been RETIRED: the two
 * machines already agree on the engine's own deterministic spawn, and a client
 * gathers itself beside the host (MpHandleCarState). Tag 95's slot is free but
 * must not be reused for a different meaning without a protocol version bump. */

/* The host's view of the match: one row per player, in ASCENDING PLAYER ID.
 *
 * That order is the point. Car slots are handed out by the engine in the order
 * the player cars are created, so if each machine walked its own registry (rows
 * are given out first-free) the two sides could put the same two players in
 * opposite slots and each would then drive the other's car. Walking player ids
 * instead gives both machines the same answer.
 *
 * It is also sent BEFORE the launch, so every machine knows how many cars to
 * spawn: a client that did not know about the host yet added no car at all and
 * left the level's own AI car sitting in the remote player's slot. */
#define MP_ROSTER_NAME_MAX	20
#define MP_ROSTER_FLAG_HOST	1
/* The host HAS a car for this player (its own car, or a peer whose pick has
 * landed and whose car the host has built). A client must not build a car for a
 * peer who has not picked yet -- that is the placeholder the host stopped making
 * -- but it must build one the moment the host HAS one, or a third machine never
 * gets the car at all and the player is invisible on it while still colliding
 * (its carstate entries are dropped for a player with no car here). */
#define MP_ROSTER_FLAG_CAR_READY	2

/* The roster structs go on the wire verbatim (the host memcpy's the struct and
 * the client memcpy's it back, both sized with sizeof), so pin their layout to
 * the contract this header states for the rest of the file. Left naturally
 * aligned, adding a byte to the entry would silently add 3 padding bytes. */
#pragma pack(push, 1)
typedef struct MP_ROSTER_ENTRY
{
	uint8_t  id;
	uint8_t  carId;		/* that machine's local CAR_DATA slot, informational */
	uint8_t  model;		/* car model, 0xFF = on foot */
	uint8_t  modelCity;	/* city `model` belongs to: MP_CAR_CITY_SESSION = the
				 * session's city, 0..CITY_COUNT-1 = a cross-city import */
	uint8_t  flags;		/* MP_ROSTER_FLAG_* */
	uint8_t  pedModel;	/* MP_PED_MODEL_*: the character this player is using */
	uint16_t ping;		/* round trip in ms, as the host measured it */
	uint16_t palette;	/* the player's palette (was named `reserved`; it has only
				 * ever held this, so the name now says so) */
	uint8_t  leftModel;	/* the car this player got OUT of and left parked (model
				 * NUMBER), 0xFF = none. Carried so a late joiner's
				 * roster snapshot names abandoned cars -- the pose still
				 * rides the per-frame carstate (MP_CARSTATE_LEFT_CAR),
				 * which is the only place a position can live. */
	uint8_t  leftModelCity;	/* city leftModel belongs to: MP_CAR_CITY_SESSION = the
				 * session's city, 0..CITY_COUNT-1 = a cross-city import */
	char     name[MP_ROSTER_NAME_MAX];
} MP_ROSTER_ENTRY;

typedef struct MP_ROSTER
{
	uint8_t        count;
	uint8_t        reserved[3];
	MP_ROSTER_ENTRY entries[MP_MAX_PLAYERS];
} MP_ROSTER;
#pragma pack(pop)
#define MP_TAG_CHAT	"JPCX"	/* either side: a chat line */
#define MP_TAG_STATS	"JPSX"	/* host -> all: each player's link to the host (rx/tx/loss).
				 * OPTIONAL: a peer that does not know it ignores it (unknown
				 * tags are dropped), so it needs no protocol bump. */

/* Envelope flags */
#define MP_FLAG_RELIABLE	0x01	/* sender wants an ordered/reliable channel */

/* ------------------------------------------------------------------ */
/* Role / lifecycle                                                    */
/* ------------------------------------------------------------------ */
enum
{
	MP_ROLE_NONE = 0,
	MP_ROLE_HOST,
	MP_ROLE_CLIENT
};

/* Reject reasons (MP_REJECT.reason) */
enum
{
	MP_REJECT_NONE = 0,
	MP_REJECT_FULL,
	MP_REJECT_VERSION,	/* protocol / SDK / game build mismatch */
	MP_REJECT_MODS,		/* mod manifest mismatch while enforcement is on */
	MP_REJECT_INPROGRESS,	/* the host has already launched the level */
	MP_REJECT_CUSTOM
};

/* Lobby mod-match strictness (host setting) */
enum
{
	MP_MODCHECK_OFF = 0,	/* admit any client */
	MP_MODCHECK_VERSION,	/* admit if enabled-mod ids match (versions ignored) */
	MP_MODCHECK_EXACT	/* admit only if enabled-mod ids AND versions match */
};

/* Gamemode ids for the lobby (module-side; the engine GAMETYPE is mapped
 * separately). Take a Ride is the only one implemented for now. */
enum
{
	MP_GAMEMODE_TAKEADRIDE = 0,
	MP_GAMEMODE_COUNT
};

/* ------------------------------------------------------------------ */
/* Envelope (12 bytes before the payload)                              */
/* ------------------------------------------------------------------ */
#pragma pack(push, 1)
typedef struct MP_ENVELOPE
{
	uint32_t len;		/* bytes following this field (>= 8) */
	char     tag[4];
	uint8_t  version;
	uint8_t  flags;
	uint16_t spare;
} MP_ENVELOPE;

#define MP_ENVELOPE_SIZE 12

/* ------------------------------------------------------------------ */
/* Discovery beacon (UDP broadcast, host -> LAN)                       */
/* ------------------------------------------------------------------ */
#define MP_BEACON_INTERVAL_MS	1000
#define MP_BEACON_TIMEOUT_MS	4000	/* drop a server after 4s of silence */

typedef struct MP_BEACON
{
	uint32_t magic;			/* MP_UDP_MAGIC */
	uint16_t protoVersion;
	uint16_t port;			/* TCP port the host listens on */
	char     hostName[MP_NAME_MAX];
	uint8_t  players;
	uint8_t  maxPlayers;
	uint8_t  gamemode;
	uint8_t  modsEnforced;		/* MP_MODCHECK_* */
	uint8_t  city;
	uint8_t  inProgress;		/* 1 once the level has launched */
	uint16_t modHash;		/* short digest of the host manifest */
	uint16_t rules;			/* the host's SESSION RULES, MP_RULES_PACK'd -- the SAME
				 * packed byte MP_WELCOME.rules carries, so a browser can show
				 * the session's settings (cops etc.) without joining. The MODE's
				 * name comes from `gamemode`, never from these rules.
				 * This field was `spare`; the offset and size are unchanged, so
				 * the beacon is identical on the wire, and a peer that predates
				 * it reads 0 (MP_RULES_PACK'd "no rules"), which is the old
				 * behaviour exactly. */
} MP_BEACON;

/* UDP datagram magic -- 'JMP1' little-endian. */
#define MP_UDP_MAGIC 0x31504D4A

/* Liveness: both sides ping on this cadence, so an idle session (frontend
 * lobby, quiet stretch, paused game) never looks like a dead peer. */
#define MP_KEEPALIVE_INTERVAL_MS	1000
#define MP_KEEPALIVE_MIN_MS		250	/* clamp for the config value */

/* Silence that drops a peer. The default; the runtime value is read from
 * mp.ini as idle_drop_ms (0 = never drop). Shared so mp_config.c can default it. */
#define MP_CONN_TIMEOUT_MS	30000

/* ------------------------------------------------------------------ */
/* Handshake                                                           */
/* ------------------------------------------------------------------ */

/* One installed-mod row in the manifest. */
typedef struct MP_MOD_INFO
{
	char     id[MP_MOD_ID_MAX];
	char     version[MP_MOD_VER_MAX];
	uint8_t  enabled;
	uint8_t  reserved;
} MP_MOD_INFO;

/* 'JPHL' -- client -> host. Followed by modCount MP_MOD_INFO rows, then
 * optionally the PLAYER ID block: MP_HELLO_ID_TAG + MP_PLAYER_ID_LEN bytes, a
 * random per-install id (mp_config.c, [mp] player_id) a server can recognise a
 * player by (admins). No protocol bump: every host reads exactly modCount rows and
 * ignores what follows (C MpHandleHello; dediserver reads whole 42-byte rows, and
 * 20 bytes is less than one), so old hosts accept it and old clients just omit it.
 * It is a bearer secret, not authentication: the link is unencrypted. */
#define MP_HELLO_ID_TAG		"JPID"
#define MP_PLAYER_ID_LEN	16
/* ...then optionally the BUILD block: MP_HELLO_VER_TAG + u8 length + that many
 * bytes of the client's RELEASE SERIES ("0.10.4", plus "-dev" on a non-Release
 * build; MpVersionLabel). Display only -- the host shows it in its join toast;
 * admission still goes by gameBuild. Same no-bump reasoning as JPID, with one
 * hard limit: dediservers before this read EVERY whole 42-byte row after the
 * header as a mod (not just modCount of them), so JPID + JPVR together must stay
 * UNDER 42 bytes -- 20 + 5 + 16 = 41. Do not raise MP_HELLO_VER_MAX. */
#define MP_HELLO_VER_TAG	"JPVR"
#define MP_HELLO_VER_MAX	16
typedef struct MP_HELLO
{
	uint16_t protoVersion;
	uint16_t sdkVersion;
	uint16_t gameBuild;	/* hash of JERICHO_BUILD_VERSION */
	uint16_t car;		/* this machine's vehicle (car id), 0xFFFF = unset */
	char     playerName[MP_NAME_MAX];
	uint8_t  modCount;
	uint8_t  reserved[3];
} MP_HELLO;

/* 'JPWL' -- host -> client, accepted. */
typedef struct MP_WELCOME
{
	uint8_t  playerId;	/* assigned slot, 1..MP_MAX_PLAYERS-1 (0 = host) */
	uint8_t  maxPlayers;
	uint8_t  modsEnforced;	/* MP_MODCHECK_* */
	uint8_t  modsMatched;	/* 1 if the client's manifest matched the host */
	uint8_t  running;	/* 1 = the host's match is already live (join in progress) */
	uint8_t  subGame;	/* the multiplayer sub-level (gSubGameNumber) */
	uint8_t  mpLevel;	/* 1 = the host is on a multiplayer map, 0 = the full city */
	uint8_t  arena;		/* which multiplayer map, 0/1 (gBootMpArena) - keeps the struct 16 bytes */
	uint8_t  gamemode;
	uint8_t  city;
	uint8_t  timeOfDay;
	uint8_t  weather;
	uint32_t seed;
	uint8_t  hostCar;	/* the host's own vehicle (car id), 0xFF = unset */
	uint8_t  rules;		/* the host's SESSION RULES, MP_RULES_PACK'd (v11) -- what a
				 * client joining a match IN PROGRESS must adopt */
} MP_WELCOME;

/* 'JPRJ' -- host -> client, refused. */
typedef struct MP_REJECT
{
	uint8_t  reason;	/* MP_REJECT_* */
	uint8_t  reserved[3];
	char     text[MP_REJECT_TEXT_MAX];
} MP_REJECT;

/* The host's SESSION RULES, packed into ONE byte. They travel three ways and the
 * three must stay in step: MP_WELCOME.rules (join in progress), the free bits
 * of MP_SESSION.spare (the launch path, shifted up by one because spare's bit 0
 * is the map shape), and MP_BEACON.rules (so a browser can NAME the mode of a
 * server it has not joined). MP_RULES_PACK and its readers are the only writers. */
#define MP_RULE_COPS		0x1	/* 1 = police cars spawn (CopsAllowed = 1), 0 = off */
#define MP_RULE_INVULN		0x2	/* 1 = no car can be damaged (gInvincibleCar) */
#define MP_RULE_DIFF_SHIFT	2	/* 2 bits: gCopDifficultyLevel, 0..3 */
#define MP_RULE_DIFF_MASK	0x3
#define MP_RULE_IMMUNE		0x10	/* 1 = cops can't come after you (gPlayerImmune) */

/* COPS and IMMUNITY are deliberately SEPARATE axes, not two names for one thing:
 * Cops = do police cars exist/spawn at all (CopsAllowed), while Immunity = they
 * may well exist but you are un-touchable (gPlayerImmune zeroes the wanted level,
 * so nobody is ever sent after you). "Cops off" removes them; "Immunity on"
 * leaves them on the map and makes them impotent. */
#define MP_RULES_PACK(cops, invuln, diff, immune)	\
	(uint32_t)(((cops) ? MP_RULE_COPS : 0) |\
	           ((invuln) ? MP_RULE_INVULN : 0) |\
	           (((diff) & MP_RULE_DIFF_MASK) << MP_RULE_DIFF_SHIFT) |\
	           ((immune) ? MP_RULE_IMMUNE : 0))
#define MP_RULES_COPS(b)	(((b) & MP_RULE_COPS) ? 1 : 0)
#define MP_RULES_INVULN(b)	(((b) & MP_RULE_INVULN) ? 1 : 0)
#define MP_RULES_DIFF(b)	(((b) >> MP_RULE_DIFF_SHIFT) & MP_RULE_DIFF_MASK)
#define MP_RULES_IMMUNE(b)	(((b) & MP_RULE_IMMUNE) ? 1 : 0)

/* The launch config. It travels INSIDE MP_START ('JPST'), never as a standalone
 * message: the old standalone form ('JPSS') had no sender and no handler and has
 * been retired. `state` is set to MP_SESSION_STARTING when the host launches. */
typedef struct MP_SESSION
{
	uint8_t  gamemode;
	uint8_t  city;
	uint8_t  timeOfDay;
	uint8_t  weather;
	uint32_t seed;
	uint8_t  numPlayers;
	uint8_t  state;		/* MP_SESSION_* */
	uint16_t spare;
} MP_SESSION;

enum
{
	/* 0 is RETIRED (it was MP_SESSION_LOBBY, a lobby state nothing ever sent).
	 * The NUMBERING is kept deliberately: `state` rides the wire inside
	 * MP_START, so renumbering STARTING to 0 would change what a peer reads. */
	MP_SESSION_STARTING = 1	/* the only value the launch path sets */
};

/* 'JPST' -- host -> client: launch the level with the agreed config. */
typedef struct MP_START
{
	MP_SESSION session;
} MP_START;

/* ------------------------------------------------------------------ */
/* Per-frame input (input lockstep)                                    */
/* ------------------------------------------------------------------ */
typedef struct MP_PLAYER_INPUT
{
	uint8_t  playerId;
	uint16_t pad;		/* engine-native mapped pad bits */
	uint8_t  spare;
} MP_PLAYER_INPUT;

/* 'JPIN' -- one frame's input set. Header followed by count rows. */
typedef struct MP_INPUT
{
	uint8_t  count;
	uint8_t  reserved[3];
} MP_INPUT;

/* ------------------------------------------------------------------ */
/* State resync (fallback when lockstep diverges)                      */
/* ------------------------------------------------------------------ */
/* 'JPCS' -- host -> client periodic snapshot. Header + count rows. */
typedef struct MP_CARSTATE
{
	uint32_t frame;
	uint8_t  count;
	uint8_t  reserved[3];
} MP_CARSTATE;

/* ------------------------------------------------------------------ */
/* An ON-FOOT player's pose.
 *
 * Deliberately NOT bolted onto MP_CARSTATE_ENTRY. A car and a walking person
 * share no fields that matter -- a car has a body orientation and linear and
 * angular velocities, a person has a heading and a speed -- and mixing them
 * would mean every reader of a car state has to remember that half the fields
 * mean something else when one byte says "on foot".
 *
 * There is no animation frame on the wire either: the engine picks the walk, run
 * or idle animation from the SPEED, so carrying the speed carries the animation.
 * The receiving end does the same thing the owning end does -- tell the ped how
 * fast to move -- rather than trying to replay poses. */
typedef struct MP_PEDSTATE_ENTRY
{
	uint8_t  playerId;
	uint8_t  flags;		/* MP_PED_MOVING etc. */
	uint8_t  pedModel;	/* MP_PED_MODEL_*: the owner's current character */
	uint8_t  spare;
	int32_t  x, y, z;	/* the ped's own position, engine units */
	int32_t  heading;	/* 0..4095 */
	int32_t  speed;		/* signed: > 0 forward, < 0 backpedal, 0 standing */
} MP_PEDSTATE_ENTRY;		/* 24 bytes */

static_assert(sizeof(MP_PEDSTATE_ENTRY) == 24, "MP_PEDSTATE_ENTRY layout");

#define MP_PED_MOVING	0x01	/* wheels... rather, legs in motion */

typedef struct MP_PEDSTATE
{
	uint8_t  count;
	uint8_t  reserved[3];	/* [0] = wrapping 1..255 send sequence; 0 = older build (unordered) */
} MP_PEDSTATE;	/* header only, like MP_CARSTATE: the entries follow */

/* A player's chosen colour.
 *
 * `on` is the whole feature: with it 0 the player keeps the colours the game gave
 * their character, which is the DEFAULT and stays the default. r/g/b are 0..255.
 * Sent by the owner (only the owner may say what they look like) and by the host
 * as a whole table when somebody joins, so a late joiner learns everyone. */
typedef struct MP_COLOR_ENTRY
{
	uint8_t playerId;
	uint8_t on;
	uint8_t r, g, b;
	uint8_t pedModel;	/* MP_PED_MODEL_*: identity travels with colour */
	uint8_t spare[2];
} MP_COLOR_ENTRY;		/* 8 bytes */

static_assert(sizeof(MP_COLOR_ENTRY) == 8, "MP_COLOR_ENTRY layout");

typedef struct MP_COLOR
{
	uint8_t  count;
	uint8_t  reserved[3];
} MP_COLOR;	/* header only: the entries follow */

/* A snapshot row carries the car's WHOLE rigid body, not just a position and a
 * heading: hd.direction is an OUTPUT the engine re-derives from the orientation,
 * so a snap that writes only that leaves the receiver's car at the wrong ATTITUDE
 * -- which is how a remote car ends up driving around upside down. Orientation
 * and velocities come straight from st.n (the handling state).
 *
 * There is deliberately NO carSlot here: a CAR_DATA slot number means a different
 * car on two machines (traffic is not replicated), so moving a player by slot
 * warps them into an unrelated car. Vehicles are matched by MODEL, in place
 * (MpAdoptRemoteCar). */
#define MP_CARSTATE_HAS_BODY	1
#define MP_CARSTATE_SIREN	8	/* owner has siren/lights on (police car) */
/* The body we are in now is the SAME `car_data` slot we last got out of (this
 * machine's slot -- the peers know which body they released for us). The owner
 * sets it whenever they walk back into the car they left, or use the pause menu's
 * Change car while on foot: `MpChangeCarRun` re-enters their parked car and
 * re-models it in place. Without this a peer could only see "was on foot, now
 * reports a car" and its re-seat pass would build a SECOND vehicle, leaving the
 * body it released standing where it was. An unknown bit is ignored by older
 * readers, and an older sender simply never sets it, so no protocol bump. */
#define MP_CARSTATE_SAME_BODY	2

/* The NO_CAR row also describes the car the owner walked away from: leftModel /
 * leftModelCity name it, and the row's palette, x/y/z and heading carry its
 * colour and pose. A machine that was present when the owner got out already has
 * that body and ignores this; a joiner that arrived afterwards uses it to build
 * the parked CIV_AI car instead of seeing a player whose car never existed. */
#define MP_CARSTATE_LEFT_CAR	4

/* entry.model when the owner is on foot: no vehicle to drive, so the peers
 * release the car they were driving for them (it stays in the world). */
#define MP_CARSTATE_NO_CAR	0xFF

typedef struct MP_CARSTATE_ENTRY
{
	uint8_t  playerId;
	uint8_t  flags;		/* MP_CARSTATE_HAS_BODY | MP_CARSTATE_SIREN */
	uint8_t  palette;	/* owner's car colour (cp->ap.palette) -- owner-authoritative */
	uint8_t  model;		/* the VEHICLE the owner is driving (cp->ap.model);
				 * MP_CARSTATE_NO_CAR = on foot, so the peers stop
				 * driving our old car and leave it where it was */
	uint8_t  modelCity;	/* city `model` belongs to: MP_CAR_CITY_SESSION = the
				 * session's city, 0..CITY_COUNT-1 = a cross-city import */
	int16_t  orient[4];	/* st.n.orientation */
	int32_t  x, y, z;	/* world units */
	int32_t  heading;	/* hd.direction */
	int32_t  angVel[3];	/* st.n.angularVelocity -- int32, NOT int16: the engine's
				 * angular velocity routinely exceeds 16 bits (a spin
				 * reaches +-1.5 MILLION), so a 16-bit field truncated
				 * every snapshot into a different spin. */
	int32_t  vel[3];	/* st.n.linearVelocity */
	uint8_t  leftModel;	/* MP_CARSTATE_LEFT_CAR: the parked car's model NUMBER */
	uint8_t  leftModelCity;	/* ...and the city that number belongs to */
	uint8_t  hubcaps;	/* bits 0..3 = hubcap LOST on wheel 0..3 (cp->ap.flags low
				 * nibble). Appearance is owner-authoritative, exactly like
				 * the palette: LoseHubcap writes it on the owner's machine and
				 * nothing else clears it. */
	uint8_t  crushScale;	/* owner's body-crush multiplier in HALF steps:
				 * 2 = 1.0x, 20 = 10.0x (0/1 read as 1.0x). Per CAR,
				 * not per player -- mp applies it to the car this row
				 * names, so every machine deforms that body alike. */
} MP_CARSTATE_ENTRY;

/* ------------------------------------------------------------------ */
/* Replicated TRAFFIC (civilians and police).
 *
 * Unlike a player car, this row MUST carry the car_data SLOT it lives in: the
 * two machines hold disjoint traffic bands (see the band section in
 * mp_session.c), so a slot number is the shared identity -- slot 9 is "the same"
 * car on both machines by construction, and the receiver mirrors the state into
 * exactly that slot. That is the one respect in which traffic differs from a
 * player car, which is matched by MODEL precisely because a slot means nothing
 * there.
 *
 * A police car needs no separate message: it is the level's own police MODEL
 * (model 0, the car CarHasSiren keys off), carried here like any other, and
 * whether its siren and lightbar are ON rides the flags byte -- because the
 * receiver builds it as a posed mirror, not as an AI pursuer, so the engine's
 * PURSUER_AI test cannot answer it there. Its TARGET, though, is a player id
 * and does NOT ride this generic row. */
#define MP_TRAFFIC_REMOVE	0x01	/* this row says "the car in carSlot is gone" */
#define MP_TRAFFIC_SIREN	0x02	/* this police car is on duty: siren + lightbar up */

#pragma pack(push, 1)
typedef struct MP_TRAFFIC_ENTRY
{
	uint8_t  carSlot;	/* the car_data slot on BOTH machines -- the shared identity */
	uint8_t  flags;		/* MP_TRAFFIC_* */
	uint8_t  model;		/* the vehicle (residentCarModels[ap.model]) */
	uint8_t  modelCity;	/* city `model` belongs to; MP_CAR_CITY_SESSION = the session's */
	uint8_t  palette;	/* cp->ap.palette -- the owner is the colour authority */
	uint8_t  reserved1;
	int16_t  damage[6];	/* cp->ap.damage[]: the zone damage the DENTED mesh is built
				 * from -- DentCarDirectional deforms from these alone, so the
				 * mirror can be re-dented without moving any vertices */
	uint16_t totalDamage;	/* cp->totalDamage: the health a wreck/smoke FX keys off */
	int16_t  orient[4];	/* st.n.orientation */
	int32_t  x, y, z;	/* world units */
	int32_t  heading;	/* hd.direction */
	int32_t  vel[3];	/* st.n.linearVelocity; angular velocity is not worth the bytes
				 * for a civilian -- they do not spin like a car in a firefight */
} MP_TRAFFIC_ENTRY;

/* 'JPTF' -- header followed by count rows. Sent by the OWNER of each car (the
 * machine whose band holds it); the host relays a client's rows on. */
typedef struct MP_TRAFFIC
{
	uint32_t frame;
	uint8_t  count;
	uint8_t  reserved[3];
} MP_TRAFFIC;
#pragma pack(pop)

/* ------------------------------------------------------------------ */
/* Addon network bridge ('JPCH')                                       */
/* ------------------------------------------------------------------ */

/* A registered channel id is a short name; the payload follows the header. */
typedef struct MP_CHANNEL
{
	char     name[MP_CHANNEL_NAME_MAX];
	uint16_t len;
	uint32_t frame;		/* 0 = out-of-band (latest-wins) */
	uint8_t  reliable;
	uint8_t  fromPlayer;
	uint8_t  reserved[2];
} MP_CHANNEL;

/* Ping/pong carry a tick the peer echoes. */
typedef struct MP_PING
{
	uint32_t tick;
} MP_PING;

#define MP_PONG MP_PING

typedef struct MP_CAR
{
	uint8_t  model;		/* the chosen model; 0xFF = none */
	uint8_t  city;		/* 0..3 = the city it belongs to, 0xFF = the session's own */
	uint8_t  reserved[2];	/* [0] palette, [1] 1 = [0] is set (optional; old peers send 0) */
} MP_CAR;

/* A chat line: a player's message, announced to every seat. */
#define MP_CHAT_TEXT_MAX	96

typedef struct MP_CHAT
{
	uint8_t playerId;
	/* The speaker's ink when the SERVER is speaking (a dedicated server's motd):
	 * r, g, b, all zero for an ordinary chat line. Old builds ignore it and print
	 * in the usual colour, which is why this needs no protocol bump. */
	uint8_t reserved[3];
	char    text[MP_CHAT_TEXT_MAX];
} MP_CHAT;

/* MP_CHAT.reserved = { MP_CHAT_MARK_ADMIN, 0, 0 } on a PLAYER's line: a dedicated
 * server saying the speaker is one of its admins; the client then shows "[Admin] name".
 * Old builds ignore it (ink is honoured only for a speaker with no player row). A game
 * host clears it on what it relays, so a peer cannot mark itself. */
#define MP_CHAT_MARK_ADMIN	0x01

/* The host removing a player. `playerId` names the row being removed (the
 * connection it travels on is the same thing, but the id is self-documenting
 * and lets the client assert the two agree). Reliable: a lost kick must not
 * leave the client sitting in a match the host no longer has it in. */
typedef struct MP_KICK
{
	uint8_t playerId;
	uint8_t reserved[3];
} MP_KICK;

/* Optional tail: a KICK may be followed by MP_KICK_TEXT_LEN bytes of
 * NUL-terminated text the kicked player is shown instead of the stock
 * "You were kicked by the host" (e.g. "Kicked by admin: <reason>"). Old
 * clients read only the 4-byte head, so no protocol bump. */
#define MP_KICK_TEXT_LEN	64

/* MP_KICK.reserved[0] flags. Old clients ignore them (a plain kick). */
#define MP_KICK_FLAG_REJOIN	0x01	/* the server is changing city: rejoin it shortly */

/* A contact report. Cars are owner-authoritative, so a machine can only move
 * the ONE car it owns: when MY car touches YOURS I push MINE, and I send you
 * this so you push YOURS. Both cars move, and each stays the owner's truth.
 *
 * A TRAFFIC contact rides the same message. `targetId` names a player for a car,
 * but a car_data SLOT when MP_HIT_F_TRAFFIC is set -- the band is disjoint, so the
 * slot is already the shared traffic identity (see MP_TRAFFIC_ENTRY). Only the
 * owner of that slot applies the impulse: on the observer the mirror is rewritten
 * verbatim every frame, so a push there would be discarded. */
#define MP_HIT_F_TRAFFIC	0x01	/* targetId is a car_data slot, not a player id */

/* Each player's link as the HOST measures it (MpPeerStats), so every machine can
 * show rx / tx / loss for everyone, not only for its own connection. Sent with
 * the roster. A client only has a link to the host, which is why this travels. */
#define MP_STATS_LOSS_UNKNOWN	0xFF	/* this hub does not measure loss */

typedef struct MP_STATS_ENTRY
{
	uint8_t  playerId;
	uint8_t  lossPct;	/* 0..100, or MP_STATS_LOSS_UNKNOWN */
	uint16_t pingMs;
	uint32_t rxBps;		/* bytes/s the host RECEIVES from this player */
	uint32_t txBps;		/* bytes/s the host SENDS to this player */
} MP_STATS_ENTRY;		/* 12 bytes */

typedef struct MP_STATS
{
	uint8_t  count;
	uint8_t  reserved[3];
} MP_STATS;	/* header only: the entries follow */

typedef struct MP_HIT
{
	uint8_t  targetId;	/* the player whose car should receive the impulse */
	uint8_t  flags;		/* MP_HIT_F_* */
	uint8_t  reserved[2];
	int32_t  impulse[3];	/* velocity delta to ADD to the target's car */

	/* WHERE AND WHEN the contact happened, in the TARGET's own timeline.
	 *
	 * The sender collided with the pose its interpolation playout was
	 * displaying, so `targetFrame` is a carstate frame number the TARGET
	 * itself sent, and `tgtPos` is that same pose in world units. The target
	 * can therefore look the frame up in its own short pose history and check
	 * that it really was there -- a push that names a frame the target never
	 * occupied, or that arrives long after the cars have separated, is a
	 * ghost and is dropped instead of applied.
	 *
	 * 0 means "no timeline" (a sender that has not played this player yet).
	 * The receiver treats it as unvalidatable and drops the push; contacts
	 * only arm 120 frames into a match, by which point the buffer is primed. */
	uint32_t targetFrame;	/* the TARGET's carstate frame at the contact */
	int32_t  tgtPos[3];	/* the sender's view of the target car at that frame */
} MP_HIT;

#pragma pack(pop)

/* Compile-time layout checks (modules compile as C++). */
#ifdef __cplusplus
static_assert(sizeof(MP_ENVELOPE) == 12, "MP_ENVELOPE layout");
static_assert(sizeof(MP_BEACON) == 50, "MP_BEACON layout");
static_assert(sizeof(MP_MOD_INFO) == 42, "MP_MOD_INFO layout");
static_assert(sizeof(MP_HELLO) == 44, "MP_HELLO layout");
static_assert(sizeof(MP_WELCOME) == 18, "MP_WELCOME layout");	/* 18 since v11 (rules) */
static_assert(sizeof(MP_REJECT) == 68, "MP_REJECT layout");
static_assert(sizeof(MP_SESSION) == 12, "MP_SESSION layout");
static_assert(sizeof(MP_PLAYER_INPUT) == 4, "MP_PLAYER_INPUT layout");
static_assert(sizeof(MP_INPUT) == 4, "MP_INPUT layout");
static_assert(sizeof(MP_ROSTER_ENTRY) == 32, "MP_ROSTER_ENTRY layout");
static_assert(sizeof(MP_CARSTATE_ENTRY) == 57, "MP_CARSTATE_ENTRY layout");
static_assert(sizeof(MP_HIT) == 32, "MP_HIT layout");
static_assert(sizeof(MP_STATS_ENTRY) == 12, "MP_STATS_ENTRY layout");
static_assert(sizeof(MP_CARSTATE) == 8, "MP_CARSTATE layout");
static_assert(sizeof(MP_TRAFFIC_ENTRY) == 56, "MP_TRAFFIC_ENTRY layout");
static_assert(sizeof(MP_TRAFFIC) == 8, "MP_TRAFFIC layout");
static_assert(sizeof(MP_CHANNEL) == 26, "MP_CHANNEL layout");

#endif

#ifdef __cplusplus
}
#endif

#endif /* MP_PROTO_H */
