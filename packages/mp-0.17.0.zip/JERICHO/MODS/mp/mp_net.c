/*
 * mp_net.c -- JERICHO Multiplayer transport.
 *
 * Non-blocking TCP session + UDP LAN discovery beacon. The socket layer
 * mirrors the proven gaildrv2.c approach:
 *
 *   - Windows: winsock2 (included BEFORE windows.h; the PSX libapi.h
 *     OpenEvent clash is defused), ws2_32 linked via #pragma.
 *   - Linux: plain BSD sockets.
 *   - session sockets are NON-blocking (MpSetNonBlocking), and recv only runs
 *     when select() reports something to read, so no socket call can stall a
 *     frame; SO_SNDTIMEO is set as a belt-and-braces backstop.
 *     The listen socket is non-blocking too, so accept() never hangs.
 *
 * Framing and the message catalog live in mp_proto.h. Complete messages
 * are handed to MpHandleMessage() (mp_session.c) which owns the semantics.
 */
#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <windows.h>
   /* Adapter list, for the per-interface broadcast addresses below. */
#  include <iphlpapi.h>
#  pragma comment(lib, "ws2_32.lib")
#  pragma comment(lib, "iphlpapi.lib")
   /* The Windows SDK renames OpenEvent -> OpenEventW under UNICODE, which
    * would clash with the PSX shim; kill the macro. */
#  undef OpenEvent
#else
#  include <sys/socket.h>
#  include <sys/ioctl.h>
#  include <netinet/in.h>
#  include <netinet/tcp.h>
#  include <arpa/inet.h>
#  include <netdb.h>		/* getaddrinfo: a join target may be a DNS name */
#  include <unistd.h>
#  include <fcntl.h>
#  include <sys/time.h>	/* gettimeofday for MpClockMs - NOT <time.h>, see there */
   /* NO <time.h> HERE. The game ships Game/C/time.h (GetTimeStamp) and Game/C is
    * on the include path, so an angle-bracket time.h resolves to THAT and
    * clock_gettime/CLOCK_MONOTONIC are never declared. Worse, that shadow also
    * breaks a C++ header which pulls <ctime> - chrono, say - on Windows, whose
    * internal <time.h> is hijacked the same way. MpClockMs sidesteps both. */
#  include <errno.h>
#  include <ifaddrs.h>
#  include <net/if.h>
   typedef int SOCKET;
#  define INVALID_SOCKET (-1)
#  define SOCKET_ERROR   (-1)
#  define closesocket close
#  define ioctlsocket(s, cmd, argp) ioctl((s), (cmd), (argp))
#endif

/* Last socket error and the two connection-reset codes, spelled once so the
 * call sites do not have to know which platform they are on. Windows reports
 * these through Winsock's WSA* codes, POSIX through errno; the POSIX build does
 * not compile while a call site names the Windows spelling directly. */
#ifdef _WIN32
#  define MP_LAST_ERROR()	WSAGetLastError()
#  define MP_ECONNRESET		WSAECONNRESET
#  define MP_ECONNABORTED	WSAECONNABORTED
/* NOT a transient stack hiccup: this says the handle is not a socket any more, i.e. the
 * connection has already been closed -- by us. Winsock spells it 6, POSIX as EBADF. */
#  define MP_EBADHANDLE		WSA_INVALID_HANDLE
#else
#  define MP_LAST_ERROR()	errno
#  define MP_ECONNRESET		ECONNRESET
#  define MP_ECONNABORTED	ECONNABORTED
#  define MP_EBADHANDLE		EBADF
#endif

#include "jericho.h"
#include "mp.h"
#include "jer_console.h"	/* the unified status console (jer_console_log) */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>		/* malloc/free for the adapter list */

/* The largest frame this side will accept: the envelope plus a payload of 8192, which is the
 * limit the parser enforces on env.len below. THE BUFFER MUST HOLD ONE OF THESE. It did not:
 * the limit accepted a 8196-byte frame and the buffer was 8192, so a maximal frame could
 * never be assembled and the peer was dropped for sending something the protocol allows. */
#define MP_RECV_MAX_FRAME	(MP_ENVELOPE_SIZE + 8192)
#define MP_RECV_BUF		(MP_RECV_MAX_FRAME + 512)	/* room for a second, partial one */
#define MP_SEND_BUF		2048
#define MP_SEND_QUEUE	8192	/* frames waiting for a busy socket */
#define MP_ACCEPT_BACKLOG	8
#ifdef _WIN32
#  define MP_SHUT_WR		SD_SEND
#else
#  define MP_SHUT_WR		SHUT_WR
#endif

#define MP_CLOSE_GRACE_MS	2000	/* how long a half-closed (refused) peer may
								 * take to read its rejection before we
								 * stop waiting and close the socket */
#define MP_HANDSHAKE_TIMEOUT_MS	5000	/* a peer that connects and then says
								 * nothing is not a player: give up on it
								 * long before the idle timeout */
/* MP_CONN_TIMEOUT_MS (now in mp_proto.h) is the default idle drop: a peer silent
 * this long is dropped, unless idle_drop_ms is set to 0 to disable it. It was
 * 10 s, and the busy guard that excuses a SILENT LEVEL LOAD is OUR OWN flag
 * (MpBusy) -- the peer's is not visible to us, so a peer that was loading (or
 * just hitching) for longer than 10 s got dropped by the OTHER side: the "it
 * disconnects after a while" report. Real liveness still comes from the 1 s
 * keepalive, which is why this grace can be generous. */
#define MP_CONNECT_TIMEOUT_MS	5000

/* ------------------------------------------------------------------ */
/* Connection table                                                    */
/* ------------------------------------------------------------------ */
typedef struct MP_CONN
{
	int           used;
	SOCKET        sock;
	int           hostSide;	/* 1 = a peer connected to us (host role) */
	int           playerId;	/* assigned during the handshake, -1 until then */
	int           hsDone;	/* HELLO/WELCOME exchanged: no longer a stranger */
	unsigned long acceptedMs;	/* when the connection was adopted */
	int           closing;	/* we half-closed this peer (refused it): drain, then close */
	unsigned long closingSinceMs;
	unsigned long lastRecvMs;
	unsigned char rbuf[MP_RECV_BUF];
	int           rbufLen;
	unsigned long rxBytes;	/* bytes received in total. "the peer never
							 * spoke" and "the peer spoke, then died" are
							 * different problems with different causes, and a
							 * bare "closed" cannot tell them apart. */
	unsigned long txBytes;	/* bytes handed to this peer, for the on-screen rate */
	char          peer[32];	/* "ip:port" of the far end, for the log */
	int           hsStage;	/* client: how far the join got (MP_HS_*) */
	unsigned long pingMs;	/* round trip, from the PING/PONG tick */
	unsigned long lossMarkMs;	/* lastRecvMs as of the previous sample (delivery stat) */
	int           lossPct;	/* EWMA of the % of polls in which NOTHING arrived (0..100) */
	unsigned char sbuf[MP_SEND_QUEUE];	/* frames waiting for the socket */
	int           sbufLen;
	int           sbufOff;	/* bytes already written out */
	int           stageSeen;	/* the stage the timer is measuring */
	unsigned long stageSinceMs;	/* when the current stage began ("time in state") */
	char          lastEvent[40];	/* what happened last, for the on-screen line */
	unsigned long lastEventMs;	/* when it happened */
} MP_CONN;

static MP_CONN gConn[MP_MAX_PLAYERS];
static SOCKET  gListen = INVALID_SOCKET;	/* host listener */
static int     gNetStarted;
static unsigned long gLastPollMs;	/* when we last serviced the sockets */

/* How far a join got. A bare "connection lost" says nothing useful: the stage
 * says whether the server was never reached, accepted the TCP connection but
 * never answered the handshake, or dropped a running match. */
enum {
	MP_HS_NONE = 0,
	MP_HS_CONNECTING, MP_HS_CONNECTED, MP_HS_HELLO_SENT,
	MP_HS_WELCOME, MP_HS_PLAYING
};

static const char* MpStageName(int s)
{
	switch (s)
	{
	case MP_HS_CONNECTING: return "still connecting";
	case MP_HS_CONNECTED:  return "connected, handshake not sent";
	case MP_HS_HELLO_SENT: return "HELLO sent, no WELCOME";
	case MP_HS_WELCOME:    return "WELCOME received, awaiting the level";
	case MP_HS_PLAYING:    return "in the match";
	default:               return "not connecting";
	}
}

/* "ip:port" of the far end of a socket, for logs. Worth the effort: without it
 * a drop says nothing about WHICH machine failed to reach which. */
static void MpPeerName(SOCKET s, char* out, size_t cap)
{
	struct sockaddr_in a;
	int len = (int)sizeof a;

	out[0] = 0;
	if (s == INVALID_SOCKET) { snprintf(out, cap, "?"); return; }

	if (getpeername(s, (struct sockaddr*)&a, &len) == 0)
	{
		const unsigned char* ip = (const unsigned char*)&a.sin_addr.s_addr;
		snprintf(out, cap, "%u.%u.%u.%u:%u",
			ip[0], ip[1], ip[2], ip[3], (unsigned)ntohs(a.sin_port));
	}
	else
		snprintf(out, cap, "?");
}

/* ------------------------------------------------------------------ */
/* Platform helpers                                                    */
/* ------------------------------------------------------------------ */
static unsigned long MpClockMs(void)
{
#ifdef _WIN32
	return GetTickCount();
#else
	/* Milliseconds. NOT via <time.h>: the game's Game/C/time.h shadows it on
	 * this include path, so clock_gettime/CLOCK_MONOTONIC are not declared, and a
	 * C++ header that pulls <ctime> breaks on Windows for the same reason (see
	 * the include note above). gettimeofday is wall-clock rather than monotonic,
	 * which is a caveat for a timeout clock, but it is what this platform offers
	 * without the shadowed header. */
	struct timeval tv;

	gettimeofday(&tv, NULL);

	return (unsigned long)(tv.tv_sec * 1000ULL + tv.tv_usec / 1000);
#endif
}

unsigned long MpNowMs(void)
{
	return MpClockMs();
}

/* No crash DIALOGS, process-wide. See the module entry for why.
 *
 * It lives HERE because this file already includes the Windows headers in the
 * right order (winsock2 before windows.h -- see the top of the file); mp.c
 * deliberately includes none of that, and pulling windows.h into it risks the
 * clashes the include order exists to avoid. */
void MpSuppressCrashDialogs(void)
{
#ifdef _WIN32
	SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
#endif
}

static int MpPendingBytes(SOCKET s)
{
#ifdef _WIN32
	unsigned long n = 0;
	ioctlsocket(s, FIONREAD, &n);
	return (int)n;
#else
	int n = 0;
	ioctl(s, FIONREAD, &n);
	return n;
#endif
}

static void MpSetNonBlocking(SOCKET s, int on)
{
#ifdef _WIN32
	unsigned long mode = on ? 1 : 0;
	ioctlsocket(s, FIONBIO, &mode);
#else
	int fl = fcntl(s, F_GETFL, 0);
	if (on) fcntl(s, F_SETFL, fl | O_NONBLOCK);
	else    fcntl(s, F_SETFL, fl & ~O_NONBLOCK);
#endif
}

/* Connection tuning. TCP_NODELAY only.
 *
 * SO_SNDTIMEO used to be set here too (250 ms), as belt-and-braces against a
 * blocking send stalling the frame, and it was WRONG to have it: the session
 * sockets are NON-BLOCKING (MpSetNonBlocking), so nothing here can wait on a
 * send, and on Windows the stack still enforces SO_SNDTIMEO on such a socket --
 * the documented outcome of it tripping is an ABORTED connection, which is
 * exactly the WSAECONNABORTED (10053) that "send failed" reported. Removed
 * rather than lowered: there is no timeout to want. (The disconnects themselves
 * turned out to be the clock underflow in the idle timeout -- see MpElapsedMs --
 * but a timeout that can abort a healthy socket has no business here either.) */
static void MpTuneConn(SOCKET s)
{
	int one = 1;

	setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char*)&one, sizeof(one));
}

static void MpDropConn(int idx, const char* why);	/* used by the send queue */
static void MpLinkTick(unsigned long now);		/* link-state logging, MP_DEBUG only */

/* Would this send only have had to wait? Non-blocking sockets say so this way,
 * and it is NOT an error -- it is the normal case on a busy link. */
static int MpWouldBlock(void)
{
#ifdef _WIN32
	int e = WSAGetLastError();

	return e == WSAEWOULDBLOCK || e == WSAEINPROGRESS;
#else
	return errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR;
#endif
}

/* Milliseconds between two of OUR clock reads, never negative.
 *
 * A timestamp stamped DURING a poll can be LATER than the `now` the poll read at
 * its top: MpNetPoll reads the clock once and then, several steps later, the
 * receive path stamps each arrival as it happens. GetTickCount moves in ~15 ms
 * steps, so an arrival in this poll is regularly stamped one tick ahead of `now`.
 * `now - then` is then a small negative number -- and in UNSIGNED arithmetic that
 * is a huge positive one, so `(now - lastRecvMs) > idle_drop_ms` was TRUE in the
 * very poll that heard from the peer: the connection was dropped for "timeout"
 * immediately after a successful read, on both ends, once every few tens of
 * seconds of play. That is the long-standing "it disconnects after about a
 * minute" report. Always compare via this helper. */
static unsigned long MpElapsedMs(unsigned long now, unsigned long then)
{
	long d = (long)(now - then);

	return (d < 0) ? 0UL : (unsigned long)d;
}

/* Write whatever is queued for this peer. 1 = still fine (possibly with bytes
 * left to send), 0 = the peer is gone. */
static int MpFlushConn(int idx)
{
	MP_CONN* c;

	if (idx < 0 || idx >= MP_MAX_PLAYERS || !gConn[idx].used)
		return 0;

	c = &gConn[idx];

	while (c->sbufOff < c->sbufLen)
	{
		int n = send(c->sock, (const char*)c->sbuf + c->sbufOff, c->sbufLen - c->sbufOff, 0);

		if (n > 0)
		{
			if (MpDebugOn() && gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] wrote %d byte(s) conn=%d\n", n, idx);

			c->sbufOff += n;
			continue;
		}

		if (n < 0)
		{
			/* Capture the error BEFORE MpWouldBlock(), which asks the stack
			 * again. The recv path already says which errno it saw; the send
			 * path used to say nothing at all, so the one failure that ends a
			 * session ("send failed") arrived with no code attached. */
			int err = MP_LAST_ERROR();

			if (MpWouldBlock())
				return 1;	/* it will take more next poll */

			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx,
					"[mp] send error %d conn=%d queued=%d\n",
					err, idx, c->sbufLen - c->sbufOff);
		}

		return 0;			/* a real error: this peer is gone */
	}

	c->sbufLen = 0;
	c->sbufOff = 0;

	return 1;
}

/* Queue a frame and write what the socket will take now.
 *
 * This used to hand the bytes straight to send() and DROP the frame whenever the
 * non-blocking socket was not ready -- and, worse, give up after a partial write,
 * leaving half a frame on the wire. Both are fatal for a reliable frame: a lost
 * WELCOME leaves the joining player sitting there until their timeout expires,
 * and a half-written frame desynchronises the stream for good. Bytes the socket
 * will not take yet wait in the queue and go out on the next poll instead. */
static int MpSendRaw(int idx, const void* data, int len)
{
	MP_CONN* c;

	if (idx < 0 || idx >= MP_MAX_PLAYERS || !gConn[idx].used)
		return 0;

	c = &gConn[idx];

	/* whatever was already written is finished with: close the gap */
	if (c->sbufOff > 0)
	{
		int left = c->sbufLen - c->sbufOff;

		if (left > 0)
			memmove(c->sbuf, c->sbuf + c->sbufOff, (size_t)left);

		c->sbufLen = left;
		c->sbufOff = 0;
	}

	if (len > 0 && c->sbufLen + len > (int)sizeof(c->sbuf))
	{
		/* a peer that will not read even this much is not coming back */
		MpDropConn(idx, "peer is not reading");
		return 0;
	}

	if (len > 0)
	{
		memcpy(c->sbuf + c->sbufLen, data, (size_t)len);
		c->sbufLen += len;
		c->txBytes += (unsigned long)len;
	}

	MpFlushConn(idx);

	return 1;
}

/* ------------------------------------------------------------------ */
/* Lifecycle                                                           */
/* ------------------------------------------------------------------ */
int MpNetStart(void)
{
#ifdef _WIN32
	WSADATA wsa;

	if (gNetStarted)
		return 1;

	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 0;
#endif
	gNetStarted = 1;
	memset(gConn, 0, sizeof(gConn));

	return 1;
}

static void MpCloseSock(SOCKET* s)
{
	if (*s != INVALID_SOCKET)
	{
		if (MpDebugOn() && gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] MpCloseSock(%llu)\n", (unsigned long long)*s);

		closesocket(*s);
		*s = INVALID_SOCKET;
	}
}

void MpNetShutdown(void)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used)
		{
			MpCloseSock(&gConn[i].sock);
			gConn[i].used = 0;
			gConn[i].rbufLen = 0;
		}
	}

	MpDiscoveryStop();
	MpCloseSock(&gListen);

	/* The UPnP worker (if any) must stop before Winsock is torn down; it deletes
	 * its mappings best-effort and exits on its own. */
	MpUpnpStop();

#ifdef _WIN32
	if (gNetStarted)
		WSACleanup();
#endif
	gNetStarted = 0;
}

/* ------------------------------------------------------------------ */
/* Host: listen / accept                                               */
/* ------------------------------------------------------------------ */
/* Tell every connected player we are ending the match, before the sockets
 * close, so they can go back to their frontend with a proper notice. */
void MpHostByeAll(void)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used && gConn[i].hostSide)
		{
			MpSendConn(i, MP_TAG_LEAVE, MP_FLAG_RELIABLE, NULL, 0);

			/* Flush it: a queued goodbye that is never written is the same as no
			 * goodbye at all, and the socket is about to close. */
			MpFlushConn(i);
		}
	}
}

/* Client: tell the host we are going, before the socket closes -- and do it in a
 * way that actually ARRIVES.
 *
 * Sending the LEAVE is not enough on its own. Closing a socket that still has
 * unread inbound data makes the OS send RST, and an RST makes the RECEIVER throw
 * away data it had already received but not yet read -- so the goodbye was
 * discarded and the host reported a player who pressed Exit as "connection reset
 * (WSAECONNRESET)". A deliberate quit and a crash were literally indistinguishable
 * from the far end.
 *
 * The fix is a proper half-close: send, push a FIN with shutdown(SD_SEND), then
 * read whatever is already in flight for a moment so the host gets the chance to
 * see it before the socket goes away. Only the host had a goodbye (MpHostByeAll);
 * this is the other half. */
void MpClientBye(void)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		char drain[1024];
		unsigned long until;

		if (!gConn[i].used || gConn[i].hostSide)
			continue;

		MpSendConn(i, MP_TAG_LEAVE, MP_FLAG_RELIABLE, NULL, 0);
		MpFlushConn(i);

		if (gConn[i].sock == INVALID_SOCKET)
			continue;

		shutdown(gConn[i].sock, MP_SHUT_WR);

		/* Bounded: this runs while leaving, so a long stall here would look like
		 * a freeze. 150 ms is several round trips on a LAN. */
		until = MpNowMs() + 150;

		while (MpNowMs() < until)
		{
			int n = recv(gConn[i].sock, drain, (int)sizeof(drain), 0);

			if (n > 0)
				continue;

			if (n == 0)
				break;			/* the far end said goodbye as well */

			if (MpWouldBlock())
			{
				#ifdef _WIN32
		Sleep(5);
#else
		usleep(5000);	/* POSIX: Sleep() takes ms, usleep() takes us */
#endif
				continue;
			}

			break;
		}
	}
}

int MpHostBegin(void)
{
	struct sockaddr_in addr;
	int one = 1;

	if (!gNetStarted && !MpNetStart())
		return 0;

	if (gListen != INVALID_SOCKET)
		return 1;	/* already listening */

	gListen = socket(AF_INET, SOCK_STREAM, 0);
	if (gListen == INVALID_SOCKET)
		return 0;

	setsockopt(gListen, SOL_SOCKET, SO_REUSEADDR, (const char*)&one, sizeof(one));

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons((unsigned short)gMp.config.port);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);

	/* This bind, on INADDR_ANY, is what makes Windows show its "Allow this app"
	 * firewall prompt the first time a game is hosted -- deliberately no netsh /
	 * rule-writing here. Keep it a plain bind on the wildcard address: an
	 * interface-specific bind would not trigger the prompt the same way. */
	if (bind(gListen, (struct sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR)
	{
		MpCloseSock(&gListen);
		return 0;
	}

	if (listen(gListen, MP_ACCEPT_BACKLOG) == SOCKET_ERROR)
	{
		MpCloseSock(&gListen);
		return 0;
	}

	MpSetNonBlocking(gListen, 1);

	gMp.listenersUp = 1;
	if (gMpCtx) gMpCtx->jer_log(gMpCtx, "[mp] listening on TCP/%d\n", gMp.config.port);

	return 1;
}

void MpHostEnd(void)
{
	MpCloseSock(&gListen);
	gMp.listenersUp = 0;
}

static int MpAllocConn(void)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (!gConn[i].used)
		{
			memset(&gConn[i], 0, sizeof(gConn[i]));
			gConn[i].used = 1;
			gConn[i].playerId = -1;
			gConn[i].acceptedMs = MpClockMs();
			gConn[i].stageSinceMs = gConn[i].acceptedMs;
			gConn[i].stageSeen = -1;	/* so the first event starts the clock */
			return i;
		}
	}

	return -1;
}

static void MpAcceptPeers(void)
{
	for (;;)
	{
		SOCKET s = accept(gListen, NULL, NULL);
		int idx;

		if (s == INVALID_SOCKET)
			break;

		idx = MpAllocConn();
		if (idx < 0)
		{
			closesocket(s);	/* full */
			continue;
		}

		/* NON-BLOCKING in BOTH directions. The recv loop is guarded by select() and
		 * treats WSAEWOULDBLOCK as "nothing yet", and the SEND path relies on it
		 * too (MpFlushConn queues whatever the socket will not take yet). A
		 * BLOCKING socket here was a real bug: when the peer's receive window
		 * filled, send() blocked INSIDE the game loop, the match froze for a few
		 * seconds, and the peer then timed us out and dropped the session. */
		MpSetNonBlocking(s, 1);
		MpTuneConn(s);
		gConn[idx].sock = s;
		gConn[idx].hostSide = 1;
		gConn[idx].lastRecvMs = MpClockMs();
		MpPeerName(s, gConn[idx].peer, sizeof gConn[idx].peer);

		if (gMpCtx) gMpCtx->jer_log(gMpCtx, "[mp] peer %s connected (awaiting handshake)\n",
			gConn[idx].peer);

		/* NOT MpConnEvent here: the master's reachability prober (and any port
		 * scanner) opens a bare TCP connect to this port every few seconds and closes
		 * it without a byte. Announcing each one on the console made a listed host
		 * look like it was flapping with the master. A real peer is announced as
		 * soon as its handshake arrives. */
	}
}

/* ------------------------------------------------------------------ */
/* Client: join state + the asynchronous connect plumbing              */
/*                                                                     */
/* The frontend must never freeze on a join, so the UI path starts the  */
/* connect and lets MpClientConnectPoll() finish it on a later frame,   */
/* while the menu shows "Connecting to <host>:<port>...".               */
/* ------------------------------------------------------------------ */
static SOCKET gConnectingSock = INVALID_SOCKET;
static char   gConnectingHost[64];
static int    gConnectingPort;
static unsigned long gConnectingSinceMs;
static int    gJoinState = MP_JOIN_IDLE;

int MpJoinState(void)
{
	return gJoinState;
}

void MpJoinStateSet(int state)
{
	gJoinState = state;

	/* The connection was accepted: the retries did their job (or none were needed), so the
	 * next join starts counting from one again. Done HERE rather than at the WELCOME handler
	 * because this is the single setter for the join state, so no path can reach READY
	 * without clearing it. */
	if (state == MP_JOIN_READY)
		MpJoinRetryClear();
}

const char* MpJoinTarget(void)
{
	return gConnectingHost;
}

int MpJoinTargetPort(void)
{
	return gConnectingPort;
}

/* Join retries (see MpJoinFail): the statics live here, above MpClientDisconnect, because
 * that function cancels a pending retry. */
#define MP_JOIN_ATTEMPTS	3
#define MP_JOIN_RETRY_MS	1200

static int gJoinAttempt;		/* 1..MP_JOIN_ATTEMPTS for the target being tried */
static unsigned long gJoinRetryAtMs;	/* a retry is due at this time, 0 = none pending */

/* The connection was accepted: the retries did their job (or none were needed), so the next
 * join starts counting from one again. Called where the join state goes READY, and from the
 * join entry point. NOT from the connect itself - the retry path goes through there, and
 * resetting it there would make the retries endless. */
void MpJoinRetryClear(void)
{
	gJoinAttempt = 0;
	gJoinRetryAtMs = 0;
}

static void MpClientConnectCancel(void)
{
	MpCloseSock(&gConnectingSock);
}

/* ------------------------------------------------------------------ */
/* Client: disconnect                                                   */
/* ------------------------------------------------------------------ */
/* The join itself is always ASYNCHRONOUS (MpClientConnectBegin +
 * MpClientConnectPoll), so the frontend can show "Connecting to ..." instead of
 * freezing; there is no blocking connect variant. */

void MpClientDisconnect(void)
{
	int i;

	/* A cancelled or abandoned join must not come back to life: a retry the last failed
	 * attempt asked for would otherwise fire ~1.2 s later, reconnecting to a server the
	 * player has walked away from - and if they have since started HOSTING, the retry's
	 * handover would tear that new session down. Clear the PENDING RETRY only; the attempt
	 * count stays, because clearing it here would make the retries endless (the retry path
	 * comes through this function too). */
	gJoinRetryAtMs = 0;

	if (gMpCtx != NULL)
	{
		MpConnEvent("disconnecting (client side)", -1, "deliberate");

		gMpCtx->jer_log(gMpCtx, "[mp] MpClientDisconnect (closing our link)\n");
	}

	MpClientConnectCancel();	/* abandon an in-flight connect too */

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used && !gConn[i].hostSide)
		{
			MpCloseSock(&gConn[i].sock);
			gConn[i].used = 0;
			gConn[i].rbufLen = 0;
		}
	}

	gMp.connected = 0;
	gJoinState = MP_JOIN_IDLE;
}

/* Is this something we can dial? A dotted-quad IPv4 or a DNS name -- both are
 * resolved by MpResolveHost. This is only a SANITY check (non-empty, no
 * whitespace, not absurdly long), because whether a name actually EXISTS is the
 * resolver's answer and can only be had at connect time. */
int MpIsValidAddress(const char* host)
{
	size_t i;

	if (host == NULL || host[0] == '\0' || strlen(host) >= 128)
		return 0;

	for (i = 0; host[i] != '\0'; i++)
	{
		/* a name may carry letters, digits, dots, hyphens and an inline :port;
		 * whitespace or a slash is a paste or typing mistake every time */
		if (host[i] == ' ' || host[i] == '\t' || host[i] == '/' || host[i] == '\\')
			return 0;
	}

	return 1;
}

/* Resolve `host` (a dotted-quad IPv4 or a DNS name) plus `port` into `out`.
 *
 * A literal IPv4 is taken directly, which keeps LAN peers and the
 * discovery-derived addresses off the resolver entirely. Anything else goes
 * through getaddrinfo -- the only reason this module can be pointed at a NAME at
 * all, and what makes "join myhost.ddns.net" work.
 *
 * getaddrinfo BLOCKS: a DNS server that is slow or unreachable stalls for seconds,
 * and the game loop must not. So the answer is cached per host string -- a retry
 * (MP_JOIN_ATTEMPTS) or a reconnect re-uses it rather than re-querying, and the
 * lookup therefore happens once, where the join is started (a menu press or -join),
 * never on the frame path.
 *
 * Returns 1 and fills `out` on success, 0 if the name does not resolve. */
static int MpResolveHost(const char* host, int port, struct sockaddr_in* out)
{
	static char cachedHost[128];
	static struct in_addr cachedAddr;

	struct in_addr literal;

	if (host == NULL || host[0] == '\0')
		return 0;

	memset(out, 0, sizeof(*out));
	out->sin_family = AF_INET;
	out->sin_port = htons((unsigned short)(port > 0 ? port : gMp.config.port));

	/* NOTE: inet_addr also rejects the all-ones address, which nothing sensible
	 * would dial; everything else non-numeric falls through to the resolver. */
	literal.s_addr = inet_addr(host);
	if (literal.s_addr != INADDR_NONE)
	{
		out->sin_addr = literal;
		return 1;
	}

	if (cachedAddr.s_addr != 0 && strcmp(cachedHost, host) == 0)
	{
		out->sin_addr = cachedAddr;
		return 1;
	}

	{
		struct addrinfo hints;
		struct addrinfo* res = NULL;
		int rc;

		memset(&hints, 0, sizeof(hints));
		hints.ai_family = AF_INET;		/* the transport is IPv4-only */
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_flags = AI_ADDRCONFIG;		/* no IPv6 here: skip AAAA lookups */

		rc = getaddrinfo(host, NULL, &hints, &res);

		if (rc != 0 || res == NULL)
		{
			/* name the true cause here: the caller can only see "no socket" */
			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] '%s' does not resolve (getaddrinfo %d)\n", host, rc);

			return 0;
		}

		out->sin_addr = ((struct sockaddr_in*)res->ai_addr)->sin_addr;

		snprintf(cachedHost, sizeof(cachedHost), "%s", host);
		cachedAddr = out->sin_addr;

		freeaddrinfo(res);
		return 1;
	}
}

/* A socket set up for `host:port` (already non-blocking, ready for connect). */
static SOCKET MpClientSocket(const char* host, int port, struct sockaddr_in* out)
{
	struct sockaddr_in addr;
	SOCKET s;
	int one = 1;

	/* resolved BEFORE the socket exists: an unresolvable name is a reporting
	 * error, not something to open a handle for */
	if (!MpResolveHost(host, port, &addr))
		return INVALID_SOCKET;

	s = socket(AF_INET, SOCK_STREAM, 0);
	if (s == INVALID_SOCKET)
		return INVALID_SOCKET;

	setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char*)&one, sizeof(one));

	*out = addr;

	MpSetNonBlocking(s, 1);

	return s;
}

/* The connect succeeded: adopt the socket as the host connection and start
 * the handshake. Still CONNECTING until the host answers with a WELCOME. */
static int MpClientAdopt(SOCKET s, const char* host, int port)
{
	int idx;

	/* NON-BLOCKING: the send path queues what the socket will not take yet, and
	 * a blocking send() would stall the game loop whenever the host's receive
	 * window fills (the "freezes for a few seconds" symptom). */
	MpSetNonBlocking(s, 1);
	MpTuneConn(s);

	idx = MpAllocConn();
	if (idx < 0)
	{
		closesocket(s);
		return 0;
	}

	gConn[idx].sock = s;
	gConn[idx].hostSide = 0;
	gConn[idx].playerId = 0;	/* the host */
	gConn[idx].lastRecvMs = MpClockMs();
	MpPeerName(s, gConn[idx].peer, sizeof gConn[idx].peer);
	gConn[idx].hsStage = MP_HS_CONNECTED;

	gMp.connected = 1;
	gJoinState = MP_JOIN_CONNECTING;

	if (gMpCtx) gMpCtx->jer_log(gMpCtx, "[mp] connected to %s:%d\n", host, port);

	MpConnEvent("connected (outbound)", idx, "TCP established");

	MpSendHello();
	gConn[idx].hsStage = MP_HS_HELLO_SENT;

	MpConnEvent("sent HELLO", idx, "awaiting WELCOME");

	if (gMpCtx) gMpCtx->jer_log(gMpCtx, "[mp] HELLO sent to %s, awaiting WELCOME\n",
		gConn[idx].peer[0] ? gConn[idx].peer : host);

	return 1;
}

/* The attempt is over and it failed: drop the socket. Before reporting a failure to the
 * player, TRY AGAIN - the user asked for this after a launch where the connect failed
 * once and had to be fixed by hand in the menu:
 *
 *   "give two additional retries so the game tries to connect a total of 3 times before
 *    saying it failed to connect - i think sometimes the tests fail prematurely and i have
 *    to intervene by manually navigating the menu on the client to connect"
 *
 * A failed attempt leaves no state behind (MpClientConnectCancel drops the socket), so a
 * retry is safe. The toast and the permanent failure only come after the LAST attempt, so a
 * retry is silent apart from the log -- otherwise a transient failure would still read as a
 * failure to the player. The counter is 0-based and the guard adds one, so the total is
 * exactly MP_JOIN_ATTEMPTS (the first version retried one time too many and logged
 * "attempt 4 of 3"). */
static void MpJoinFail(const char* why)
{
	MpClientConnectCancel();

	if (gJoinAttempt + 1 < MP_JOIN_ATTEMPTS)
	{
		gJoinAttempt++;
		gJoinRetryAtMs = MpNowMs() + MP_JOIN_RETRY_MS;

		if (gMpCtx)
			gMpCtx->jer_log(gMpCtx,
				"[mp] join attempt %d of %d to %s:%d failed (%s) - retrying in %d ms\n",
				gJoinAttempt, MP_JOIN_ATTEMPTS, gConnectingHost, gConnectingPort,
				why, MP_JOIN_RETRY_MS);

		return;		/* not a failure yet: the UI keeps showing "Connecting..." */
	}

	gJoinRetryAtMs = 0;
	gJoinState = MP_JOIN_FAILED;

	if (gMp.role == MP_ROLE_CLIENT)
		gMp.role = MP_ROLE_NONE;

	jer_error("Could not join the server at %s:%d", gConnectingHost, gConnectingPort);
	jer_console_log("join failed: %s:%d (%s)", gConnectingHost, gConnectingPort, why);

	MpConnEvent("join FAILED", -1, why);

	if (gMpCtx)
		gMpCtx->jer_log(gMpCtx, "[mp] join FAILED: could not reach %s:%d (%s)\n",
			gConnectingHost, gConnectingPort, why);
}

int MpClientConnectBegin(const char* host, int port)
{
	struct sockaddr_in addr;
	SOCKET s;
	int rc;

	/* A manual connect cancels any pending retry, but does NOT reset the attempt count: the
	 * retry path comes through here too, and resetting it here would make the retries
	 * endless. A fresh, user-initiated join clears the count itself (MpJoinRetryClear). */
	gJoinRetryAtMs = 0;

	if (!gNetStarted && !MpNetStart())
		return 0;

	/* A JOIN IS A HANDOVER, NOT A CONFLICT.
	 *
	 * This refused outright at first, and that broke a legitimate reconnect: once an
	 * instance has hosted, `listenersUp` stays set (nothing closes the listener on the
	 * way back to the frontend), so every later join was turned away with "this machine
	 * is already hosting" - an instance that had ever hosted could never join again.
	 * Measured by the user: "the first join worked correctly but i couldnt reconnect".
	 *
	 * Stopping the local hosting first also removes the self-join this guard exists for:
	 * an instance cannot connect to a listener of its own that is no longer there, so
	 * "Lost the server (WELCOME received, awaiting the level)" - one process hosting and
	 * joining itself - cannot happen either. */
	if (gMp.listenersUp || gMp.role == MP_ROLE_HOST)
	{
		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx,
				"[mp] joining %s:%d - stopping the local hosting first (a join takes over from it)\n",
				host != NULL ? host : "?", port);

		MpHostEnd();
		MpDiscoveryStop();

		gMp.role = MP_ROLE_NONE;
		gMp.connected = 0;
	}

	MpClientDisconnect();	/* also cancels any earlier attempt */

	/* Recorded BEFORE the socket, because the failure paths below report
	 * "%s:%d" and would otherwise name nothing (and the pre-connect log should
	 * name the same thing the connection will). */
	snprintf(gConnectingHost, sizeof(gConnectingHost), "%s", host != NULL ? host : "");
	gConnectingPort = port > 0 ? port : gMp.config.port;

	s = MpClientSocket(host, port, &addr);
	if (s == INVALID_SOCKET)
	{
		/* MpResolveHost logs WHICH it was (no socket, or a name that does not
		 * resolve). Either way this is FINAL rather than parked in the retry path:
		 * a name that does not resolve will not resolve 1.2 seconds from now, and
		 * making the player wait through MP_JOIN_ATTEMPTS for it is worse than
		 * telling them at once. */
		gJoinAttempt = MP_JOIN_ATTEMPTS - 1;
		MpJoinFail("could not resolve the address");
		return 0;
	}

	gConnectingSinceMs = MpClockMs();
	gJoinState = MP_JOIN_CONNECTING;

	if (gMpCtx)
		gMpCtx->jer_log(gMpCtx, "[mp] connecting to %s:%d\n", gConnectingHost, gConnectingPort);

	rc = connect(s, (struct sockaddr*)&addr, sizeof(addr));

	if (rc == 0)
	{
		/* connected on the spot (loopback usually does) */
		MpClientAdopt(s, gConnectingHost, gConnectingPort);
		return 1;
	}

	/* refused/timeout is NOT an error here: a non-blocking connect reports it
	 * through select() in a moment, which is what keeps the frontend alive */
	gConnectingSock = s;

	return 1;
}

void MpClientConnectPoll(unsigned long now)
{
	fd_set wfds, efds;
	struct timeval tv;
	int err = 0;
#ifdef _WIN32
	int elen = (int)sizeof(err);
#else
	socklen_t elen = sizeof(err);
#endif

	if (gConnectingSock == INVALID_SOCKET)
		return;

	FD_ZERO(&wfds);
	FD_SET(gConnectingSock, &wfds);
	FD_ZERO(&efds);
	FD_SET(gConnectingSock, &efds);
	tv.tv_sec = 0;
	tv.tv_usec = 0;

	if (select((int)gConnectingSock + 1, NULL, &wfds, &efds, &tv) <= 0)
	{
		/* not resolved yet -- only give up after the bounded wait */
		if (MpElapsedMs(now, gConnectingSinceMs) > (unsigned long)MP_CONNECT_TIMEOUT_MS)
			MpJoinFail("timed out");

		return;
	}

	if (FD_ISSET(gConnectingSock, &wfds) || FD_ISSET(gConnectingSock, &efds))
	{
		if (getsockopt(gConnectingSock, SOL_SOCKET, SO_ERROR, (char*)&err, &elen) == 0 && err == 0)
		{
			SOCKET done = gConnectingSock;
			gConnectingSock = INVALID_SOCKET;
			MpClientAdopt(done, gConnectingHost, gConnectingPort);
		}
		else
		{
			MpJoinFail("connection refused");
		}
	}
}

/* ------------------------------------------------------------------ */
/* Framed send                                                         */
/* ------------------------------------------------------------------ */
/* The round trip to the peer playing `playerId`, or 0 if unknown. The host is
 * the only side that has one for everybody, so it is the host's measurement that
 * travels in the roster. */
int MpPingForPlayer(int playerId)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used && gConn[i].playerId == playerId)
			return (int)gConn[i].pingMs;
	}

	return 0;
}

/* Record a PONG's round trip against the peer that owns this connection. */
void MpConnSetPing(int idx, unsigned long ms)
{
	if (idx >= 0 && idx < MP_MAX_PLAYERS && gConn[idx].used)
		gConn[idx].pingMs = ms;
}

/* Everything the on-screen readout needs about one peer's link, or 0 if we hold
 * no connection for that player id. */
int MpPeerStats(int playerId, MP_PEER_STATS* out)
{
	int i;
	unsigned long now = MpClockMs();

	if (out == NULL)
		return 0;

	memset(out, 0, sizeof(*out));

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (!gConn[i].used || gConn[i].playerId != playerId)
			continue;

		out->rxBytes = gConn[i].rxBytes;
		out->txBytes = gConn[i].txBytes;
		out->pingMs = (int)gConn[i].pingMs;
		out->linkMs = (now > gConn[i].acceptedMs) ? (now - gConn[i].acceptedMs) : 1;
		out->lossPct = gConn[i].lossPct;	/* frames with no data from this peer */

		return 1;
	}

	return 0;
}

int MpSendConn(int idx, const char* tag, int flags, const void* payload, int len)
{
	unsigned char buf[MP_ENVELOPE_SIZE + MP_SEND_BUF];
	MP_ENVELOPE env;

	if (idx < 0 || idx >= MP_MAX_PLAYERS || !gConn[idx].used)
		return 0;

	if (len < 0) len = 0;
	if (len > MP_SEND_BUF)
		return 0;

	env.len = (uint32_t)(8 + len);
	memcpy(env.tag, tag, 4);
	env.version = (uint8_t)MP_PROTO_VERSION;
	env.flags = (uint8_t)flags;
	env.spare = 0;

	memcpy(buf, &env, MP_ENVELOPE_SIZE);
	if (len > 0)
		memcpy(buf + MP_ENVELOPE_SIZE, payload, len);

	return MpSendRaw(idx, buf, MP_ENVELOPE_SIZE + len);
}

int MpHostBroadcast(const char* tag, int flags, const void* payload, int len)
{
	int i, sent = 0;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used && gConn[i].hostSide)
			sent += MpSendConn(i, tag, flags, payload, len);
	}

	return sent;
}

/* Broadcast to every HOST-side connection EXCEPT one. The host uses this to pass
 * a client's car state on to the OTHER clients: in the owner-authoritative model
 * each machine sends only its own car, so the host is the hub that fans them out. */
int MpHostRelay(int exceptConn, const char* tag, int flags, const void* payload, int len)
{
	int i, sent = 0;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (i == exceptConn)
			continue;
		if (gConn[i].used && gConn[i].hostSide)
			sent += MpSendConn(i, tag, flags, payload, len);
	}

	return sent;
}

int MpSendToHost(const char* tag, int flags, const void* payload, int len)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used && !gConn[i].hostSide)
			return MpSendConn(i, tag, flags, payload, len);
	}

	return 0;
}

int MpConnFindByPlayer(int playerId)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used && gConn[i].hostSide && gConn[i].playerId == playerId)
			return i;
	}

	return -1;
}

void MpConnAssignPlayer(int connIndex, int playerId)
{
	if (connIndex >= 0 && connIndex < MP_MAX_PLAYERS)
		gConn[connIndex].playerId = playerId;
}

int MpConnPlayerId(int connIndex)
{
	if (connIndex >= 0 && connIndex < MP_MAX_PLAYERS && gConn[connIndex].used)
		return gConn[connIndex].playerId;

	return -1;
}

int MpPeerCount(void)
{
	int i, n = 0;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used && gConn[i].hostSide)
			n++;
	}

	return n;
}

/* ------------------------------------------------------------------ */
/* Framed recv + dispatch                                              */
/* ------------------------------------------------------------------ */

/* ONE PLACE THAT SAYS WHAT HAPPENED TO A CONNECTION, AND WHY.
 *
 * Deliberately UNCONDITIONAL -- not behind MP_DEBUG. A two-machine problem is
 * diagnosed from these two logs alone, and a missing event costs a whole
 * iteration, so a plain PLAY_HOST.bat / PLAY_JOIN.bat run has to produce them.
 * The events are rare (a handful per session), so the volume is nothing.
 *
 * Every origin calls this -- connect, accept, hello, welcome, refuse, leave,
 * drop, queue overflow, the deadlines -- and every close logs too, so the ORDER
 * of the lines names whoever closed the socket. A close with no origin line in
 * front of it is the one thing that must never happen again. */
/* ------------------------------------------------------------------ */
/* Diagnostics: capture, do not reconstruct                            */
/*                                                                    */
/* A two-machine failure is a reconstruction problem -- by the time    */
/* anyone looks, the connection that failed is gone and the state that */
/* explains it no longer exists. So it is CAPTURED: a ring of the last */
/* events, and a dump written automatically at every drop (the moment  */
/* that matters) and on demand from the pause menu.                    */
#define MP_DIAG_EVENTS 32

typedef struct MP_DIAG_EVENT
{
	unsigned long ms;
	char text[80];
} MP_DIAG_EVENT;

static MP_DIAG_EVENT gDiagEvents[MP_DIAG_EVENTS];
static int           gDiagNext;
static int           gDiagCount;

static void MpDiagNote(const char* text)
{
	MP_DIAG_EVENT* e = &gDiagEvents[gDiagNext];

	e->ms = MpNowMs();
	snprintf(e->text, sizeof(e->text), "%s", text != NULL ? text : "?");

	gDiagNext = (gDiagNext + 1) % MP_DIAG_EVENTS;

	if (gDiagCount < MP_DIAG_EVENTS)
		gDiagCount++;
}

/* Everything we know, to mp_diag.txt next to the exe (the game runs from its own
 * directory, so that is where a person will look and where it can be attached).
 * Called automatically by MpDropConn -- every drop funnels through there -- and by
 * hand from the MP pause menu. */
void MpDiagDump(const char* reason)
{
	FILE* f;
	int i;
	unsigned long now = MpNowMs();

	f = fopen("mp_diag.txt", "w");

	if (f == NULL)
	{
		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] diag: cannot write mp_diag.txt (%s)\n", reason);
		return;
	}

	fprintf(f, "jericho mp diagnostics\n");
	fprintf(f, "reason  : %s\n", reason != NULL ? reason : "?");
	fprintf(f, "build   : %04x   mods %04x\n", MpBuildHash(), MpModHash());
	fprintf(f, "role    : %s   running %d   frame %lu\n",
		gMp.role == MP_ROLE_HOST ? "host" : (gMp.role == MP_ROLE_CLIENT ? "client" : "none"),
		gMp.running, gMp.frame);
	fprintf(f, "local id: %d   players %d   listeners %d   connected %d\n",
		gMp.localPlayerId, gMp.playerCount, gMp.listenersUp, gMp.connected);
	fprintf(f, "city    : %d   subgame %d   mode %d   seed %u\n",
		gMp.city, gMp.subGame, gMp.gamemode, gMp.seed);

	fprintf(f, "\n-- connections --\n");
	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		MP_CONN* c = &gConn[i];

		if (!c->used)
			continue;

		fprintf(f, "  conn %d  peer %-22s stage %-38s age %lums\n",
			i, c->peer[0] ? c->peer : "(none)", MpStageName(c->hsStage),
			now - c->acceptedMs);
		fprintf(f, "           heard %lums ago  rx %lu  tx %lu  queued %d  ping %lums  loss %d%%  hostSide %d  playerId %d\n",
			now - c->lastRecvMs, c->rxBytes, c->txBytes,
			c->sbufLen - c->sbufOff, c->pingMs, c->lossPct, c->hostSide, c->playerId);
		fprintf(f, "           last event: %s (%lums ago)\n",
			c->lastEvent[0] ? c->lastEvent : "-", now - c->lastEventMs);
	}
	if (i == 0 || !gConn[0].used)
	{
		int any = 0;

		for (i = 0; i < MP_MAX_PLAYERS; i++)
			if (gConn[i].used) any = 1;

		if (!any)
			fprintf(f, "  (none)\n");
	}

	fprintf(f, "\n-- players --\n");
	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		MP_PLAYER* p = &gMp.players[i];

		if (!p->active)
			continue;

		fprintf(f, "  id %d  %-16s %s%s  carId %d  car %d (slot %d)  palette %d\n",
			p->id, p->name[0] ? p->name : "(unnamed)",
			p->connected ? "connected" : "gone",
			p->isLocal ? " LOCAL" : "",
			p->carId, p->car, p->carIsSlot, p->palette);
	}

	fprintf(f, "\n-- last %d event(s), oldest first --\n", gDiagCount);
	for (i = 0; i < gDiagCount; i++)
	{
		int k = (gDiagNext - gDiagCount + i + MP_DIAG_EVENTS) % MP_DIAG_EVENTS;

		fprintf(f, "  +%6lums  %s\n", now - gDiagEvents[k].ms, gDiagEvents[k].text);
	}

	fclose(f);

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] diag: wrote mp_diag.txt (%s)\n", reason);
}

/* The connection readout, in two SHORT lines: peer + the stage it is in and how
 * long it has been there, then the last event and how long ago it was.
 *
 *      part 0:  "<peer>  <stage> <n>s"   e.g. "192.168.50.244:55497  in match 67s"
 *      part 1:  "last: <event> (<n>s ago)"
 *
 * REMOVED from the screen: mp used to draw these two lines (and a HOST/CLIENT
 * tag) at the bottom-left, and that block is gone -- the status console owns the
 * corner now. What is left is the LOG rollup, written by MpConnEvent on every
 * connection event and by the periodic link tick: "time in the current stage"
 * and "what happened last" are what a log reader needs to reconstruct a
 * handshake, so both callers stay. */
void MpConnLineText(char* out, int cap, int part)
{
	int idx = -1;
	int i;
	unsigned long now;

	if (out == NULL || cap <= 0)
		return;

	out[0] = 0;

	if (gMp.role != MP_ROLE_HOST && gMp.role != MP_ROLE_CLIENT)
	{
		if (part == 0)
			snprintf(out, cap, "not in a session");
		return;
	}

	for (i = 0; i < MP_MAX_PLAYERS; i++)
		if (gConn[i].used) { idx = i; break; }

	if (idx < 0)
	{
		/* In a session but with no live connection: the useful fact is that we are
		 * not connected -- a blank line reads like the overlay is broken. */
		if (part == 0)
			snprintf(out, cap, "no connection%s", gMp.running ? " (in a match)" : "");
		else
			snprintf(out, cap, "last: %s", gConnectingHost[0] ? gConnectingHost : "-");
		return;
	}

	now = MpNowMs();

	if (part == 0)
		snprintf(out, cap, "%s  %s %lus",
			gConn[idx].peer[0] ? gConn[idx].peer : "(peer)",
			MpStageName(gConn[idx].hsStage),
			(now - gConn[idx].stageSinceMs) / 1000UL);
	else
		snprintf(out, cap, "last: %s  (%lus ago)",
			gConn[idx].lastEvent[0] ? gConn[idx].lastEvent : "-",
			(now - gConn[idx].lastEventMs) / 1000UL);
}

void MpConnEvent(const char* ev, int idx, const char* why)
{
	char peer[80];

	if (gMpCtx == NULL)
		return;

	/* Keep the stage timer and the last-event string current: those are what the
	 * on-screen line reads, and a stage that changed without moving its clock
	 * would look as if nothing had happened for minutes. */
	if (idx >= 0 && idx < MP_MAX_PLAYERS)
	{
		if (gConn[idx].stageSeen != gConn[idx].hsStage)
		{
			gConn[idx].stageSeen = gConn[idx].hsStage;
			gConn[idx].stageSinceMs = MpNowMs();
		}
		snprintf(gConn[idx].lastEvent, sizeof(gConn[idx].lastEvent), "%s", ev != NULL ? ev : "?");
		gConn[idx].lastEventMs = MpNowMs();
	}

	MpDiagNote(ev);

	peer[0] = 0;

	if (idx >= 0 && idx < MP_MAX_PLAYERS && gConn[idx].used && gConn[idx].peer[0] != 0)
		snprintf(peer, sizeof(peer), "%s", gConn[idx].peer);
	else if (gConnectingHost[0] != 0)
		snprintf(peer, sizeof(peer), "%s", gConnectingHost);
	else
		snprintf(peer, sizeof(peer), "(none)");

	gMpCtx->jer_log(gMpCtx, "[mp] conn: %s | peer %s | role %s | stage %s%s%s\n",
		ev != NULL ? ev : "?",
		peer,
		gMp.role == MP_ROLE_HOST ? "host" : (gMp.role == MP_ROLE_CLIENT ? "client" : "none"),
		(idx >= 0 && idx < MP_MAX_PLAYERS) ? MpStageName(gConn[idx].hsStage) : "n/a",
		(why != NULL && why[0] != 0) ? " | why: " : "",
		why != NULL ? why : "");

	/* The two-line rollup (MpConnLineText) next to the event line above: the event
	 * says WHAT happened, this says how long the connection has been in its current
	 * stage and when it last did anything. */
	{
		char l0[120];
		char l1[120];

		MpConnLineText(l0, sizeof(l0), 0);
		MpConnLineText(l1, sizeof(l1), 1);

		gMpCtx->jer_log(gMpCtx, "[mp] conn status: %s | %s\n", l0, l1);
	}

	/* JERICHO-HOOK: the SAME event, into the unified status console (jer_console.h).
	 * Every discrete connection/handshake step funnels through here, so this one
	 * call is what puts "connected to <ip>", "WELCOME received" and stage changes
	 * on the bottom-left stream -- in the frontend AND in-game. The live
	 * HOST/CLIENT block stays separate; `~` hides both together. */
	if (peer[0] != 0 && peer[0] != '(')
		jer_console_log("[mp] %s  %s", ev != NULL ? ev : "?", peer);
	else
		jer_console_log("[mp] %s", ev != NULL ? ev : "?");
}

static void MpDropConn(int idx, const char* why)
{
	/* A host-side connection that closed without sending one byte and never
	 * started a handshake is a reachability probe (the master checks the port
	 * every few seconds) or a scanner, not a player: tear it down quietly. No
	 * diag dump, no console line -- each probe used to read as a peer joining
	 * and dropping, the "flapping with the master" a LAN/listen host saw. */
	if (gConn[idx].used && gConn[idx].hostSide && gConn[idx].rxBytes == 0 &&
		!gConn[idx].hsDone && gConn[idx].playerId < 0)
	{
		if (gMpCtx)
			gMpCtx->jer_log(gMpCtx, "[mp] silent connect from %s closed (%s) - probe, not a player\n",
				gConn[idx].peer[0] ? gConn[idx].peer : "?", why);

		MpCloseSock(&gConn[idx].sock);
		gConn[idx].used = 0;
		gConn[idx].rbufLen = 0;
		gConn[idx].hsStage = MP_HS_NONE;
		gConn[idx].peer[0] = 0;
		gConn[idx].rxBytes = 0;
		return;
	}

	/* Capture the state NOW, before any of it is torn down: this is the moment the
	 * interesting information exists, and it is gone by the time anyone looks. Every
	 * drop funnels through this function, so this one call covers them all. */
	MpDiagDump(why);

	/* Report it BEFORE the teardown below clears the connection, otherwise the
	 * most important line in the log is the one that cannot say who it was about. */
	if (gMpCtx != NULL)
		MpConnEvent("DROPPED", idx, why);

	/* on a client, losing the server connection is worth telling the player
	 * about -- and it means the match is over, so go back to the frontend.
	 * `gMp.leaving` marks a deliberate leave, which must stay quiet.
	 * The toast names WHERE it stopped: "lost" alone cannot distinguish a
	 * server that was never reached from one that dropped a running match. */
	if (gMp.role == MP_ROLE_CLIENT && !gMp.leaving)
	{
		jer_error("Lost the server %s (%s)",
			gConn[idx].peer[0] ? gConn[idx].peer : gConnectingHost,
			MpStageName(gConn[idx].hsStage));

		jer_console_log("lost the server %s (%s)",
			gConn[idx].peer[0] ? gConn[idx].peer : gConnectingHost,
			MpStageName(gConn[idx].hsStage));
		MpReturnToFrontend();
	}

	if (gConn[idx].used && gConn[idx].hostSide && gConn[idx].playerId >= 0)
		MpRemovePlayer(gConn[idx].playerId);

	MpCloseSock(&gConn[idx].sock);
	gConn[idx].used = 0;
	gConn[idx].rbufLen = 0;

	if (gMpCtx)
	{
		gMpCtx->jer_log(gMpCtx, "[mp] peer %s dropped (%s); %lu byte(s) received\n",
			gConn[idx].peer[0] ? gConn[idx].peer : "?", why, gConn[idx].rxBytes);

		/* A peer that CONNECTED, was accepted and then said NOTHING is not a
		 * timeout -- the socket was live and the TCP handshake completed.
		 * A blocked port cannot look like this, so it is almost always
		 * something between the two machines interfering with the flow.
		 * Name the suspects instead of leaving a bare "closed". */
		if (gConn[idx].hostSide && gConn[idx].rxBytes == 0 && !gConn[idx].hsDone)
			gMpCtx->jer_log(gMpCtx,
				"[mp] ^ that peer completed a TCP handshake and then sent ZERO "
				"bytes, which a closed port or a stealthed firewall cannot do. "
				"Likely causes, in order: security software (Norton/McAfee/AVG/"
				"ESET/Kaspersky), a VPN or Hyper-V/VirtualBox/WSL virtual adapter "
				"on either machine, then Wi-Fi client isolation. Try a wired link "
				"or a phone hotspot to tell them apart.\n");
	}

	gConn[idx].hsStage = MP_HS_NONE;
	gConn[idx].peer[0] = 0;
	gConn[idx].rxBytes = 0;
}

/* Drop a connection from outside this file, with a reason that will be believed.
 * The reason string must describe what HAPPENED, not whichever check ran last:
 * a peer that sent a LEAVE used to be closed by the 30 s liveness check instead
 * and reported as "timeout", which is a lie that cost a whole investigation. */
void MpConnDrop(int idx, const char* why)
{
	MpDropConn(idx, why);
}

void MpConnClose(int connIndex)
{
	if (connIndex >= 0 && connIndex < MP_MAX_PLAYERS && gConn[connIndex].used)
		MpDropConn(connIndex, "closed by us");
}

/* Refuse a peer without throwing the refusal away. closesocket() immediately
 * after send() can RST and discard what we just wrote, so half-close and let
 * the peer read the FIN; the poll closes the socket once the peer is done or
 * the grace period expires. */
void MpConnShutdownGraceful(int connIndex)
{
	MP_CONN* c;

	if (connIndex < 0 || connIndex >= MP_MAX_PLAYERS || !gConn[connIndex].used)
		return;

	c = &gConn[connIndex];

	if (!c->closing)
	{
		shutdown(c->sock, MP_SHUT_WR);
		c->closing = 1;
		c->closingSinceMs = MpClockMs();
	}
}

/* A HELLO or a WELCOME has been seen on this connection, so it is no longer
 * within the handshake deadline. */
void MpConnHandshakeDone(int connIndex)
{
	if (connIndex >= 0 && connIndex < MP_MAX_PLAYERS && gConn[connIndex].used)
	{
		gConn[connIndex].hsDone = 1;
		gConn[connIndex].hsStage = MP_HS_WELCOME;

		MpConnEvent("handshake done", connIndex, "HELLO or WELCOME seen");
	}
}

/* The match is RUNNING now. Say so, so every later log line and every toast
 * reports the truth: the stage used to stop at WELCOME forever, which is why a
 * 67-second-old live match still printed "Lost the server (... WELCOME received,
 * awaiting the level)" and sent the diagnosis after a join problem that was not
 * there. */
void MpConnMatchStarted(void)
{
	int i;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (gConn[i].used)
		{
			gConn[i].hsStage = MP_HS_PLAYING;
			MpConnEvent("match started", i, "the level is up");
		}
	}
}

static void MpProcessConn(int idx)
{
	MP_CONN* c = &gConn[idx];
	char buf[2048];
	int eof = 0;

	/* Drain what is readable. select() with a zero timeout is used rather
	 * than FIONREAD because a peer that hung up becomes *readable with 0
	 * bytes* -- FIONREAD never reports that, so a clean disconnect would go
	 * unnoticed until the next send. */
	for (;;)
	{
		fd_set rd;
		struct timeval tv;
		int n, space;

		FD_ZERO(&rd);
		FD_SET(c->sock, &rd);
		tv.tv_sec = 0;
		tv.tv_usec = 0;

		{
			int sel = select((int)c->sock + 1, &rd, NULL, NULL, &tv);
			int isset = FD_ISSET(c->sock, &rd);

			/* Nothing to read: stop draining, the rest waits for the next poll.
			 *
			 * This break must stay UNCONDITIONAL, but for a different reason than
			 * the one that used to be claimed here. The session sockets are
			 * NON-blocking (MpSetNonBlocking), so falling through is not a hang --
			 * recv() would return WSAEWOULDBLOCK and the check below would break
			 * anyway. What it saves is the wasted recv() syscall per connection per
			 * poll; the poll runs several times a frame, so it is a real saving.
			 *
			 * The historical reason to keep it unconditional still holds: an edit
			 * once deleted a debug log and left its `if (MP_DEBUG ...)` behind with
			 * this break as its body, so it only fired WITH MP_DEBUG set -- with it
			 * the pair worked, without it (every packaged launch) a connection was
			 * dropped the instant nothing was pending. */
			if (sel <= 0 || !isset)
				break;
		}

		/* Room for what we are about to ask for. If a partial frame has already filled
		 * the buffer, STOP READING and leave the rest in the socket: the frames buffered
		 * so far are parsed below, the space they free is used next poll, and the peer is
		 * never dropped for a burst it was entitled to send.
		 *
		 * The old code drained the socket until select() said nothing was pending and
		 * THEN dropped the connection if that turned out to be more than the buffer held.
		 * A burst is exactly what a stalled local game produces, and one real session died
		 * that way mid-chase after 54239 bytes receiver-side. */
		space = MP_RECV_BUF - c->rbufLen;

		if (space < MP_ENVELOPE_SIZE + 8)
			break;

		n = recv(c->sock, buf, space < (int)sizeof(buf) ? space : (int)sizeof(buf), 0);
		if (n <= 0 && MpDebugOn() && gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] recv n=%d\n", n);

		if (n > 0 && MpDebugOn() && gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] read %d byte(s) conn=%d\n", n, idx);

		if (n == 0)
		{
			/* The peer hung up WITH BYTES STILL QUEUED: TCP hands over the
			 * data and the FIN together. Dropping here would throw away a
			 * REJECT, a WELCOME or a LEAVE sitting in the buffer -- which is
			 * exactly how "refused, your build differs" reached the player as
			 * "Connection to the server lost!". Remember the EOF and drain
			 * the buffer first. */
			eof = 1;
			break;
		}

		if (n < 0)
		{
			int err = MP_LAST_ERROR();

			/* "No data right now" is not a failure: on a non-blocking socket it
			 * is the normal state, and the select() guard above cannot make that
			 * impossible. Never drop a live peer over it. */
			if (MpWouldBlock())
				break;

			/* An orderly close arrives as n == 0 and is handled above. n < 0
			 * with ECONNRESET means the far end or something in between RST
			 * the connection -- a different event from a hangup, and the one
			 * that a filtering middlebox produces. */
			if (err == MP_ECONNRESET || err == MP_ECONNABORTED)
			{
				MpDropConn(idx, "connection reset (WSAECONNRESET)");
				return;
			}

			/* ...but a BAD HANDLE is not one of those. err 6 says the socket is not a
			 * socket any more: this connection has already been closed, by us. Polling
			 * it as though it were alive is how a clean teardown turned into a
			 * "send failed" drop carrying a huge byte count on the other end -- the
			 * shape the mid-match disconnect has been read as all along. Say what it
			 * is and end the connection. */
			if (err == MP_EBADHANDLE)
			{
				MpDropConn(idx, "socket closed (bad handle)");
				return;
			}

			/* Anything else is NOT proof the peer is gone -- under a burst (a
			 * busy chase, a flurry of contacts) the stack reports transient
			 * errors like WSAENOBUFS/WSAENETRESET, and dropping on those kills a
			 * perfectly live session. Skip the read this frame and let the idle
			 * timeout be the judge of whether the peer is really gone. Run the
			 * dropped reason through jer_log so the CODE is not a mystery. */
			{
				char why[64];

				snprintf(why, sizeof(why), "recv error %d (transient, kept alive)", err);

				if (gMpCtx != NULL)
					gMpCtx->jer_log(gMpCtx, "[mp] %s conn=%d rx=%lu\n", why, idx, c->rxBytes);
			}
			break;
		}

		/* Cannot overflow: the read above is bounded by the space that was left, and a
		 * maximal legal frame always fits (see MP_RECV_BUF). The drop that used to be here
		 * was the burst bug. */
		memcpy(c->rbuf + c->rbufLen, buf, n);
		c->rbufLen += n;
		/* first bytes from an accepted socket: now it is a peer worth announcing
		 * (MpAcceptPeers stays quiet so the master's port probes do not show) */
		if (c->hostSide && c->rxBytes == 0 && n > 0)
			MpConnEvent("accepted a peer", idx, "they connected to us");

		c->rxBytes += (unsigned long)n;
		c->lastRecvMs = MpClockMs();
	}

	/* parse whole messages */
	for (;;)
	{
		MP_ENVELOPE env;
		int total, payloadLen;

		if (c->rbufLen < MP_ENVELOPE_SIZE)
			break;

		memcpy(&env, c->rbuf, MP_ENVELOPE_SIZE);

		if (env.len < 8 || env.len > (uint32_t)MP_RECV_BUF)
		{
			MpDropConn(idx, "bad frame");
			return;
		}

		total = 4 + (int)env.len;	/* len field + env.len bytes */
		if (c->rbufLen < total)
			break;			/* wait for the rest */

		payloadLen = (int)env.len - 8;

		if (env.version != MP_PROTO_VERSION)
		{
			MpDropConn(idx, "version mismatch");
			return;
		}

		MpHandleMessage(idx, env.tag, c->rbuf + MP_ENVELOPE_SIZE, payloadLen);

		/* the handler may have dropped us (e.g. a rejected join closed the
		 * connection and zeroed rbufLen) -- bail BEFORE the shift, otherwise
		 * rbufLen - total is negative and memmove() gets a huge length. */
		if (!gConn[idx].used)
			return;

		memmove(c->rbuf, c->rbuf + total, c->rbufLen - total);
		c->rbufLen -= total;
	}

	/* Now act on the EOF. Whatever is left is a half-frame we can never
	 * complete, so say so rather than pretending it was a clean close. */
	if (eof && gConn[idx].used)
		MpDropConn(idx, gConn[idx].rbufLen > 0 ? "closed mid-frame" : "closed");
}

/* ------------------------------------------------------------------ */
/* Keepalive                                                           */
/* ------------------------------------------------------------------ */
static unsigned long gLastPingMs;

/* Both sides ping on a timer, so an idle session (frontend lobby, a quiet
 * stretch, a paused game) keeps proving it is alive -- the silence timeout
 * then means what it says: the peer really is gone. */
static void MpKeepaliveTick(unsigned long now)
{
	MP_PING pg;
	int ms;

	if (gMp.role == MP_ROLE_NONE)
		return;

	if (MpIsHost())
	{
		if (MpPeerCount() <= 0)
			return;	/* nobody to keep alive */
	}
	else if (!gMp.connected)
	{
		return;		/* still connecting / already gone */
	}

	ms = gMp.config.keepaliveMs;
	if (ms < MP_KEEPALIVE_MIN_MS)
		ms = MP_KEEPALIVE_MIN_MS;

	if (gLastPingMs != 0 && (now - gLastPingMs) < (unsigned long)ms)
		return;

	gLastPingMs = now;
	pg.tick = (uint32_t)now;

	if (MpIsHost())
		MpHostBroadcast(MP_TAG_PING, 0, &pg, sizeof(pg));
	else
		MpSendToHost(MP_TAG_PING, 0, &pg, sizeof(pg));
}

/* Application-level DELIVERY statistic, replacing the "packet loss" column.
 *
 * TCP retransmits, so there is no packet loss to read out of the stack -- and a
 * TCP socket happily reports "0%" while the peer's data is seconds late. What
 * actually matters to a game is whether the peer's data is arriving each frame,
 * so that is what we measure: an EWMA (1/8) of the fraction of polls in which
 * NOTHING arrived from that peer. 0 = every frame delivered; 100 = nothing is
 * getting through. A level load is silent BY DESIGN, so it is not sampled. */
static void MpLossTick(void)
{
	static unsigned long lastFrame = (unsigned long)-1;
	int i;

	/* MpNetPoll runs SEVERAL times per frame (the frame hook, the overlay and
	 * the lockstep tick). Sampling per POLL would count the extra calls as
	 * "nothing arrived" and report a large phantom loss, so sample ONCE per
	 * sim frame -- the unit the statistic is defined in. */
	if (gMp.frame == lastFrame)
		return;

	lastFrame = gMp.frame;

	if (MpBusy())
		return;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		MP_CONN* c = &gConn[i];

		if (!c->used || c->playerId < 0 || c->lastRecvMs == 0)
			continue;

		if (c->lastRecvMs == c->lossMarkMs)
			c->lossPct += (100 - c->lossPct) / 8;	/* nothing this poll */
		else
			c->lossPct -= c->lossPct / 8;		/* it delivered */

		if (c->lossPct < 0)
			c->lossPct = 0;
		else if (c->lossPct > 100)
			c->lossPct = 100;

		c->lossMarkMs = c->lastRecvMs;
	}
}

void MpNetPoll(int waitMs)
{
	/* A retry the last failed attempt asked for. Done first, before anything else in the
	 * poll, so the second attempt starts as soon as it is due. */
	if (gJoinRetryAtMs != 0 && MpNowMs() >= gJoinRetryAtMs)
	{
		gJoinRetryAtMs = 0;

		if (gMpCtx)
			gMpCtx->jer_log(gMpCtx, "[mp] retrying the join to %s:%d (attempt %d of %d)\n",
				gConnectingHost, gConnectingPort, gJoinAttempt + 1, MP_JOIN_ATTEMPTS);

		MpClientConnectBegin(gConnectingHost, gConnectingPort);
	}

	unsigned long now = MpClockMs();
	int i;

	(void)waitMs;

	if (gListen != INVALID_SOCKET)
		MpAcceptPeers();

	/* ONE clock read for the whole poll -- it runs several times a frame, and
	 * every step below works off this value rather than reading it again. */
	MpDiscoveryPoll(now);
	MpClientConnectPoll(now);	/* finish an asynchronous join */
	MpKeepaliveTick(now);	/* prove we are alive to our peers */

	/* A poll gap longer than the timeout means WE were not running -- a level
	 * load, a long pause, a debugger. The peers' recv timers went stale because
	 * we were not listening, not because they went away, so credit that time
	 * back rather than dropping a healthy connection. */
	if (gLastPollMs != 0 && MpElapsedMs(now, gLastPollMs) > (unsigned long)MP_CONN_TIMEOUT_MS)
	{
		for (i = 0; i < MP_MAX_PLAYERS; i++)
		{
			if (gConn[i].used)
				gConn[i].lastRecvMs = now;
		}
	}

	gLastPollMs = now;

	for (i = 0; i < MP_MAX_PLAYERS; i++)
	{
		if (!gConn[i].used)
			continue;

		MpProcessConn(i);

		/* anything that had to wait for the socket last poll goes out now */
		if (gConn[i].used && !MpFlushConn(i))
		{
			MpDropConn(i, "send failed");
			continue;
		}

		/* a peer we refused: give it time to read the refusal, then let it
		 * go even if it never closes its side */
		if (gConn[i].used && gConn[i].closing &&
			MpElapsedMs(now, gConn[i].closingSinceMs) > MP_CLOSE_GRACE_MS)
		{
			MpDropConn(i, "refusal not acknowledged");
			continue;
		}

		/* A STRANGER that connects and then says nothing is not a player: this
		 * deadline is for a peer that connected TO us (hostSide). It must NOT
		 * apply to our own outbound connection to a host. A host that is loading
		 * a level is SILENT for seconds, and the client cannot see the host's
		 * busy flag, so a 5 s deadline here dropped a perfectly good join -- the
		 * intermittent "Lost the server (HELLO sent, no WELCOME)" that showed only
		 * when the host was still loading. Our own link is bounded by the idle
		 * timeout below (which the busy grace stands down during a load). */
		if (gConn[i].used && gConn[i].hostSide && !gConn[i].hsDone &&
			MpElapsedMs(now, gConn[i].acceptedMs) > MP_HANDSHAKE_TIMEOUT_MS)
		{
			MpDropConn(i, "no handshake reply");
			continue;
		}

		/* ...but not while a level is loading: both sides go silent for the whole
		 * load, and that is longer than the idle timeout. And not before the match
		 * starts: a player still in the car select is legitimately quiet (or slow to
		 * pick), so "silence == dead" only holds once the match is running. This is
		 * the "client was kicked for taking a few seconds to choose a car" fix. */
		/* idle_drop_ms = 0 turns this off entirely: a stalled/very-busy peer is
		 * then left connected rather than ejected mid-playtest (see mp.ini). */
		if (gConn[i].used && gMp.config.idleDropMs > 0 &&
			MpElapsedMs(now, gConn[i].lastRecvMs) > (unsigned long)gMp.config.idleDropMs && !MpBusy() && gMp.running)
			MpDropConn(i, "timeout");
	}

	/* sample the delivery statistic LAST, so it sees this poll's arrivals */
	MpLossTick();

	/* and a periodic look at the link itself, so a stall is visible before it
	 * turns into a drop */
	MpLinkTick(now);
}

/* MP_DEBUG: a periodic look at the LINK, so a stall can be seen BEFORE it becomes
 * a drop. Prints our frame, how long ago we last HEARD from each peer, and how
 * many bytes are stuck in that peer's send queue -- the three numbers that
 * separate "they stopped talking" from "we stopped listening" from "we queued but
 * never flushed". Log-only. */
static void MpLinkTick(unsigned long now)
{
	static unsigned long lastMs;
	int i;

	/* NOTE: nothing here returns or breaks on the MP_DEBUG guard -- control flow
	 * conditional on a debug flag is exactly what the debug-independence check
	 * refuses, so even the interval test lives in the guard's condition. */
	if (MpDebugOn() && gMpCtx != NULL && (now - lastMs) >= 5000)
	{
		lastMs = now;

		for (i = 0; i < MP_MAX_PLAYERS; i++)
		{
			MP_CONN* c = &gConn[i];

			if (!c->used)
				continue;

			gMpCtx->jer_log(gMpCtx,
				"[mp] link: conn %d frame %lu heard %lums ago queued %d tx=%lu\n",
				i, gMp.frame, MpElapsedMs(now, c->lastRecvMs),
				c->sbufLen - c->sbufOff, c->txBytes);
		}

		/* The same two-line rollup, on a timer: what the connection is doing
		 * between events (stage age, last event) is what shows a stalled link. */
		{
			char l0[120];
			char l1[120];

			MpConnLineText(l0, sizeof(l0), 0);
			MpConnLineText(l1, sizeof(l1), 1);

			gMpCtx->jer_log(gMpCtx, "[mp] conn status: %s | %s\n", l0, l1);
		}
	}
}

/* ------------------------------------------------------------------ */
/* UDP LAN discovery -- beacon + server list                           */
/* ------------------------------------------------------------------ */
#define MP_MAX_SERVERS 16

static SOCKET gBeaconSock = INVALID_SOCKET;
static int    gBeaconAdvertise;
static unsigned long gLastBeaconMs;
static MP_SERVER gServers[MP_MAX_SERVERS];
static unsigned gDiscoveryRev;	/* bumped when the VISIBLE server set changes */

#define MP_SERVER_SLOTS ((int)(sizeof(gServers) / sizeof(gServers[0])))

/* Every broadcast address worth trying, limited broadcast first.
 *
 * Sending only to 255.255.255.255 is the classic reason a host is invisible
 * on a machine with more than one adapter (Wi-Fi + Ethernet + VPN + Hyper-V
 * or WSL): Windows picks one adapter to send it out of, and it is regularly
 * the wrong one. A directed broadcast per adapter (ip | ~mask) removes the
 * guesswork. */
static int MpBroadcastTargets(uint32_t* out, int max)
{
	int n = 0;

	if (max <= 0)
		return 0;

	out[n++] = INADDR_BROADCAST;

#ifdef _WIN32
	{
		IP_ADAPTER_INFO* list = NULL;
		ULONG len = 0;

		if (GetAdaptersInfo(NULL, &len) == ERROR_BUFFER_OVERFLOW && len > 0)
		{
			list = (IP_ADAPTER_INFO*)malloc(len);

			if (list != NULL && GetAdaptersInfo(list, &len) == ERROR_SUCCESS)
			{
				IP_ADAPTER_INFO* a;

				for (a = list; a != NULL; a = a->Next)
				{
					IP_ADDR_STRING* ipa;

					for (ipa = &a->IpAddressList; ipa != NULL; ipa = ipa->Next)
					{
						uint32_t ip = inet_addr(ipa->IpAddress.String);
						uint32_t mask = inet_addr(ipa->IpMask.String);
						uint32_t bcast;
						int i, seen = 0;

						if (ip == INADDR_NONE || mask == INADDR_NONE)
							continue;

						if ((ip & 0xFF000000u) == 0x7F000000u)	/* loopback */
							continue;

						bcast = htonl((ntohl(ip) & ntohl(mask)) | ~ntohl(mask));

						for (i = 0; i < n; i++)			/* no duplicates */
							if (out[i] == bcast)
								seen = 1;

						if (!seen && n < max)
							out[n++] = bcast;
					}
				}
			}

			free(list);
		}
	}
#else
	{
		struct ifaddrs* ifa = NULL;

		if (getifaddrs(&ifa) == 0)
		{
			struct ifaddrs* p;

			for (p = ifa; p != NULL; p = p->ifa_next)
			{
				uint32_t bcast;
				int i, seen = 0;

				if (p->ifa_addr == NULL || p->ifa_netmask == NULL ||
					p->ifa_addr->sa_family != AF_INET)
					continue;

				{
					uint32_t ip = ntohl(((struct sockaddr_in*)p->ifa_addr)->sin_addr.s_addr);
					uint32_t mask = ntohl(((struct sockaddr_in*)p->ifa_netmask)->sin_addr.s_addr);

					if ((ip & 0xFF000000u) == 0x7F000000u)
						continue;

					bcast = htonl((ip & mask) | ~mask);
				}

				for (i = 0; i < n; i++)
					if (out[i] == bcast)
						seen = 1;

				if (!seen && n < max)
					out[n++] = bcast;
			}

			freeifaddrs(ifa);
		}
	}
#endif

	return n;
}

/* LAN discovery fails silently by nature: if the UDP socket or its bind fails,
 * nothing else in the module notices, and the player just gets an empty server
 * list with no explanation. Say so -- in the log and on screen.
 *
 * NOTE: this cannot open the Windows Firewall for you. Inbound UDP/TCP 1318 has
 * to be allowed, or a host on another machine stays invisible even though
 * everything here succeeded. */
static void MpDiscoveryFailed(const char* why)
{
	char text[128];

	snprintf(text, sizeof(text), "%s (UDP/%d)", why, MP_DISCOVERY_PORT);

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] discovery unavailable: %s\n", text);

	jer_error("LAN discovery is off: %s", text);
}

void MpDiscoveryStart(int advertise)
{
	struct sockaddr_in addr;
	int one = 1;

	if (gBeaconSock == INVALID_SOCKET)
	{
		gBeaconSock = socket(AF_INET, SOCK_DGRAM, 0);
		if (gBeaconSock == INVALID_SOCKET)
		{
			MpDiscoveryFailed("could not open a discovery socket");
			return;
		}

		setsockopt(gBeaconSock, SOL_SOCKET, SO_REUSEADDR, (const char*)&one, sizeof(one));
		setsockopt(gBeaconSock, SOL_SOCKET, SO_BROADCAST, (const char*)&one, sizeof(one));

		memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_port = htons((unsigned short)MP_DISCOVERY_PORT);
		addr.sin_addr.s_addr = htonl(INADDR_ANY);

		if (bind(gBeaconSock, (struct sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR)
		{
			MpCloseSock(&gBeaconSock);
			MpDiscoveryFailed("the port is already taken by another program");
			return;
		}

		MpSetNonBlocking(gBeaconSock, 1);
	}

	gBeaconAdvertise = advertise;
	gLastBeaconMs = 0;

	if (gMpCtx)
	{
		uint32_t targets[8];

		gMpCtx->jer_log(gMpCtx, "[mp] discovery %s on UDP/%d (session TCP/%d), %d broadcast target(s)\n",
			advertise ? "advertising" : "browsing", MP_DISCOVERY_PORT, gMp.config.port,
			MpBroadcastTargets(targets, (int)(sizeof(targets) / sizeof(targets[0]))));
	}
}

void MpDiscoveryStop(void)
{
	MpCloseSock(&gBeaconSock);
	gBeaconAdvertise = 0;
	gLastBeaconMs = 0;

	/* forget the servers we had, so a later browse starts from empty rather
	 * than showing rows that went silent while we were not listening */
	if (MpDiscoveryCount() > 0)
	{
		memset(gServers, 0, sizeof(gServers));
		gDiscoveryRev++;
	}
}

static void MpBeaconSend(void)
{
	MP_BEACON b;
	struct sockaddr_in addr;
	uint32_t targets[8];
	int n, i;

	memset(&b, 0, sizeof(b));
	b.magic = MP_UDP_MAGIC;
	b.protoVersion = (uint16_t)MP_PROTO_VERSION;
	b.port = (uint16_t)gMp.config.port;
	snprintf(b.hostName, sizeof(b.hostName), "%s", gMp.config.hostName);
	b.players = (uint8_t)gMp.playerCount;
	b.maxPlayers = MP_MAX_PLAYERS;
	b.gamemode = (uint8_t)gMp.gamemode;
	b.modsEnforced = (uint8_t)gMp.config.modCheck;
	b.city = (uint8_t)gMp.city;
	b.inProgress = (uint8_t)gMp.running;
	b.modHash = MpModHash();
	/* The third carrier of the packed rules byte (mp_proto.h): the browser reads
	 * it to NAME a server's mode before anyone joins it. */
	b.rules = (uint16_t)MpRulesForPeer();

	/* the beacon goes to the FIXED discovery port; b.port carries the session
	 * port so the browser knows where to connect. Sent once per broadcast
	 * address -- see MpBroadcastTargets. */
	n = MpBroadcastTargets(targets, (int)(sizeof(targets) / sizeof(targets[0])));

	for (i = 0; i < n; i++)
	{
		memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_port = htons((unsigned short)MP_DISCOVERY_PORT);
		addr.sin_addr.s_addr = targets[i];

		/* Which interfaces the beacon actually left by. "I can't see his
		 * server" is usually a beacon going out of the wrong adapter -- or
		 * out of none at all -- so log every target, not just the send. */
		if (MpDebugOn() && gMpCtx != NULL)
		{
			struct in_addr ia;
			ia.s_addr = targets[i];
			gMpCtx->jer_log(gMpCtx, "[mp] beacon -> %s:%d\n",
				inet_ntoa(ia), MP_DISCOVERY_PORT);
		}

		sendto(gBeaconSock, (const char*)&b, (int)sizeof(b), 0,
			(struct sockaddr*)&addr, sizeof(addr));
	}

	if (n <= 0 && MpDebugOn() && gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx,
			"[mp] beacon: no broadcast target at all -- no usable adapter? "
			"A server on this machine will be invisible to everyone.\n");
}

static void MpServerTouch(const char* ip, const MP_BEACON* b)
{
	char name[MP_NAME_MAX];
	int i, freeIdx = -1;

	/* A host beacons and also receives its own beacon, so on a single machine
	 * it lists itself and offers to join a game it is already running. We hold
	 * our own session port, so a beacon advertising it is us: skip it.
	 *
	 * A second copy of the game cannot bind the same session port, so this
	 * cannot hide a genuine companion instance -- which is exactly what
	 * same-machine testing uses. */
	if (MpIsHost() && (int)b->port == gMp.config.port)
		return;

	/* The wire name is a fixed 32-byte field with no guaranteed NUL. The precision
	 * bounds the READ as well as the write -- a bare %s would walk off the end of the
	 * beacon before snprintf's own size limit ever applied. */
	snprintf(name, sizeof(name), "%.*s", (int)sizeof(b->hostName), b->hostName);

	for (i = 0; i < MP_SERVER_SLOTS; i++)
	{
		if (gServers[i].used)
		{
			if (strcmp(gServers[i].ip, ip) == 0 && gServers[i].port == (int)b->port)
			{
				/* only count a change the browser can actually show: the
				 * beacon repeats every second and bumping the revision for an
				 * identical beacon would refresh the menu once a second */
				if (gServers[i].players != b->players ||
				    gServers[i].maxPlayers != b->maxPlayers ||
				    gServers[i].gamemode != b->gamemode ||
				    gServers[i].city != b->city ||
				    gServers[i].modsEnforced != b->modsEnforced ||
				    gServers[i].inProgress != b->inProgress ||
				    gServers[i].rules != b->rules ||
				    gServers[i].modHash != b->modHash ||
				    strcmp(gServers[i].hostName, name) != 0)
					gDiscoveryRev++;

				snprintf(gServers[i].hostName, MP_NAME_MAX, "%s", name);
				gServers[i].players = b->players;
				gServers[i].maxPlayers = b->maxPlayers;
				gServers[i].gamemode = b->gamemode;
				gServers[i].city = b->city;
				gServers[i].modsEnforced = b->modsEnforced;
				gServers[i].inProgress = b->inProgress;
				gServers[i].rules = b->rules;
				gServers[i].modHash = b->modHash;
				gServers[i].lastSeenMs = MpClockMs();
				return;
			}
		}
		else if (freeIdx < 0)
		{
			freeIdx = i;
		}
	}

	if (freeIdx < 0)
		return;		/* list full */

	memset(&gServers[freeIdx], 0, sizeof(gServers[freeIdx]));
	gServers[freeIdx].used = 1;
	snprintf(gServers[freeIdx].ip, sizeof(gServers[freeIdx].ip), "%s", ip);
	gServers[freeIdx].port = b->port;
	snprintf(gServers[freeIdx].hostName, MP_NAME_MAX, "%s", name);
	gServers[freeIdx].players = b->players;
	gServers[freeIdx].maxPlayers = b->maxPlayers;
	gServers[freeIdx].gamemode = b->gamemode;
	gServers[freeIdx].city = b->city;
	gServers[freeIdx].modsEnforced = b->modsEnforced;
	gServers[freeIdx].inProgress = b->inProgress;
	gServers[freeIdx].rules = b->rules;
	gServers[freeIdx].modHash = b->modHash;
	gServers[freeIdx].lastSeenMs = MpClockMs();
	gDiscoveryRev++;		/* a new row appeared in the browser */

	if (gMpCtx)
		gMpCtx->jer_log(gMpCtx, "[mp] server found: '%s' %s:%d (%d/%d players, %s, city %d)\n",
			gServers[freeIdx].hostName, ip, b->port,
			b->players, b->maxPlayers, MpModeName(b->gamemode), b->city);
}

static void MpBeaconRecv(void)
{
	for (;;)
	{
		MP_BEACON b;
		struct sockaddr_in from;
#ifdef _WIN32
		int fl = (int)sizeof(from);
#else
		socklen_t fl = sizeof(from);
#endif
		int n = recvfrom(gBeaconSock, (char*)&b, (int)sizeof(b), 0,
			(struct sockaddr*)&from, &fl);

		if (n <= 0)
			break;

		if (n < (int)sizeof(MP_BEACON))
			continue;

		if (b.magic != MP_UDP_MAGIC || b.protoVersion != (uint16_t)MP_PROTO_VERSION)
			continue;

		/* b is our own copy of the datagram, so the peer's name can be terminated
		 * here once and then read freely below (the debug log below uses %s). */
		b.hostName[sizeof(b.hostName) - 1] = '\0';

		/* Log every beacon we actually received, with its sender: when a
		 * server is visible from one machine and not the other, this line is
		 * the difference between the two. */
		if (MpDebugOn() && gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] beacon <- %s \"%s\" players=%u/%u city=%u\n",
				inet_ntoa(from.sin_addr), b.hostName,
				(unsigned)b.players, (unsigned)b.maxPlayers, (unsigned)b.city);

		MpServerTouch(inet_ntoa(from.sin_addr), &b);
	}
}

void MpDiscoveryPoll(unsigned long now)
{
	int i;

	if (gBeaconSock == INVALID_SOCKET)
		return;

	if (gBeaconAdvertise &&
	    (gLastBeaconMs == 0 || (now - gLastBeaconMs) >= (unsigned long)gMp.config.beaconMs))
	{
		MpBeaconSend();
		gLastBeaconMs = now;
	}

	MpBeaconRecv();

	/* drop silent servers */
	for (i = 0; i < MP_SERVER_SLOTS; i++)
	{
		if (gServers[i].used && (now - gServers[i].lastSeenMs) > MP_BEACON_TIMEOUT_MS)
		{
			if (gMpCtx)	/* say which one left -- it is gone from here */
				gMpCtx->jer_log(gMpCtx, "[mp] server gone: '%s' %s:%d\n",
					gServers[i].hostName, gServers[i].ip, gServers[i].port);

			memset(&gServers[i], 0, sizeof(gServers[i]));
			gDiscoveryRev++;	/* a row left the browser */
		}
	}
}

int MpDiscoveryCount(void)
{
	int i, n = 0;

	for (i = 0; i < MP_SERVER_SLOTS; i++)
		if (gServers[i].used)
			n++;

	return n;
}

MP_SERVER* MpDiscoveryGet(int index)
{
	int i, n = 0;

	for (i = 0; i < MP_SERVER_SLOTS; i++)
	{
		if (gServers[i].used)
		{
			if (n == index)
				return &gServers[i];
			n++;
		}
	}

	return NULL;
}

/* Monotonic counter for the visible server set (mp_ui.c rebuilds the LAN
 * browser only when this changes, so a live list stays stable otherwise). */
int MpDiscoveryRevision(void)
{
	return (int)gDiscoveryRev;
}

/* ------------------------------------------------------------------ */
/* The discovery server (master): the Online browser's list            */
/* ------------------------------------------------------------------ */
/* An internet host is not on our broadcast domain, so the LAN beacon cannot
 * find it: the list is FETCHED from the master (tools/servers/masterserver) and
 * kept here, separately from gServers -- MpDiscoveryStop wipes those on every
 * browse stop, and this list must survive one.
 *
 * The same three rules the session sockets follow apply, for the same reasons:
 *
 *   - the socket is NON-blocking and the fetch is a state machine driven from
 *     the frame poll, so a slow or dead master cannot stall the frontend;
 *   - getaddrinfo BLOCKS, so the name is resolved ONCE in MpOnlineSetMaster,
 *     which a menu press or a config change calls -- never the frame path;
 *   - the reply is read by a FIXED-SUBSET JSON reader with bounded buffers. A
 *     general JSON parser is a lot of code to trust for six fields, and a reply
 *     it cannot follow must leave the previous list ALONE rather than leave a
 *     half-replaced one behind.
 */

#define MP_ONLINE_TIMEOUT_MS	5000
#define MP_ONLINE_BUF_SIZE		8192

static SOCKET gOnlineSock = INVALID_SOCKET;
static struct sockaddr_in gOnlineAddr;
/* ONE socket and one state machine carry every master request -- the browser's
 * fetch and the advertisement's register/heartbeat/unregister -- so they are
 * serialised rather than racing over two connections. What the socket is being
 * used for decides how a finished reply is handled. */
#define MPI_REQ_FETCH		0
#define MPI_REQ_REGISTER	1
#define MPI_REQ_HEARTBEAT	2
#define MPI_REQ_UNREGISTER	3
#define MPI_REQ_VERIFY		4	/* the host fetching the list to find ITSELF */

static int  gOnlineKind;
static int  gOnlineState = MP_ONLINE_OFF;
static unsigned long gOnlineSinceMs;
static char gOnlineReq[512];		/* a GET fits in 320; a register POST does not */
static int  gOnlineReqLen, gOnlineReqSent;
static char gOnlineBuf[MP_ONLINE_BUF_SIZE];
static int  gOnlineLen;
static MP_ONLINE_SERVER gOnline[MP_ONLINE_MAX];
static int  gOnlineCount;
static int  gOnlineRetries;		/* early failures already retried */
static unsigned long gOnlineRetryAtMs;	/* when the next try is due */
static int  gOnlineEverReady;		/* one fetch has completed: stop excusing */

/* Is the server browser on screen? NOTHING talks to the master for a LISTING
 * unless it is: the game used to resolve the discovery server and fetch at module
 * activation, so every launch -- single-player included -- made a DNS lookup and an
 * HTTP request for a screen nobody opened, and kept retrying. The banner-advertise
 * path is separate and unaffected: a host lists itself whether or not it is looking
 * at the browser, because that is the point of hosting. */
static int  gOnlineWatching;

/* The configured master, kept unresolved until something needs to dial it. The name
 * used to be resolved in MpOnlineSetMaster, i.e. at module ACTIVATION -- a BLOCKING
 * getaddrinfo on every launch, single-player included, for a server most launches
 * never speak to. */
static char gOnlineName[128];
static int  gOnlinePort;
static int  gOnlineAddrOk;
static unsigned gOnlineRev;

/* The master's greeting. It rides in the same /v1/servers body (no second
 * request), and `rev` moves only when the TEXT changes so a browser that refreshes
 * every few seconds does not repeat the same line. */
static char gOnlineMotd[192];
static unsigned gOnlineMotdRev;
static unsigned char gOnlineMotdR = 240, gOnlineMotdG = 240, gOnlineMotdB = 240;
static char gOnlineError[96];
static char gOnlineUrl[160];		/* what the config said, for the log */
static char gOnlineHostHdr[160];	/* host:port, for the request's Host: */

/* Defined with the ping probe below, and used by the parse (a new list invalidates
 * every measurement) and by MpOnlineReset. */
static void MpOnlinePingReset(void);

/* --- the advertisement (this host, on that master) ------------------- */
static int  gAdvertOn;			/* a session is live and we mean to list it */
static int  gAdvertRegistered;		/* we hold a token */
static int  gAdvertBusy;			/* a request of ours is in flight */
static char gAdvertToken[40];		/* the master's handle for our entry */
static char gAdvertName[32];
static int  gAdvertPort, gAdvertCity, gAdvertGamemode, gAdvertRules;
static int  gAdvertPlayers, gAdvertMaxPlayers = 8, gAdvertInProgress;
static unsigned long gAdvertNextMs;	/* when the next beat (or retry) is due */
static void MpAdvertReply(int status, const char* body);
static const char* gAdvertWhy = "";	/* the last thing that went wrong, for the log */
static char gAdvertWhyBuf[64];		/* a socket-level failure, copied (MpOnlineFail's text) */
static int  gAdvertReach = -1;		/* the master's own probe of our port: -1 unknown, 0 down, 1 up */
static int  gAdvertListed = -1;		/* -1 unchecked, 0 missing from the list, 1 on it */
static char gAdvertSeenHost[64];	/* the host field our own row carries on the master */
static unsigned long gAdvertVerifyMs;	/* when the next list check is due (0 = none) */
#define MPI_ADVERT_VERIFY_FIRST_MS	1500	/* after the register ACK */
#define MPI_ADVERT_VERIFY_MS		60000	/* then, while hosting */

/* --- a fixed-subset JSON reader ------------------------------------ */

static const char* MpJsonSkipWs(const char* p, const char* end)
{
	while (p < end && (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n'))
		p++;

	return p;
}

/* The value of "key" within [obj, end), or NULL. A key that is not followed by a
 * colon is skipped and the search continues, so a nested object cannot hide a
 * later match. */
static const char* MpJsonValue(const char* obj, const char* end, const char* key)
{
	char pat[40];
	size_t klen = strlen(key);
	const char* p = obj;

	if (klen + 3 > sizeof(pat))
		return NULL;

	pat[0] = '"';
	memcpy(pat + 1, key, klen);
	pat[klen + 1] = '"';
	pat[klen + 2] = '\0';

	while (p < end)
	{
		const char* hit = strstr(p, pat);

		if (hit == NULL || hit >= end)
			return NULL;

		hit = MpJsonSkipWs(hit + klen + 2, end);

		if (hit < end && *hit == ':')
		{
			hit = MpJsonSkipWs(hit + 1, end);

			return (hit < end) ? hit : NULL;
		}

		p = hit;
	}

	return NULL;
}

static int MpJsonInt(const char* obj, const char* end, const char* key, int def)
{
	const char* v = MpJsonValue(obj, end, key);
	char* stop = NULL;
	long n;

	if (v == NULL)
		return def;

	n = strtol(v, &stop, 10);

	if (stop == v || stop > end)
		return def;

	return (int)n;
}

/* A JSON string into `out`. Escapes are unescaped one character deep, which is
 * all a server name needs; a name can never overrun `out`. */
static void MpJsonStr(const char* obj, const char* end, const char* key, char* out, size_t n)
{
	const char* v = MpJsonValue(obj, end, key);
	size_t w = 0;

	if (n > 0)
		out[0] = '\0';

	if (v == NULL || *v != '"' || n == 0)
		return;

	v++;

	while (v < end && *v != '"' && w + 1 < n)
	{
		if (*v == '\\' && (v + 1) < end)
			v++;

		out[w++] = *v++;
	}

	out[w] = '\0';
}

/* The matching '}' for the '{' at `p`, or NULL. Strings are skipped, so a brace
 * inside a name cannot end the object early. */
static const char* MpJsonObjectEnd(const char* p, const char* end)
{
	int depth = 0, inStr = 0;

	while (p < end)
	{
		char c = *p++;

		if (inStr)
		{
			if (c == '\\')
			{
				p++;
				continue;
			}

			if (c == '"')
				inStr = 0;

			continue;
		}

		if (c == '"')
			inStr = 1;
		else if (c == '{')
			depth++;
		else if (c == '}')
		{
			if (--depth == 0)
				return p - 1;
		}
	}

	return NULL;
}

/* Replace the list from a reply BODY. Returns 0 -- and changes nothing -- if the
 * body is not the shape the master documents. */
static int MpOnlineParse(const char* body)
{
	MP_ONLINE_SERVER tmp[MP_ONLINE_MAX];
	const char* end = body + strlen(body);
	const char* arr = MpJsonValue(body, end, "servers");
	const char* p;
	int count = 0;

	if (arr == NULL || *arr != '[')
		return 0;

	p = arr + 1;

	while (p < end && *p != ']' && count < MP_ONLINE_MAX)
	{
		const char* close;
		MP_ONLINE_SERVER* s;

		if (*p != '{')
		{
			p++;
			continue;
		}

		close = MpJsonObjectEnd(p, end);

		if (close == NULL)
			return 0;		/* truncated */

		s = &tmp[count];
		memset(s, 0, sizeof(*s));

		MpJsonStr(p, close, "name", s->name, sizeof(s->name));
		MpJsonStr(p, close, "host", s->host, sizeof(s->host));
		s->port = MpJsonInt(p, close, "port", 0);
		s->players = MpJsonInt(p, close, "players", 0);
		s->maxPlayers = MpJsonInt(p, close, "maxPlayers", 0);
		s->city = MpJsonInt(p, close, "city", 0);
		s->rules = MpJsonInt(p, close, "rules", 0);
		s->gamemode = MpJsonInt(p, close, "gamemode", MP_GAMEMODE_TAKEADRIDE);

		/* a row with nowhere to connect to is not a row */
		if (s->host[0] != '\0' && s->port > 0 && s->port <= 65535)
			count++;

		p = close + 1;
	}

	/* The master's greeting, from the SAME body (no second request). Both keys are
	 * optional: a master that says nothing prints nothing. An unparsable colour
	 * keeps the previous one rather than going black, which would be unreadable. */
	{
		char txt[sizeof(gOnlineMotd)];
		char col[16];

		MpJsonStr(body, end, "motd", txt, sizeof(txt));
		MpJsonStr(body, end, "motdColor", col, sizeof(col));

		if (strcmp(txt, gOnlineMotd) != 0)
		{
			snprintf(gOnlineMotd, sizeof(gOnlineMotd), "%s", txt);
			gOnlineMotdRev++;		/* a NEW line is worth saying again */
		}

		if (col[0] == '#' && strlen(col + 1) >= 6)
		{
			unsigned long v = strtoul(col + 1, NULL, 16);

			gOnlineMotdR = (unsigned char)((v >> 16) & 0xFF);
			gOnlineMotdG = (unsigned char)((v >> 8) & 0xFF);
			gOnlineMotdB = (unsigned char)(v & 0xFF);
		}
	}

	memcpy(gOnline, tmp, (size_t)count * sizeof(tmp[0]));

	/* a new list means new addresses: every measurement is now about a row that
	 * no longer exists, so the probes start again */
	MpOnlinePingReset();

	/* the ROW COUNT is what a menu has to rebuild for; the values inside a row
	 * are read live by the draw, so they need no revision of their own */
	if (count != gOnlineCount)
		gOnlineRev++;

	gOnlineCount = count;

	/* one fetch has now worked, so an early-race excuse no longer applies */
	gOnlineEverReady = 1;
	gOnlineRetries = 0;
	gOnlineRetryAtMs = 0;

	return 1;
}

/* --- the fetch ------------------------------------------------------ */

/* Until one fetch has COMPLETED, a failure is not a verdict: the first attempt
 * happens at module activation, where Winsock is not up yet and the socket call
 * itself fails ("could not open a socket"), and a cold resolver fails its first
 * lookup too. Both looked identical from the player's side -- "cannot be reached",
 * then a list, with no click in between -- so an early failure retries a few times
 * before it is believed. A server that really is unreachable still ends in the
 * same toast, three retries and nine seconds later. */
#define MP_ONLINE_RETRIES		3
#define MP_ONLINE_RETRY_MS		3000

/* How old a listing may be before reopening the browser refreshes it. Short, because
 * a player who opens the screen wants the current list; the point of the rest of this
 * is that NOTHING happens while the screen is closed. */
#define MP_ONLINE_WATCH_REFRESH_MS	15000

static void MpOnlineClose(void)
{
	MpCloseSock(&gOnlineSock);
	gOnlineReqSent = 0;
}

static void MpOnlineFail(const char* why)
{
	MpOnlineClose();

	/* whatever we were sending did not arrive; the advertisement retries later and
	 * the session carries on either way */
	gAdvertBusy = 0;

	if (gAdvertOn)
	{
		gAdvertNextMs = MpNowMs() + MPI_ADVERT_RETRY_MS;

		/* a failed register is a failed listing; a failed beat or list check only
		 * means we do not know right now */
		if (gOnlineKind == MPI_REQ_VERIFY)
			gAdvertVerifyMs = MpNowMs() + MPI_ADVERT_RETRY_MS;
		else if (!gAdvertRegistered)
		{
			snprintf(gAdvertWhyBuf, sizeof(gAdvertWhyBuf), "%s", why);
			gAdvertWhy = gAdvertWhyBuf;
		}
	}

	snprintf(gOnlineError, sizeof(gOnlineError), "%s", why);

	if (!gOnlineEverReady && gOnlineRetries < MP_ONLINE_RETRIES)
	{
		gOnlineRetries++;
		gOnlineState = MP_ONLINE_CONNECTING;	/* still trying: no alarm yet */
		gOnlineRetryAtMs = MpNowMs() + MP_ONLINE_RETRY_MS;

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] discovery server %s: %s -- retrying (%d/%d)\n",
				gOnlineHostHdr, why, gOnlineRetries, MP_ONLINE_RETRIES);

		return;
	}

	gOnlineState = MP_ONLINE_FAILED;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] discovery server %s: %s\n", gOnlineHostHdr, why);

	/* A HOST whose listing never landed should be told so, not left to wonder why
	 * the game is not on the Online board. The success case already says "master:
	 * listed as ..."; this is the failure half of that same report. */
	if (gAdvertOn && !gAdvertRegistered && gOnlineKind != MPI_REQ_VERIFY)
		jer_console_log("hosting: not listed online (%s) - LAN beacon still works", why);
}

void MpOnlineReset(void)
{
	MpOnlineClose();
	MpOnlinePingReset();
	gOnlineState = MP_ONLINE_OFF;
	gOnlineError[0] = '\0';
	gOnlineUrl[0] = '\0';
	gOnlineHostHdr[0] = '\0';
	gOnlineRetries = 0;
	gOnlineRetryAtMs = 0;
	gOnlineEverReady = 0;
	gOnlineName[0] = '\0';
	gOnlineAddrOk = 0;

	if (gOnlineCount > 0)
	{
		memset(gOnline, 0, sizeof(gOnline));
		gOnlineCount = 0;
		gOnlineRev++;
	}
}

/* Take the shared socket and send `req`. EVERY master request goes through here --
 * the browser's fetch and the advertisement's register/heartbeat/unregister -- so
 * there is one connect path, one timeout and one state machine to reason about.
 * Non-blocking: the connect itself completes in the poll. */
/* Resolve the configured master, once, when something is about to use it. Returns
 * 0 (and reports the failure the usual way) if there is nothing to resolve. */
static int MpOnlineEnsureAddr(void)
{
	if (gOnlineAddrOk)
		return 1;

	if (gOnlineName[0] == '\0')
		return 0;

	/* BLOCKING, and that is why it is here and not in the poll -- but only ever on
	 * the frame that is about to talk to the master, not on every launch. */
	if (!MpResolveHost(gOnlineName, gOnlinePort, &gOnlineAddr))
	{
		MpOnlineFail("the name does not resolve");
		return 0;
	}

	gOnlineAddrOk = 1;
	return 1;
}

static void MpHttpKick(const char* req, int kind)
{
	SOCKET s;
	int rc;

	MpOnlineClose();
	gOnlineError[0] = '\0';

	s = socket(AF_INET, SOCK_STREAM, 0);

	if (!MpOnlineEnsureAddr())
		return;

	if (s == INVALID_SOCKET)
	{
		MpOnlineFail("could not open a socket");
		return;
	}

	MpSetNonBlocking(s, 1);

	rc = connect(s, (struct sockaddr*)&gOnlineAddr, sizeof(gOnlineAddr));

	if (rc != 0 && !MpWouldBlock())
	{
		MpCloseSock(&s);
		MpOnlineFail("connection refused");
		return;
	}

	gOnlineSock = s;

	snprintf(gOnlineReq, sizeof(gOnlineReq), "%s", req);

	gOnlineReqLen = (int)strlen(gOnlineReq);
	gOnlineReqSent = 0;
	gOnlineLen = 0;
	gOnlineSinceMs = MpNowMs();
	gOnlineKind = kind;
	gOnlineState = MP_ONLINE_CONNECTING;
}

/* Kick off (or retry) the fetch. The address is already resolved. */
void MpOnlineRefresh(void)
{
	char req[320];

	gOnlineRetries = 0;		/* an explicit refresh restarts the count */
	gOnlineRetryAtMs = 0;

	if (gOnlineHostHdr[0] == '\0')
	{
		/* An empty browser with no request on the wire looks, from outside, exactly
		 * like a master that never answered -- so name which one it is. */
		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx,
				"[mp] online: nothing to fetch (no discovery server; name '%s')\n",
				gOnlineName);

		return;
	}

	snprintf(req, sizeof(req),
		"GET /v1/servers?limit=%d HTTP/1.1\r\n"
		"Host: %s\r\n"
		"User-Agent: jericho-mp\r\n"
		"Accept: application/json\r\n"
		"Connection: close\r\n"
		"\r\n",
		MP_ONLINE_MAX, gOnlineHostHdr);

	MpHttpKick(req, MPI_REQ_FETCH);
}

void MpOnlineSetMaster(const char* url)
{
	char host[128];
	const char* p;
	char* colon;
	/* the master's port, not the http default: a bare host used to dial 80, where
	 * nothing is listening, and the screen just said "contacting" until it gave up */
	int port = 8100;

	MpOnlineClose();
	gOnlineError[0] = '\0';
	gOnlineHostHdr[0] = '\0';

	if (url == NULL || url[0] == '\0')
	{
		gOnlineState = MP_ONLINE_OFF;
		gOnlineUrl[0] = '\0';
		return;
	}

	snprintf(gOnlineUrl, sizeof(gOnlineUrl), "%s", url);

	/* take a scheme and a path off, so both "master.example.com:8100" and
	 * "http://master.example.com:8100/v1" are usable as typed */
	p = url;

	if (strncmp(p, "http://", 7) == 0)
		p += 7;

	snprintf(host, sizeof(host), "%s", p);

	{
		char* slash = strchr(host, '/');

		if (slash != NULL)
			*slash = '\0';
	}

	colon = strrchr(host, ':');

	if (colon != NULL)
	{
		port = atoi(colon + 1);
		*colon = '\0';
	}

	if (host[0] == '\0' || port <= 0 || port > 65535)
	{
		MpOnlineFail("that is not a usable address");
		return;
	}

	snprintf(gOnlineHostHdr, sizeof(gOnlineHostHdr), "%s:%d", host, port);

	/* remember it; resolving waits until something is about to dial */
	snprintf(gOnlineName, sizeof(gOnlineName), "%s", host);
	gOnlinePort = port;
	gOnlineAddrOk = 0;
	gOnlineRetries = 0;
	gOnlineRetryAtMs = 0;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] discovery server set to %s (from '%s')\n",
			gOnlineHostHdr, url);

	/* NOT MpOnlineRefresh(): configuring the address must not contact anything.
	 * The browser asks when it opens, and the advertise path resolves on demand. */
}

/* --- the ping probe --------------------------------------------------
 * One row at a time, a non-blocking connect whose COMPLETION TIME is the
 * measurement. A connect is a single round trip, which is what a player wants to
 * know before committing to a join, and it needs nothing from the peer -- no
 * protocol, and no cooperation from a master we do not run.
 *
 * The host a master reports is the peer's own address, so it is an IP literal in
 * practice, and MpResolveHost has an IPv4 fast path that never reaches the
 * resolver for one. A NAME would block, which is why the queue is drained here
 * (from the fetch's own arrival) rather than anywhere more time-critical.
 *
 * A row nobody has measured keeps MP_ONLINE_PING_UNSET and the browser shows a
 * dash: "no measurement" and "a slow server" must not look the same. A row whose
 * connect FAILED gets MP_ONLINE_PING_FAILED and shows an x -- that is the cell
 * that tells a player, before they click, that the listed server is not dialable
 * (a shut port is the usual reason, and it was the reason this was added: a
 * working listing, a shut session port, and nothing on screen to say so).
 *
 * The reading is quantised by the FRAME -- the connect is started one frame and
 * noticed one or more frames later -- so a round trip shorter than a frame
 * reports as one frame (~16 ms at 60 fps) and a loopback server reads ~30. That
 * is the honest resolution of this method, and it is enough to separate "near"
 * from "far", which is what the column is for. */
#define MP_ONLINE_PING_TIMEOUT_MS	1200

static SOCKET gOnlinePingSock = INVALID_SOCKET;
static int  gOnlinePingIndex = -1;	/* the row being probed, -1 = idle */
static int  gOnlinePingNext;		/* the next row to probe */
static unsigned long gOnlinePingStartMs;

/* The row is listed but nothing answers on it. Said in the console as well as the
 * log, because the player reading the browser is the one who needs it -- the log
 * is read by someone else, later. */
static void MpOnlinePingFailed(int index)
{
	if (index < 0 || index >= gOnlineCount)
		return;

	gOnline[index].pingMs = MP_ONLINE_PING_FAILED;

	jer_console_log("online: %s:%d does not answer", gOnline[index].host, gOnline[index].port);

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] online: %s:%d listed but unreachable\n",
			gOnline[index].host, gOnline[index].port);
}

static void MpOnlinePingReset(void)
{
	MpCloseSock(&gOnlinePingSock);

	gOnlinePingIndex = -1;
	gOnlinePingNext = 0;
}

static void MpOnlinePingStart(int index)
{
	struct sockaddr_in addr;
	SOCKET s;

	/* A LITERAL that does not parse is not a name to look up: the master already
	 * told us the address, so a failure here is a failure of that address. */
	if (!MpResolveHost(gOnline[index].host, gOnline[index].port, &addr))
		return;

	s = socket(AF_INET, SOCK_STREAM, 0);

	if (s == INVALID_SOCKET)
		return;

	MpSetNonBlocking(s, 1);
	connect(s, (struct sockaddr*)&addr, sizeof(addr));	/* never blocks */

	gOnlinePingSock = s;
	gOnlinePingIndex = index;
	gOnlinePingStartMs = MpNowMs();
}

static void MpOnlinePingPoll(void)
{
	fd_set wfds, efds;
	struct timeval tv;
	int err = 0;
#ifdef _WIN32
	int elen = (int)sizeof(err);
#else
	socklen_t elen = sizeof(err);
#endif

	if (gOnlinePingIndex >= 0)
	{
		if (gOnlinePingSock == INVALID_SOCKET)
		{
			gOnlinePingIndex = -1;
			return;
		}

		FD_ZERO(&wfds);
		FD_SET(gOnlinePingSock, &wfds);
		FD_ZERO(&efds);
		FD_SET(gOnlinePingSock, &efds);
		tv.tv_sec = 0;
		tv.tv_usec = 0;

		if (select((int)gOnlinePingSock + 1, NULL, &wfds, &efds, &tv) <= 0)
		{
			if (MpElapsedMs(MpNowMs(), gOnlinePingStartMs) > (unsigned long)MP_ONLINE_PING_TIMEOUT_MS)
			{
				/* a connect that never completes is as undialable as one that
				 * is refused, so it gets the same mark */
				MpOnlinePingFailed(gOnlinePingIndex);
				MpCloseSock(&gOnlinePingSock);
				gOnlinePingIndex = -1;
			}

			return;			/* still connecting */
		}

		if (getsockopt(gOnlinePingSock, SOL_SOCKET, SO_ERROR, (char*)&err, &elen) == 0 && err == 0)
		{
			gOnline[gOnlinePingIndex].pingMs = (int)MpElapsedMs(MpNowMs(), gOnlinePingStartMs);

			if (MpDebugOn() && gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] online ping: row %d %s:%d = %d ms\n",
					gOnlinePingIndex, gOnline[gOnlinePingIndex].host,
					gOnline[gOnlinePingIndex].port, gOnline[gOnlinePingIndex].pingMs);
		}
		else
		{
			MpOnlinePingFailed(gOnlinePingIndex);
		}

		MpCloseSock(&gOnlinePingSock);
		gOnlinePingIndex = -1;

		return;				/* one measurement per frame */
	}

	/* idle: take the next row nobody has measured yet */
	while (gOnlinePingNext >= 0 && gOnlinePingNext < gOnlineCount)
	{
		int i = gOnlinePingNext++;

		if (gOnline[i].pingMs == MP_ONLINE_PING_UNSET)
		{
			MpOnlinePingStart(i);
			return;
		}
	}

	gOnlinePingNext = -1;			/* the queue is drained */
}

/* The browser opened or closed. Everything a LISTING needs hangs off this. */
void MpOnlineSetWatching(int on)
{
	on = on ? 1 : 0;

	if (on == gOnlineWatching)
		return;

	gOnlineWatching = on;

	if (gMpCtx != NULL)
		gMpCtx->jer_log(gMpCtx, "[mp] online: watching %s (state %d, name '%s')\n",
			on ? "on" : "off", gOnlineState, gOnlineName);

	if (!on)
	{
		/* stop talking to the master: drop the request in flight and cancel a
		 * pending retry. The rows stay, so reopening draws the last list while the
		 * new one arrives -- and the next open refreshes it. */
		if (gOnlineState == MP_ONLINE_CONNECTING || gOnlineState == MP_ONLINE_READING)
		{
			MpOnlineClose();
			gOnlineState = MP_ONLINE_OFF;
		}

		gOnlineRetryAtMs = 0;

		return;
	}

	/* Opening it: refresh if there is nothing to show, or what we have is old
	 * enough that showing it would be a lie. */
	if (gOnlineState == MP_ONLINE_OFF || gOnlineState == MP_ONLINE_FAILED
	    || MpElapsedMs(MpNowMs(), gOnlineSinceMs) > (unsigned long)MP_ONLINE_WATCH_REFRESH_MS)
		MpOnlineRefresh();
}

/* The retry, driven by the poll. A failed attempt leaves no socket and no state
 * machine to make progress with, so without this the retry would never fire. */
static void MpOnlineRetryPoll(void)
{
	char url[sizeof(gOnlineUrl)];

	if (gOnlineState != MP_ONLINE_CONNECTING || gOnlineRetryAtMs == 0)
		return;

	if (MpNowMs() < gOnlineRetryAtMs)
		return;

	gOnlineRetryAtMs = 0;

	/* SetMaster writes into gOnlineUrl, so it cannot be handed its own buffer */
	snprintf(url, sizeof(url), "%s", gOnlineUrl);
	MpOnlineSetMaster(url);
}

void MpOnlinePoll(void)
{
	fd_set wfds, efds;
	struct timeval tv;
	unsigned long now;
	int err = 0;
#ifdef _WIN32
	int elen = (int)sizeof(err);
#else
	socklen_t elen = sizeof(err);
#endif

	if (gOnlineWatching)
		MpOnlineRetryPoll();

	/* Ping measurements are for the screen that shows them, so they only advance
	 * while it is open. */
	if (gOnlineWatching)
		MpOnlinePingPoll();

	if (gOnlineState != MP_ONLINE_CONNECTING && gOnlineState != MP_ONLINE_READING)
		return;

	/* A LISTING request is abandoned the moment the browser closes; an ADVERTISE is
	 * the host's own business and runs to completion either way. */
	if (!gOnlineWatching && gOnlineKind == MPI_REQ_FETCH)
	{
		MpOnlineClose();
		gOnlineState = MP_ONLINE_OFF;
		return;
	}

	if (gOnlineSock == INVALID_SOCKET)
		return;

	now = MpNowMs();

	if (MpElapsedMs(now, gOnlineSinceMs) > (unsigned long)MP_ONLINE_TIMEOUT_MS)
	{
		MpOnlineFail("timed out");
		return;
	}

	if (gOnlineState == MP_ONLINE_CONNECTING)
	{
		if (gOnlineReqSent == 0)
		{
			/* wait for the connect to complete before sending anything */
			FD_ZERO(&wfds);
			FD_SET(gOnlineSock, &wfds);
			FD_ZERO(&efds);
			FD_SET(gOnlineSock, &efds);
			tv.tv_sec = 0;
			tv.tv_usec = 0;

			if (select((int)gOnlineSock + 1, NULL, &wfds, &efds, &tv) <= 0)
				return;		/* still connecting */

			if (getsockopt(gOnlineSock, SOL_SOCKET, SO_ERROR, (char*)&err, &elen) != 0 || err != 0)
			{
				MpOnlineFail("connection refused");
				return;
			}
		}

		while (gOnlineReqSent < gOnlineReqLen)
		{
			int n = send(gOnlineSock, gOnlineReq + gOnlineReqSent,
				gOnlineReqLen - gOnlineReqSent, 0);

			if (n > 0)
			{
				gOnlineReqSent += n;
				continue;
			}

			if (n < 0 && MpWouldBlock())
				return;		/* the rest goes next frame */

			MpOnlineFail("the request could not be sent");
			return;
		}

		gOnlineLen = 0;
		gOnlineState = MP_ONLINE_READING;

		return;
	}

	/* READING: one bounded recv per frame, then parse on close */
	while (gOnlineLen < (int)sizeof(gOnlineBuf) - 1)
	{
		int n = recv(gOnlineSock, gOnlineBuf + gOnlineLen,
			(int)sizeof(gOnlineBuf) - 1 - gOnlineLen, 0);

		if (n > 0)
		{
			gOnlineLen += n;
			continue;
		}

		if (n == 0)
		{
			const char* body;
			int ok = 0;

			gOnlineBuf[gOnlineLen] = '\0';
			body = strstr(gOnlineBuf, "\r\n\r\n");

			if (body == NULL)
			{
				MpOnlineFail("the reply had no body");
				return;
			}

			/* the advertisement's replies are not lists: hand them over and stop --
			 * a 201 from register is a success, not a malformed fetch */
			if (gOnlineKind != MPI_REQ_FETCH)
			{
				int status = 0;
				const char* sp = strchr(gOnlineBuf, ' ');

				if (sp != NULL)
					status = atoi(sp + 1);

				MpAdvertReply(status, body + 4);
				MpOnlineClose();
				return;
			}

			/* a 200 is the only answer that carries a list; anything else
			 * (a 404 from a master behind a path rewrite, a 502 from a proxy)
			 * says so rather than being parsed as empty */
			if (strstr(gOnlineBuf, " 200 ") == NULL)
			{
				MpOnlineFail("the discovery server refused the request");
				return;
			}

			ok = MpOnlineParse(body + 4);

			MpOnlineClose();

			if (!ok)
			{
				gOnlineState = MP_ONLINE_FAILED;
				snprintf(gOnlineError, sizeof(gOnlineError), "the reply could not be read");

				if (gMpCtx != NULL)
					gMpCtx->jer_log(gMpCtx, "[mp] discovery server: the reply could not be read\n");
				return;
			}

			gOnlineState = MP_ONLINE_READY;

			if (gMpCtx != NULL)
				gMpCtx->jer_log(gMpCtx, "[mp] discovery server: %d server(s)\n", gOnlineCount);
			return;
		}

		if (MpWouldBlock())
			return;			/* more next frame */

		MpOnlineFail("the connection was lost");
		return;
	}

	/* the buffer filled without a body end: not something we can read */
	MpOnlineFail("the reply was too large");
}

int MpOnlineState(void)		{ return gOnlineState; }
const char* MpOnlineError(void)	{ return gOnlineError; }
int MpOnlineCount(void)		{ return gOnlineCount; }
int MpOnlineRevision(void)	{ return (int)gOnlineRev; }
const char* MpOnlineMotd(void)	{ return gOnlineMotd; }
int MpOnlineMotdRev(void)	{ return (int)gOnlineMotdRev; }

void MpOnlineMotdColor(unsigned char* r, unsigned char* g, unsigned char* b)
{
	if (r != NULL) *r = gOnlineMotdR;
	if (g != NULL) *g = gOnlineMotdG;
	if (b != NULL) *b = gOnlineMotdB;
}

const MP_ONLINE_SERVER* MpOnlineGet(int index)
{
	if (index < 0 || index >= gOnlineCount)
		return NULL;

	return &gOnline[index];
}
/* --- advertising this host on the master -----------------------------
 * The mirror of the fetch above: same socket, same state machine, same rules --
 * non-blocking, driven from the frame poll, never in the way of a session.
 *
 * Registered when a session starts HOSTING and unregistered when it ends. In
 * between a small heartbeat carries the live player count, because that is the
 * number a player picks a server by and a listing that says 1/8 while four are
 * playing is worse than none. A master we cannot reach costs one retry: the LAN
 * beacon needs no server at all, so nothing about hosting depends on this.
 */

/* A host name is free text and goes into JSON: the quote, the backslash and
 * control characters have to survive it, or the master answers 400 to a perfectly
 * good name like Bob's "good" game. */
static void MpJsonEscape(char* dst, size_t cap, const char* src)
{
	size_t o = 0;

	for (; src != NULL && *src != '\0' && o + 7 < cap; src++)
	{
		unsigned char c = (unsigned char)*src;

		if (c == '"' || c == '\\')
		{
			dst[o++] = '\\';
			dst[o++] = (char)c;
		}
		else if (c < 0x20)
		{
			o += (size_t)snprintf(dst + o, cap - o, "\\u%04x", c);
		}
		else
		{
			dst[o++] = (char)c;
		}
	}

	dst[(o < cap) ? o : (cap > 0 ? cap - 1 : 0)] = '\0';
}

static void MpAdvertPost(const char* path, const char* body, int kind)
{
	char req[512];

	snprintf(req, sizeof(req),
		"POST %s HTTP/1.1\r\n"
		"Host: %s\r\n"
		"User-Agent: jericho-mp\r\n"
		"Content-Type: application/json\r\n"
		"Content-Length: %d\r\n"
		"Connection: close\r\n"
		"\r\n"
		"%s",
		path, gOnlineHostHdr, (int)strlen(body), body);

	gAdvertBusy = 1;
	MpHttpKick(req, kind);
}

static void MpAdvertRegister(void)
{
	char name[128], body[320];

	MpJsonEscape(name, sizeof(name), gAdvertName);

	/* the same fields the beacon carries, so a browser can name this game from
	 * either source, plus the two counters only the master can show */
	snprintf(body, sizeof(body),
		"{\"name\":\"%s\",\"port\":%d,\"city\":%d,\"gamemode\":%d,\"rules\":%d,"
		"\"players\":%d,\"maxPlayers\":%d,\"inProgress\":%d,"
		"\"modsEnforced\":%d,\"modHash\":%u,\"protoVersion\":%d,\"sdkVersion\":%d}",
		name, gAdvertPort, gAdvertCity, gAdvertGamemode, gAdvertRules,
		gAdvertPlayers, gAdvertMaxPlayers, gAdvertInProgress,
		(int)gMp.config.modCheck, (unsigned)MpModHash(),
		MP_PROTO_VERSION, JERICHO_SDK_VERSION);

	MpAdvertPost("/v1/register", body, MPI_REQ_REGISTER);
}

static void MpAdvertHeartbeat(void)
{
	char body[160];

	snprintf(body, sizeof(body),
		"{\"token\":\"%s\",\"players\":%d,\"inProgress\":%d}",
		gAdvertToken, gAdvertPlayers, gAdvertInProgress);

	MpAdvertPost("/v1/heartbeat", body, MPI_REQ_HEARTBEAT);
}

static void MpAdvertUnregister(void)
{
	char body[96];

	snprintf(body, sizeof(body), "{\"token\":\"%s\"}", gAdvertToken);

	MpAdvertPost("/v1/unregister", body, MPI_REQ_UNREGISTER);
}

/* Our own row in a /v1/servers reply: same name and port as we registered. The
 * master fills "host" from the address it saw the register come from, which is
 * the host's public address as the internet sees it. */
static void MpAdvertVerifyReply(int status, const char* body)
{
	const char* end = body + strlen(body);
	const char* arr = MpJsonValue(body, end, "servers");
	const char* p;
	int found = 0;

	gAdvertVerifyMs = MpNowMs() + MPI_ADVERT_VERIFY_MS;

	if (status != 200 || arr == NULL || *arr != '[')
		return;				/* unknown, not "missing": keep the last verdict */

	for (p = arr + 1; p < end && *p != ']' && !found; )
	{
		const char* close;
		char name[MP_NAME_MAX], host[64];

		if (*p != '{')
		{
			p++;
			continue;
		}

		close = MpJsonObjectEnd(p, end);
		if (close == NULL)
			break;

		MpJsonStr(p, close, "name", name, sizeof(name));
		MpJsonStr(p, close, "host", host, sizeof(host));

		if (MpJsonInt(p, close, "port", 0) == gAdvertPort && strcmp(name, gAdvertName) == 0)
		{
			const char* r = MpJsonValue(p, close, "reachable");

			found = 1;
			snprintf(gAdvertSeenHost, sizeof(gAdvertSeenHost), "%s", host);
			gAdvertReach = (r == NULL || *r == 'n') ? -1 : (*r == 't') ? 1 : 0;
		}

		p = close + 1;
	}

	if (found != gAdvertListed)
	{
		if (found)
			jer_console_log("master: confirmed on the public list as %s:%d", gAdvertSeenHost, gAdvertPort);
		else
			jer_console_log("master: accepted the listing but it is NOT on the public list");

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] advertising: list check %s (seen as '%s')\n",
				found ? "found us" : "did NOT find us", gAdvertSeenHost);
	}

	gAdvertListed = found;

	if (!found)
		gAdvertReach = -1;
}

static void MpAdvertVerify(void)
{
	char req[320];

	snprintf(req, sizeof(req),
		"GET /v1/servers?limit=%d HTTP/1.1\r\n"
		"Host: %s\r\n"
		"User-Agent: jericho-mp\r\n"
		"Accept: application/json\r\n"
		"Connection: close\r\n"
		"\r\n",
		MP_ONLINE_MAX, gOnlineHostHdr);

	gAdvertBusy = 1;
	MpHttpKick(req, MPI_REQ_VERIFY);
}

int MpMasterAdvertiseReachable(void) { return gAdvertReach; }

int MpMasterAdvertiseStatus(const char** why, const char** seenHost, const char** master)
{
	if (why != NULL)
		*why = gAdvertWhy;
	if (seenHost != NULL)
		*seenHost = gAdvertSeenHost;
	if (master != NULL)
		*master = gOnlineHostHdr;

	if (!gAdvertOn)
		return MP_ADV_OFF;
	if (gMp.config.masterUrl[0] == '\0' || gOnlineHostHdr[0] == '\0')
		return MP_ADV_NO_MASTER;
	if (!gAdvertRegistered)
		return (gAdvertWhy[0] != '\0') ? MP_ADV_FAILED : MP_ADV_PENDING;
	if (gAdvertListed == 1)
		return MP_ADV_LISTED;
	if (gAdvertListed == 0)
		return MP_ADV_MISSING;

	return MP_ADV_ACKED;
}

static void MpAdvertReply(int status, const char* body)
{
	gAdvertBusy = 0;

	if (gOnlineKind == MPI_REQ_VERIFY)
	{
		MpAdvertVerifyReply(status, body);
		return;
	}

	if (status < 200 || status > 299)
	{
		/* A master that restarted or expired us answers a beat 404 unknown_token:
		 * register again instead of beating a dead token forever. */
		if (gOnlineKind == MPI_REQ_HEARTBEAT && status == 404)
		{
			gAdvertRegistered = 0;
			gAdvertToken[0] = '\0';
			gAdvertListed = -1;
			gAdvertSeenHost[0] = '\0';
			gAdvertNextMs = 0;
			jer_console_log("master: forgot this game - registering again");
			return;
		}

		gAdvertWhy = "the master refused it";
		jer_console_log("master: %s refused the listing", gOnlineHostHdr);
		gAdvertNextMs = MpNowMs() + MPI_ADVERT_RETRY_MS;

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] advertising: %s (HTTP %d)\n", gAdvertWhy, status);

		return;
	}

	if (gOnlineKind == MPI_REQ_REGISTER)
	{
		const char* t = strstr(body, "\"token\"");

		gAdvertNextMs = MpNowMs() + MPI_ADVERT_BEAT_MS;

		if (t != NULL)
		{
			const char* q = strchr(t + 7, '"');

			if (q != NULL)
			{
				const char* e = strchr(q + 1, '"');

				if (e != NULL && (size_t)(e - q - 1) < sizeof(gAdvertToken))
				{
					memcpy(gAdvertToken, q + 1, (size_t)(e - q - 1));
					gAdvertToken[e - q - 1] = '\0';
					gAdvertRegistered = 1;
				}
			}
		}

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] advertised on %s as %s:%d (%s)\n",
				gOnlineHostHdr, gAdvertName, gAdvertPort, MpModeName(gAdvertGamemode));

		/* ...and say so on SCREEN, in the left-hand console rows (the same place the
		 * version toast goes): the menu label that would carry this is capped at 32
		 * characters, which is why "contacting the discovery server..." arrives cut in
		 * half. The console has room for the whole sentence and keeps it for a moment. */
		jer_console_log("master: listed as %s", gAdvertName);

		/* the register reply carries the address the master saw us from */
		MpJsonStr(body, body + strlen(body), "host", gAdvertSeenHost, sizeof(gAdvertSeenHost));

		/* ACK is not presence: go and look for our own row */
		gAdvertWhy = "";
		gAdvertListed = -1;
		gAdvertVerifyMs = MpNowMs() + MPI_ADVERT_VERIFY_FIRST_MS;
	}
	else if (gOnlineKind == MPI_REQ_HEARTBEAT)
	{
		gAdvertNextMs = MpNowMs() + MPI_ADVERT_BEAT_MS;

	}
	else if (gOnlineKind == MPI_REQ_UNREGISTER)
	{
		gAdvertRegistered = 0;
		gAdvertToken[0] = '\0';

		if (gMpCtx != NULL)
			gMpCtx->jer_log(gMpCtx, "[mp] withdrawn from %s\n", gOnlineHostHdr);
	}
}

void MpMasterAdvertiseStart(const char* name, int port, int city, int gamemode, int rules)
{
	gAdvertOn = 1;
	gAdvertRegistered = 0;
	gAdvertBusy = 0;
	gAdvertToken[0] = '\0';
	gAdvertWhy = "";
	gAdvertListed = -1;
	gAdvertReach = -1;
	gAdvertSeenHost[0] = '\0';
	gAdvertVerifyMs = 0;
	snprintf(gAdvertName, sizeof(gAdvertName), "%s",
		(name != NULL && name[0] != '\0') ? name : "A game");
	gAdvertPort = port;
	gAdvertCity = city;
	gAdvertGamemode = gamemode;
	gAdvertRules = rules;
	gAdvertPlayers = 1;
	gAdvertMaxPlayers = MP_MAX_PLAYERS;
	gAdvertInProgress = gMp.running ? 1 : 0;
	gAdvertNextMs = 0;			/* due on the next poll */

	/* No master configured = no listing, on purpose: say so once on the console
	 * so a host is not left wondering why its game never shows up Online. The
	 * LAN beacon still runs. */
	if (gMp.config.masterUrl[0] == '\0')
		jer_console_log("hosting: LAN only - no discovery server set (master_url in mp.ini)");
}

void MpMasterAdvertiseCounts(int players, int inProgress)
{
	if (players > 0)
		gAdvertPlayers = players;

	gAdvertInProgress = inProgress ? 1 : 0;
}

void MpMasterAdvertiseStop(void)
{
	if (!gAdvertOn)
		return;

	gAdvertOn = 0;

	if (!gAdvertRegistered)
		return;

	/* Best effort. If the socket is busy, or the master is gone, the entry lapses on
	 * its own ttl -- nothing here is worth delaying a session teardown for. */
	if (gOnlineHostHdr[0] != '\0' && !gAdvertBusy
		&& gOnlineState != MP_ONLINE_CONNECTING && gOnlineState != MP_ONLINE_READING)
	{
		MpAdvertUnregister();
		return;
	}

	gAdvertRegistered = 0;
	gAdvertToken[0] = '\0';
}

void MpMasterAdvertisePoll(void)
{
	unsigned long now;

	/* nothing to do and nothing in flight */
	if (!gAdvertOn && !gAdvertBusy && !gAdvertRegistered)
		return;

	/* ONE request at a time on the socket shared with the browser's fetch */
	if (gOnlineState == MP_ONLINE_CONNECTING || gOnlineState == MP_ONLINE_READING)
		return;

	if (gAdvertBusy)
		gAdvertBusy = 0;			/* it finished; MpAdvertReply saw the answer */

	if (!gAdvertOn)
		return;

	if (gOnlineHostHdr[0] == '\0')
		return;					/* no master configured: LAN beacon only */

	now = MpNowMs();

	if (gAdvertRegistered && gAdvertVerifyMs != 0 && (long)(now - gAdvertVerifyMs) >= 0)
	{
		gAdvertVerifyMs = 0;			/* re-armed by the reply */
		MpAdvertVerify();
		return;
	}

	if (gAdvertNextMs != 0 && (long)(now - gAdvertNextMs) < 0)
		return;					/* not due yet */

	if (gAdvertRegistered)
		MpAdvertHeartbeat();
	else
		MpAdvertRegister();
}

