/*
 * antfarm.c — "Ant Farm" screensaver / idle mode (JERICHO module).
 *
 * A passive city observer for REDRIVER2. When enabled it:
 *   - cuts off player input (gStopPadReads), hides the HUD (gDoOverlays),
 *     silences the player's own car engine so its idle loop stops (the
 *     JER_EVENT_CAR_ENGINE_SOUND hook - the master volume alone never did it,
 *     because SetMasterVolume(0) is UNITY gain and silence is -10000; the
 *     master volume is instead kept at the game's normal level so the music
 *     and the city stay audible), disables cop aggression (CopsAllowed = 0),
 *   - pins the hidden player car to the camera focus and redirects the
 *     region spool there, so geometry + traffic stream to every shot,
 *   - hops to a FAR area of the map on every cut (touring the whole city)
 *     and picks a diverse cinematic shot:
 *       CHASE    : behind-follow on a traffic car, framed to vehicle size
 *       STATIC   : a fixed roadside camera tracking a car as it passes
 *       OVERHEAD : scenic elevated 3/4 view down onto traffic (car or road)
 *       TRIPOD   : parked roadside camera watching a junction/road
 *       FLYOVER  : slow eased dolly along a long straight
 *       JUNCTION : parked vantage sliding its aim across a crossroads
 *     Static/overhead styles are weighted over the chase cam.
 *   - while focusing on a car, the camera cycles through multiple angles
 *     (chase behind, chase front, side, overhead, static) every few seconds,
 *     inspired by the replay director's camera modes, before cutting to a
 *     new area.
 *   - optional rogue-car events (off by default): a tiny chance per cut that
 *     the car of interest becomes LEAD AI and tears across the map, with
 *     cops giving chase; the camera follows it until it is totaled.
 *
 * Transitions fade through a semi-transparent wash (the stock FadeGameScreen
 * look) and reselect while black, so the new area streams in without popping.
 *
 * Toggle: F9 (keyboard, PC) or Pause -> Modules -> Ant Farm. Pressing START
 * hands control back and opens the normal pause.
 *
 * Pure JERICHO module — no game files are edited.
 */

#include "jericho.h"
#include "jer_events.h"
#include "jer_config.h"
#include "jer_pause_menu.h"

#include "driver2.h"
#include "dr2math.h"
#include "players.h"	/* player[] / MainPlayer (spoolXZ, playerType) */
#include "cars.h"		/* car_data[] */
#include "camera.h"		/* camera_position, camera_angle, CameraCar, PointAtTarget */
#include "dr2roads.h"	/* Driver2StraightsPtr, MapHeight */
#include "main.h"		/* gStopPadReads, game_over, FrameCnt */
#include "overlay.h"	/* gDoOverlays */
#include "system.h"		/* current (prim buffer) */
#include "cutscene.h"	/* gInGameCutsceneActive */
#include "glaunch.h"	/* quick_replay, NoPlayerControl */
#include "mission.h"	/* NumPlayers, CopsAllowed */
#include "pause.h"	/* pauseflag - the pause menu is up */
#include "convert.h"	/* Random2 */
#include "objcoll.h"	/* lineClear, CheckScenaryCollisions */
#include "civ_ai.h"	/* reservedSlots, InitCar */
#include "sound.h"	/* gMasterVolume, SetMasterVolume */
#include "felony.h"	/* GetPlayerFelony */
#include "map.h"	/* units_across_halved, units_down_halved, current_region, regions_across */
#include "jer_map.h"	/* shared region maths / residency / force (see map-streaming.md) */
#include "jer_net.h"	/* jer_net_is_active - stand down during an mp session */
#include "spool.h"	/* spoolinfo_offsets, regions_unpacked */
#include "pres.h"	/* SetTextColour, PrintString (overlay captions) */

 /* spool.c:171 — 1 when the barrel regions around the current spool position
  * are all unpacked. Not in a header; the module brings its own extern. */
extern int check_regions_present(void);

#include "antfarm.h"

/* civ_ai.c:970 — the canonical road-segment + distance → x,z sampler.
 * Not declared in any header; the module brings its own extern. */
extern int GetNodePos(DRIVER2_STRAIGHT* straight, DRIVER2_JUNCTION* junction,
	DRIVER2_CURVE* curve, int distAlongPath, CAR_DATA* cp,
	int* x, int* z, int laneNo);

#ifndef PSX
#include <SDL.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h> /* for malloc/free */

#define ANT_MOD_ID "antfarm"

/* ------------------------------------------------------------------ */
/* module RNG                                                         */
/* ------------------------------------------------------------------ */
/* Random2() is a pure function of the frame counter, so every call in a
 * single frame returns the SAME value: the old code's "24 random picks"
 * were 24 identical picks, and every cut's framing was correlated with
 * the frame it happened to land on. We keep our own LCG, seeded once per
 * run - pinned by the engine's debug -seed (so two runs are comparable)
 * and otherwise drawn from ASLR + rdtsc so it varies every launch. */
#if defined(_MSC_VER) && (defined(_M_IX86) || defined(_M_X64))
#include <intrin.h>
#define ANT_HAVE_RDTSC 1
#endif

static unsigned int sRunSeedOverride;	/* 0 = not pinned */
static unsigned int sRngState;
static int sRngInit;

static void AntFarmSetRunSeed(unsigned int seed)
{
	sRunSeedOverride = seed;
	sRngState = 0;
	sRngInit = 0;
}

static unsigned int AntFarmRunSeed(void)
{
	int probe;
	unsigned int s;

	if (sRunSeedOverride != 0)
		return sRunSeedOverride;

	s = (unsigned int)(size_t)&sRngState;	/* ASLR */
	s ^= (unsigned int)(size_t)&probe;		/* stack */

#if defined(ANT_HAVE_RDTSC)
	s ^= (unsigned int)__rdtsc();
	s ^= (unsigned int)(__rdtsc() >> 32);
#endif

	s ^= (unsigned int)Random2(0) << 11;
	s = s * 2654435761u + 2246822519u;		/* avalanche */

	if (s == 0)
		s = 0x9E3779B9u;

	return s;
}

/* advance-and-return, 0..32767 */
static int AntRand(void)
{
	if (!sRngInit)
	{
		sRngState = AntFarmRunSeed();
		sRngInit = 1;
	}

	sRngState = sRngState * 1664525u + 1013904223u;	/* Numerical Recipes LCG */
	return (int)((sRngState >> 16) & 0x7fff);
}

/* inclusive range low..high (order-tolerant) */
static int AntRandRange(int lo, int hi)
{
	if (lo > hi) { int t = lo; lo = hi; hi = t; }
	if (hi == lo) return lo;
	return lo + AntRand() % (hi - lo + 1);
}

/* true with the given percent chance */
static int AntRandChance(int percent)
{
	return (percent > 0) && ((AntRand() % 100) < percent);
}

/* ------------------------------------------------------------------ */
/* camera archetypes                                                  */
/* ------------------------------------------------------------------ */
/* how the camera is driven. Several archetypes share a model and differ only
 * in their ranges (a kerb pass is a roadside camera that happens to be low and
 * long-lensed), so a new angle stays a single table row. */
#define ANT_MODEL_ROADSIDE   0	/* camera parked beside the road, framing it */
#define ANT_MODEL_DOLLY      1	/* travel along the road (flyover/crane) */
#define ANT_MODEL_ORBIT      2	/* circle the subject */
#define ANT_MODEL_FOLLOW     3	/* car-relative chase */
#define ANT_MODEL_TRACK      4	/* fixed roadside camera tracking a car */
#define ANT_MODEL_ATTACH     5	/* rig on the car itself (fender/sill/3-4) */
#define ANT_MODEL_CRANE      6	/* travel along the road while rising */
#define ANT_MODEL_TRIPODZ    7	/* fixed vantage on a car, long lens */
#define ANT_MODEL_JUNCTION   8	/* parked vantage on a junction mouth */
#define ANT_MODEL_COUNT      9

/* Is this model's camera code implemented yet? A style whose model is not
 * implemented is never offered by the picker and never defaults on, so a
 * half-landed archetype cannot be selected. Each new rig flips its case on as
 * its camera lands. */
static int AntFarmStyleImplemented(int model)
{
	switch (model)
	{
	case ANT_MODEL_ROADSIDE:
	case ANT_MODEL_DOLLY:
	case ANT_MODEL_ORBIT:
	case ANT_MODEL_FOLLOW:
	/* ANT_MODEL_TRACK ("Static track") is intentionally NOT implemented: the
	 * style relocated its fixed camera spot every time the subject passed it or
	 * drifted away, so the view jumped/interpolated between new vantage points
	 * every few seconds - hysterical. It is retired from the rotation. */
	case ANT_MODEL_CRANE:
	case ANT_MODEL_ATTACH:
	case ANT_MODEL_TRIPODZ:
	case ANT_MODEL_JUNCTION:
		return 1;

	default:
		return 0;
	}
}

/* display name for a camera model, for the log */
static const char* AntFarmModelName(int model)
{
	switch (model)
	{
	case ANT_MODEL_ROADSIDE:  return "roadside";
	case ANT_MODEL_DOLLY:     return "dolly";
	case ANT_MODEL_ORBIT:     return "orbit";
	case ANT_MODEL_FOLLOW:    return "follow";
	/* Model names. "track" still prints for the retired Static track row. */
	case ANT_MODEL_TRACK:     return "track(retired)";
	case ANT_MODEL_ATTACH:    return "attach";
	case ANT_MODEL_CRANE:     return "crane";
	case ANT_MODEL_TRIPODZ:   return "tripodz";
	case ANT_MODEL_JUNCTION:  return "junction";
	default:                  return "?";
	}
}

/* The road-following models: the ones that frame a road (along or across it)
 * and therefore share the upward framing bias (ANTFARM_ROAD_AIM_LIFT +
 * ANTFARM_ROAD_PITCH_UP) and the never-stare-at-the-ground pitch guard. The
 * attached rigs, the trail cam, the orbit and the tripod-zoom keep their own
 * framing. */
static int AntFarmModelIsRoadFacing(int model)
{
	return model == ANT_MODEL_ROADSIDE || model == ANT_MODEL_DOLLY ||
		model == ANT_MODEL_CRANE || model == ANT_MODEL_JUNCTION;
}

/* integer square root, so distances can be logged without pulling in floats */
static int AntFarmDist(int dx, int dz)
{
	long long v = (long long)dx * dx + (long long)dz * dz;
	long long r = v;

	if (v <= 0)
		return 0;

	while (r > v / r)
		r = (r + v / r) / 2;

	return (int)r;
}

/* One row per style. Both the director (selection) and the framing code read
 * from here, so a new camera archetype is a single line. Lo/Hi are inclusive
 * ranges the per-cut randomiser draws from. */
typedef struct ANT_STYLE_DEF
{
	const char* label;	/* menu + log label */
	const char* key;	/* config key suffix: style_<key> */
	int model;		/* ANT_MODEL_* - how the camera is driven */
	int weight;		/* selection weight */
	int roadOnly;		/* 1 = never takes a car subject */
	int carFirst;		/* 1 = takes (and prefers) a car subject */
	int behind;		/* attached rigs: 1 = sit behind the car */
	int zoom;		/* 1 = slow lens push-in then out across the shot */
	int heightLo, heightHi;	/* camera elevation above ground/road */
	int scrZLo, scrZHi;	/* FOV (projection distance); smaller = wider.
				 * For a zoom style these are the ramp's two ends. */
	int sideLo, sideHi;	/* lateral offset: rig offset, or the roadside margin */
	int fwdLo, fwdHi;	/* longitudinal offset (attached rigs) */
	int aimLo, aimHi;	/* how far ahead of the subject to look */
	int orbitLo, orbitHi;	/* azimuth sweep amplitude (0 = fixed) */
	int across;		/* 1 = aim across the road, not along it */
	int settle;		/* camera settle divisor (bigger = calmer) */
	int dwell;		/* scene-interest dwell multiplier, x100 */
	int nearWater;		/* 1 = prefer a road that runs beside water */
} ANT_STYLE_DEF;

/* The archetype table. Weight, subject capability and all the per-cut
 * framing ranges live here; picking and framing both read it.
 *
 * The elevated rows (Overhead / Flyover / Crane) keep their heights in a
 * showcase 3/4 band rather than a top-down: with the height-scaled aim lift
 * (AntFarmRoadAimLift) a 500-high vantage would otherwise aim straight down
 * the near lane, and the pitch guard (ANTFARM_PITCH_DOWN_MAX) would then be
 * fighting the row. Lower here means the framing is right by construction. */
static const ANT_STYLE_DEF antStyleDefs[ANTFARM_STYLE_COUNT] = {
	/* label          key          model            wt rOnly car beh zoom  hLo  hHi scrLo scrHi sLo sHi  fLo  fHi aimLo aimHi orbLo orbHi acr set dwell  nw */
	{ "Chase cam",    "chase",     ANT_MODEL_FOLLOW,   8,   0,   1,  0,  0,  180,  340,  260,  276,    0,    0,   0,    0,    0,    0,    0,    0,  0,   8,   90 },
	{ "Static track", "static",    ANT_MODEL_TRACK,   22,   0,   1,  0,  0,  180,  300,  258,  280,    0,    0,   0,    0,    0,    0,    0,    0,  0,   6,  120 },
	{ "Overhead",     "overhead",  ANT_MODEL_ROADSIDE,26,   0,   0,  0,  0,  300,  520,  218,  242,  180,  360,   0,    0,  900, 1100,  300,  760,  0,  14,  130 },
	{ "Tripod",       "tripod",    ANT_MODEL_ROADSIDE,16,   0,   0,  0,  0,  140,  260,  238,  268,  135,  270,   0,    0,  900, 1100,  820, 1140,  0,  16,  120 },
	{ "Flyover",      "flyover",   ANT_MODEL_DOLLY,   12,   0,   1,  0,  0,  300,  500,  248,  272,    0,    0,   0,    0,    0,    0,    0,    0,  0,  18,  140 },
	{ "Orbit",        "orbit",     ANT_MODEL_ORBIT,   12,   0,   0,  0,  0,  200,  440,  232,  262,    0,    0,   0,    0,    0,    0,    0,    0,  0,  20,  140 },
	{ "Crane",        "crane",     ANT_MODEL_CRANE,  10,   0,   1,  0,  0,   90,  560,  240,  270,    0,    0,   0,    0,    0,    0,    0,    0,  0,  18,  150 },
	{ "Ant level",    "low",       ANT_MODEL_ROADSIDE,10,   0,   0,  0,  0,   45,   95,  250,  282,  180,  360,   0,    0,    0,  220,  200,  480,  1,  16,  120 },
	/* --- car-attached rigs (damped, yaw-only: see ANT_MODEL_ATTACH) --- */
	{ "Fender",       "fender",    ANT_MODEL_ATTACH,  12,   0,   1,  0,  0,   45,   85,  250,  272,   20,   60, 260,  380,  900, 1200,    0,    0,  0,   3,  110 },
	{ "Sill",         "sill",      ANT_MODEL_ATTACH,  12,   0,   1,  0,  0,   40,   75,  245,  265,  240,  330, -60,   60,  400,  700,    0,    0,  0,   3,  110 },
	{ "Nose 3/4",     "nose34",    ANT_MODEL_ATTACH,  12,   0,   1,  0,  0,   90,  150,  250,  272,  200,  300, 320,  480,  500,  800,    0,    0,  0,   5,  120 },
	{ "Tail 3/4",     "tail34",    ANT_MODEL_ATTACH,  12,   0,   1,  1,  0,   90,  150,  245,  268,  180,  280, 260,  420,  500,  800,    0,    0,  0,   5,  120 },
	/* --- free / static angles --- */
	{ "Kerb pass",    "kerb",      ANT_MODEL_ROADSIDE,12,   0,   0,  0,  0,   40,   80,  290,  320,  200,  320,   0,    0,    0,  200,  180,  420,  1,  14,  120 },
	{ "Tripod zoom",  "tripzoom",  ANT_MODEL_TRIPODZ, 12,   0,   1,  0,  1,  120,  220,  235,  300,  200,  360, 500, 1500,  900, 1200,  300,  600,  0,  18,  150 },
	{ "Far pan",      "farpan",    ANT_MODEL_TRIPODZ, 10,   0,   1,  0,  1,  200,  340,  290,  340, 1400, 2200, 2000, 4000,  900, 1300,  400,  900,  0,  20,  150 },
	{ "Waterfront",   "water",     ANT_MODEL_DOLLY,   10,   1,   0,  0,  0,   60,  180,  250,  275,    0,    0,   0,    0,  700, 1000,    0,    0,  0,  16,  150,  1 },
	/* --- parked vantage on a junction (see ANT_MODEL_JUNCTION) --- */
	{ "Junction",     "junction",  ANT_MODEL_JUNCTION,12,   1,   0,  0,  0,  120,  320,  236,  266,  170,  300,   0,    0,  250,  700,  300,  700,  0,  14,  135 },
	/* --- car-following chase family (ANT_MODEL_FOLLOW). A row that sets its
	 * FORWARD range drives the trail framing itself: height -> camera height,
	 * fwd -> trail distance, side -> rear-3/4 offset, aim -> look-ahead (see
	 * AntFarmFollowCam). A row leaving fwd at 0 keeps the legacy trail. --- */
	{ "High chase",   "highchase", ANT_MODEL_FOLLOW,   8,   0,   1,  0,  0,  420,  760,  264,  280,    0,    0, 1500, 2400,  900, 1300,    0,    0,  0,   9,  110 },
	{ "Low chase",    "lowchase",  ANT_MODEL_FOLLOW,   8,   0,   1,  0,  0,   90,  150,  250,  276,    0,    0,  500,  900,  450,  750,    0,    0,  0,   6,  110 },
	{ "Side track",   "sidetrack", ANT_MODEL_FOLLOW,   9,   0,   1,  0,  0,  150,  280,  248,  274,  350,  750,  250,  650,  500,  900,    0,    0,  0,   6,  110 },
};

/* ------------------------------------------------------------------ */
/* cached usable road list (fast random & nearest)                    */
/* ------------------------------------------------------------------ */
static int* g_usableRoads = NULL;
static int g_numUsableRoads = 0;
static int g_usableRoadsAlloc = 0;
static int g_usableRoadsBuiltFor = -1;	/* NumDriver2Straights the cache was built from */

/* spool.c / map.c — unpacked status of each region (1 = loaded) */
extern int regions_unpacked[];
/* ------------------------------------------------------------------ */
/* module state                                                       */
/* ------------------------------------------------------------------ */

typedef struct ANTFARM_STATE
{
	JERICHO_CONTEXT* ctx;

	int active;		/* screensaver running */
	int pendingEnable;	/* antfarm.ini said enabled — activate when playable */
	int camSnapped;		/* camera has been snapped to the current target */

	int style;		/* ANTFARM_STYLE_* */
	int targetKind;		/* ANTFARM_TARGET_* */
	int state;		/* ANTFARM_STATE_* */
	int fade;		/* 0..255 overlay wash intensity */
	unsigned long stateStart;	/* when the current state began (ms) */
	unsigned long shotStart;	/* when the current shot's fade-in began (ms) */
	int fadeInMs;		/* duration of the current FADE_IN (the first shot is shorter) */
	int firstShot;		/* this activation has not revealed a shot yet: reveal as soon as it streams */

	int intervalMs;					/* seconds per visible shot (cut interval) */
	int stylesEnabled[ANTFARM_STYLE_COUNT];
	int leadEnabled;	/* rogue-car events allowed */
	int leadChance;		/* percent chance per cut */

	/* the shot's subject */
	int targetCarId;	/* CAR targets: car_data index */
	int roadSurfId;		/* ROAD targets: straight index (== surfId) */
	int roadLane;		/* lane index sampled on that road */
	int roadDist;		/* distAlongPath on the road (world units) */
	int junctionCorner;	/* shot sits just past a junction mouth, looking back */
	VECTOR targetPos;	/* world-space focus (also the spool content) */
	VECTOR areaPos;		/* the far-area anchor of the current cut */

	/* per-shot framing */
	int shotSideSign;	/* +1/-1 — which side of the road/car the camera sits */
	int lastSideSign;	/* the flank the previous shot used (flank variety) */
	int shotMargin;		/* clearance from the road half-width edge */
	int shotHeight;		/* camera elevation above the road/ground */
	int shotFwd;		/* attached rigs: longitudinal offset from the car */
	int shotSide;		/* attached rigs: lateral offset from the car */
	int shotLookAhead;	/* how far ahead of the camera the aim sits */
	int shotOrbitAmp;	/* tripod azimuth sweep amplitude (0 = static) */
	int shotOrbitPhase;	/* orbit phase seed */
	int shotScrZ;		/* per-shot FOV (projection distance) */
	int shotZoomTo;		/* a zoom row's other lens end (== shotScrZ when it holds) */

	/* the follow (trail) cam: damped position + slow yaw, no mode switching */
	VECTOR trailPos;	/* smoothed trail-cam position */
	int trailYaw;		/* smoothed trail-cam yaw (0..4095) */
	int trailSet;		/* the trail cam has been seeded for this shot */

	VECTOR trackCamPos;	/* STATIC style: the fixed roadside camera spot */

	VECTOR spool;		/* what MainPlayer.spoolXZ points at while active */

	VECTOR camPos;		/* smoothed camera position */
	VECTOR aimPos;		/* current aim point (render space) */
	SVECTOR camAngle;	/* smoothed camera angle */

	/* cut staging */
	int cutInit;		/* CUT state has planned this cut */
	int cutWaitForCar;	/* CUT is waiting for traffic near the new area */
	unsigned long cutStart;	/* when the CUT state began (ms) */
	unsigned long cutEnter;	/* when this CUT first began (never reset) */
	long long jumpDist2;	/* squared jump distance (for hold scaling) */
	int streamRetries;	/* far-area re-picks on streaming timeouts */
	int streamDone;		/* the new area's regions have been accepted+loaded */
	int shotPlanned;	/* 1 when the shot for this cut has been fully planned */
	int seededThisCut;	/* traffic has been pre-seeded for this cut's area */
	int blockReady;		/* regions of the destination's block that are resident */
	int blockUsable;	/* how many of the block's regions have data (the target) */

	/* rogue-car (lead AI) event */
	int leadMode;		/* following a rogue car until it is totaled */
	int leadEnding;		/* totaled — holding on the wreck before moving on */
	unsigned long leadEndStart;

	/* engine state saved/restored around activation */
	int savedStopPadReads;
	int savedDoOverlays;
	VECTOR* savedSpoolXZ;
	int savedCopsAllowed;
	int savedMasterVolume;
	int savedScrZ;		/* projection distance, restored on exit (was leaked) */
	int savedCameraCar;	/* CameraCar, restored on exit (was leaked) */
	int fovCurrent;		/* smoothed scr_z so the lens breathes instead of jumping */
	int rollOn;		/* subtle horizon roll for a less rigid frame */
	unsigned long stillSince;	/* when the subject of a rig shot stopped moving */

	/* travelling shots (dolly/crane): distance is advanced per frame and rolled
	 * onto the connected road at a junction, instead of being parameterised
	 * along one straight (which parked the camera on that road's end) */
	unsigned long lastDollyMs;
	int handoffs;

	/* per-shot telemetry, reported when the shot ends so "is it really
	 * attached?" and "did the lens actually move?" are answerable from the log */
	int lastState;
	int shotDistMin, shotDistMax;
	int fovMin, fovMax;
	int pitchMin, pitchMax;	/* camera tilt range over the shot (0 = level, +=down) */

	/* fixed vantage for the tripod-zoom / far-pan shots, resolved once */
	VECTOR shotVantage;
	int vantageSet;

	/* void guard: while the shot's region is not resident, hold the previous
	 * camera instead of drawing an unloaded one */
	unsigned long holdSince;
	int voidHolds;
	VECTOR holdPos;		/* last camera that rendered a RESIDENT region */
	SVECTOR holdAngle;	/* its angle, held with it while re-streaming */

	/* world recovery: how long the camera has been in an un-resident region,
	 * and how many times the tour has had to re-anchor itself on a road */
	unsigned long stuckSince;
	int recoveries;

	/* presentation dressing */
	int letterbox;		/* draw the soft cinematic bars */
	int captions;		/* show the occasional place-name caption */
	int debugHud;		/* bottom-right readout of the current shot (debug_hud) */
	unsigned long captionUntil;	/* when the current caption fades out */

	/* texture-area guard: the cell the camera was last in, so a live shot that
	 * crosses cells can request the new cell's area data at once */
	int lastCellX, lastCellZ;

	/* director state: a rolling memory of recent styles so consecutive cuts
	 * never repeat, plus the interest-scaled dwell of the current shot */
	int recentStyles[ANTFARM_STYLE_MEMORY];
	int recentCount;
	int recentCars[ANTFARM_STYLE_MEMORY];	/* cars already framed recently */
	int recentCarCount;
	int dwellMs;		/* this shot's visible time, interest-scaled */

	/* player car saved/restored around activation (teleport + hide) */
	int savedPlayerCarControlType;
	int savedPlayerReservedSlot;
	long savedPlayerCarPos[3];
	int savedPlayerFelony;	/* short on the car; int here */

	int cutCount;		/* diagnostic counter */
	int f9Down;		/* F9 edge detection */
} ANTFARM_STATE;

static ANTFARM_STATE s;

/* How far ABOVE the road point a road-following camera should aim, for a
 * camera `height` above its ground. The lift scales with the camera's own
 * height so a high vantage looks ACROSS the scene rather than down at the road
 * surface; a low camera keeps the flat baseline (ANTFARM_ROAD_AIM_LIFT). Pass
 * the height the camera is ACTUALLY at (a crane rises, so its lift must track
 * the rising height, not the shot's final one). See antfarm.h for the
 * reasoning (a flat lift was invisible at height 400+). */
static int AntFarmRoadAimLift(int height)
{
	int lift = height * ANTFARM_ROAD_AIM_PCT / 100;

	return lift > ANTFARM_ROAD_AIM_LIFT ? lift : ANTFARM_ROAD_AIM_LIFT;
}

/* ------------------------------------------------------------------ */
/* forward declarations for functions used before they are defined    */
/* ------------------------------------------------------------------ */
static void AntFarmPlanShot(void);
static void AntFarmPinPlayerCar(void);
static void AntFarmSetupRoadShot(void);
static void AntFarmInitShotVars(void);
static int AntFarmPickFarArea(void);
static int AntFarmPickRoadNear(int x, int z);
static int AntFarmTrafficNear(const VECTOR* pos, int radius);
static void AntFarmPickStyleAndTarget(void);
static void AntFarmBuildRoadCache(void);
static void AntFarmSetActive(int on);
static void AntFarmSuspend(void);
static void AntFarmRecoverToRoad(void);

/* ------------------------------------------------------------------ */
/* timing                                                             */
/* ------------------------------------------------------------------ */

static unsigned long AntTicks(void)
{
#ifndef PSX
	return (unsigned long)SDL_GetTicks();
#else
	return (unsigned long)FrameCnt * 1000 / 30;
#endif
}

/* the cut interval is config-driven */
static int AntIntervalMs(void)
{
	return (s.intervalMs > 0) ? s.intervalMs : ANTFARM_DEFAULT_INTERVAL * 1000;
}

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

static CAR_DATA* AntFarmValidCar(void)
{
	if (s.targetCarId < 0 || s.targetCarId >= MAX_CARS)
		return NULL;

	CAR_DATA* cp = &car_data[s.targetCarId];

	if (cp->controlType != CONTROL_TYPE_CIV_AI &&
		cp->controlType != CONTROL_TYPE_LEAD_AI)
		return NULL;

	return cp;
}

static int AntFarmMapHeight(int x, int z)
{
	VECTOR p;
	int h;

	p.vx = x;
	p.vy = 0;
	p.vz = z;

	h = MapHeight(&p);
	return (h != 0) ? h : 200; /* Fallback default height to avoid complete void drop */
}

/* ------------------------------------------------------------------ */
/* ROAD CACHE                                                         */
/* ------------------------------------------------------------------ */

/* Build the list of roads that can be used for shots (angle<2048, length>400) */
static void AntFarmBuildRoadCache(void)
{
	int n = NumDriver2Straights;

	g_usableRoadsBuiltFor = n;

	if (n <= 0) {
		g_numUsableRoads = 0;
		return;
	}

	if (g_usableRoadsAlloc < n) {
		int* grown = (int*)malloc((size_t)n * sizeof(int));

		if (grown == NULL) {
			/* keep the old (smaller) cache rather than dereferencing NULL */
			g_numUsableRoads = 0;
			return;
		}

		if (g_usableRoads) free(g_usableRoads);
		g_usableRoads = grown;
		g_usableRoadsAlloc = n;
	}

	{
		int count = 0;
		int i;

		for (i = 0; i < n; i++) {
			DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[i];

			/* Every long straight is usable. (The old filter also demanded
			 * angle < 2048, which silently dropped every road whose heading was in
			 * the second half of the compass - half the map never got a shot.) */
			if (rd->length > 400)
				g_usableRoads[count++] = i;
		}

		g_numUsableRoads = count;
	}
}

/* rebuild the cache whenever the level's straight count changes, not just
 * when it grows: a level change to one with FEWER straights left the old
 * indices in place, which indexes Driver2StraightsPtr out of bounds */
static void AntFarmEnsureRoadCache(void)
{
	if (g_usableRoadsBuiltFor != NumDriver2Straights || g_numUsableRoads == 0)
		AntFarmBuildRoadCache();
}

/* pick a straight at least minLen long, using the cache */
static int AntFarmPickSurface(int minLen)
{
	if (g_numUsableRoads == 0)
		return -1;

	/* Try up to 24 random picks from the cache */
	for (int i = 0; i < 24; i++) {
		int idx = g_usableRoads[AntRand() % g_numUsableRoads];
		if (Driver2StraightsPtr[idx].length > minLen)
			return idx;
	}

	/* Fallback: scan all usable roads for the longest that meets minLen */
	int best = -1, bestLen = 0;
	for (int i = 0; i < g_numUsableRoads; i++) {
		int idx = g_usableRoads[i];
		int len = Driver2StraightsPtr[idx].length;
		if (len > minLen && len > bestLen) {
			bestLen = len;
			best = idx;
		}
	}
	return best;
}

/* Does this straight run beside water? The engine's sea is a single flat plane
 * (GetSeaPlane, dr2roads.c:15) reached through the surface lookup, so probe a
 * few points along the road for a water or beach surface. */
static int AntFarmRoadNearWater(DRIVER2_STRAIGHT* rd)
{
	int i;

	if (rd->length < 600)
		return 0;

	for (i = 0; i <= 3; i++)
	{
		int x = 0x7fffffff, z = 0x7fffffff;
		VECTOR p;
		int surf;

		GetNodePos(rd, NULL, NULL, (rd->length * i) / 3, NULL, &x, &z, 0);

		if (x == 0x7fffffff || z == 0x7fffffff)
			continue;

		p.vx = x;
		p.vy = 0;
		p.vz = z;

		surf = GetSurfaceIndex(&p);

		if (surf == SURF_WATER || surf == SURF_DEEPWATER || surf == SURF_SAND)
			return 1;
	}

	return 0;
}

/* Nearest usable road that actually runs beside water, or -1 if none is. */
static int AntFarmPickWaterRoad(int x, int z)
{
	int best = -1, i;
	long long bestD2 = -1;

	for (i = 0; i < g_numUsableRoads; i++)
	{
		int idx = g_usableRoads[i];
		DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[idx];
		long long dx, dz, d2;

		if (!AntFarmRoadNearWater(rd))
			continue;

		dx = (long long)rd->Midx - x;
		dz = (long long)rd->Midz - z;
		d2 = dx * dx + dz * dz;

		if (bestD2 < 0 || d2 < bestD2)
		{
			bestD2 = d2;
			best = idx;
		}
	}

	return best;
}

/* Pick the closest usable road to (x,z) */
static int AntFarmPickRoadNear(int x, int z)
{
	if (g_numUsableRoads == 0)
		return -1;

	int best = -1;
	long long bestD2 = -1;
	for (int i = 0; i < g_numUsableRoads; i++) {
		int idx = g_usableRoads[i];
		DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[idx];
		long long dx = (long long)rd->Midx - x;
		long long dz = (long long)rd->Midz - z;
		long long d2 = dx * dx + dz * dz;
		if (bestD2 < 0 || d2 < bestD2) {
			bestD2 = d2;
			best = idx;
		}
	}
	return best;
}

/* A driveable surface is either a STRAIGHT or a CURVE. A curve carries
 * start/end angles, an inside radius and lane data but NO length or angle field,
 * so its length is the engine's own arc-length form (civ_ai.c:
 * curveLength = ((end - start) & 0xfff) * inside * 11 / 7). These two accessors
 * let the probes and the dolly treat either without caring which it is - a
 * straight and a curve meeting at a junction is the common case. */
static int AntFarmRoadLen(int surfId)
{
	if (IS_CURVED_SURFACE(surfId))
	{
		DRIVER2_CURVE* c = GET_CURVE(surfId);

		return (int)(((long)((c->end - c->start) & 0xfffU) * c->inside * 11) / 7);
	}

	if (IS_STRAIGHT_SURFACE(surfId))
		return (int)Driver2StraightsPtr[surfId].length;

	return 0;
}

static int AntFarmRoadHeading(int surfId)
{
	if (IS_CURVED_SURFACE(surfId))
		return GET_CURVE(surfId)->start & 0xfff;

	if (IS_STRAIGHT_SURFACE(surfId))
		return Driver2StraightsPtr[surfId].angle & 0xfff;

	return 0;
}

/* sample a point ON a road surface at a lane + distance along it, and the
 * traffic heading for that lane. x/z come out in WORLD space (positive-up);
 * the heading is 0..4095. */
static int AntFarmShotRoadPoint(int surfId, int distAlong, int laneNo,
	int* x, int* z, int* heading)
{
	DRIVER2_ROAD_INFO ri;
	DRIVER2_STRAIGHT* straight;
	DRIVER2_CURVE* curve;
	int dirBit;

	if (surfId < 0 || GetSurfaceRoadInfo(&ri, surfId) == 0)
		return 0;

	straight = ri.straight;
	curve = ri.curve;

	if (straight == NULL && curve == NULL)
		return 0;	/* junctions have no centre of their own */

	/* GetNodePos() declines to write its outputs for some straight segments
	 * (angle >= 2048 with no curve), which silently left the shot anchored at
	 * the world origin — the camera then flew off toward the map centre. Seed
	 * a sentinel and treat "untouched" as a failed sample. */
	*x = 0x7fffffff;
	*z = 0x7fffffff;

	GetNodePos(straight, NULL, curve, distAlong, NULL, x, z, laneNo);

	if (*x == 0x7fffffff || *z == 0x7fffffff)
		return 0;

	/* traffic heading for the sampled lane */
	if (straight)
	{
		dirBit = ROAD_LANE_DIR(straight, laneNo);
		*heading = (dirBit != 0) ? ((straight->angle + 2048) & 0xfff) : (straight->angle & 0xfff);
	}
	else
	{
		int ang = (distAlong + curve->start) & 0xfff;
		dirBit = ROAD_LANE_DIR(curve, laneNo);
		*heading = (dirBit != 0) ? ((ang - 1024) & 0xfff) : ((ang + 1024) & 0xfff);
	}

	return 1;
}

/* resolve the shot's road reference into a RENDER-space point + heading */
static int AntFarmShotRoadRender(int distAlong, VECTOR* roadPt, int* heading)
{
	int x, z;

	if (AntFarmShotRoadPoint(s.roadSurfId, distAlong, s.roadLane, &x, &z, heading) == 0)
		return 0;

	roadPt->vx = x;
	roadPt->vy = -AntFarmMapHeight(x, z);	/* render ground = -world ground */
	roadPt->vz = z;

	return 1;
}

/* Is this straight's end a REAL junction? A junction is where this road meets
 * another one, and the engine records no surface id of its own for it: step
 * just PAST the end along the lane heading and ask which surface is there - a
 * different usable straight means the two roads meet. A boundary road end
 * opens onto nothing (GetSurfaceIndex gives no road), and a camera parked
 * there looks off the edge of the world - which is the void a junction shot
 * showed when it used one. Returns 1 and the end point + heading when it
 * really is a junction. */
static int AntFarmJunctionEnd(int roadId, int laneNo, int atFar,
	int* x, int* z, int* heading, int* outNeigh)
{
	DRIVER2_STRAIGHT* rd;
	VECTOR tip;
	int ex, ez, eh;
	int neigh;

	if (roadId < 0 || roadId >= NumDriver2Straights)
		return 0;

	rd = &Driver2StraightsPtr[roadId];

	if (!AntFarmShotRoadPoint(roadId, atFar ? (int)rd->length : 0, laneNo, &ex, &ez, &eh))
		return 0;

	tip.vx = ex + FIXEDH(RSIN(eh) * 320);
	tip.vy = 0;
	tip.vz = ez + FIXEDH(RCOS(eh) * 320);

	neigh = GetSurfaceIndex(&tip);

	/* A junction is where this straight meets ANY other driveable road - a
	 * straight OR a curve. A curve's surface id carries the 0x4000 bit, so the
	 * old `neigh >= NumDriver2Straights` test threw every curved meeting away
	 * (a straight running into a bend read as "no junction"). */
	if (neigh == roadId ||
		(!IS_STRAIGHT_SURFACE(neigh) && !IS_CURVED_SURFACE(neigh)))
		return 0;

	*x = ex;
	*z = ez;
	*heading = eh;

	if (outNeigh != NULL)
		*outNeigh = neigh;

	return 1;
}

/* keep positions inside the playable map so the camera never reaches the
 * nodraw skybox extremes at the world edge, and never dives below the
 * ground into the void (render Y is negative-up: ground = -MapHeight) */
static void AntFarmClampToWorld(VECTOR* v)
{
	int maxX = units_across_halved - 4000;
	int maxZ = units_down_halved - 4000;

	if (v->vx < -maxX)
		v->vx = -maxX;

	if (v->vx > maxX)
		v->vx = maxX;

	if (v->vz < -maxZ)
		v->vz = -maxZ;

	if (v->vz > maxZ)
		v->vz = maxZ;
}

/* Is this point uncomfortably close to the playable map's edge? The camera is
 * clamped to the world, but a shot anchored on a boundary road sits right
 * against the nodraw skybox, and pinning the player's car out there can trip
 * the game's own end-of-world handling (a mission restart). The tour should
 * stay inside the map, so far-area candidates near the edge are skipped. */
static int AntFarmNearWorldEdge(int x, int z)
{
	int maxX = units_across_halved - 9000;
	int maxZ = units_down_halved - 9000;

	return (x < -maxX || x > maxX || z < -maxZ || z > maxZ);
}

/* clamp a RENDER-space position to just above the ground (render Y is
 * negative-up: ground = -MapHeight, so 'above' = more negative) */
static void AntFarmClampAboveGround(VECTOR* v)
{
	int ground = -AntFarmMapHeight(v->vx, v->vz);

	if (v->vy > ground - 60)
		v->vy = ground - 60;
}

/* (AntFarmWorldPresent used to live here. It probed MapHeight() in a ring and
 * treated 0 as "not loaded" — but AntFarmMapHeight() maps 0 to a 200 fallback,
 * so the test could never fire. The region-residency gate above is the real
 * signal, so it was removed rather than left as a no-op.) */

/* the region index ControlMap computes for a world position */
/* Is the level's map geometry loaded? On PC the cell and region sizes live in
 * the LEVEL header (MAP_CELL_SIZE is cell_header.cell_size), so they are ZERO
 * until a level has loaded - and the frontend runs with an empty header. Every
 * bit of map maths below divides by them. */
static int AntFarmMapReady(void)
{
	/* the level-header guard is shared (jer_map.h) - it is the same divide-by-zero
	 * trap for every module */
	return jer_map_ready();
}

static int AntFarmRegionOfAt(const VECTOR* pos, int line)
{
	/* Guard the division: without a level header this is a divide-by-zero,
	 * which is exactly how the screensaver crashed on a normal start (it is
	 * only entered from the command line with -level in the headless harness,
	 * which is why it went unnoticed). Region 0 is returned as "no idea". */
	if (!AntFarmMapReady())
	{
		static int warned;

		if (!warned)
		{
			warned = 1;
			s.ctx->jer_log(s.ctx,
				"[antfarm] map not loaded (antfarm.c:%d) - refusing map maths\n", line);
		}

		return 0;
	}

	/* the cell/region maths and the level-header guard now live in the shared
	 * jer_map helper (JERICHO/docs/map-streaming.md); this is the same call the
	 * arena module uses for its spawns */
	return jer_map_region_of(pos->vx, pos->vz);
}

/* call sites pass their line so the "map not loaded" warning can name them */
#define AntFarmRegionOf(pos) AntFarmRegionOfAt((pos), __LINE__)

/* Is this region number currently resident? The engine keeps FOUR unpacked
 * regions, indexed by BARREL slot — (region_x & 1) + (region_z & 1) * 2 —
 * each holding the region number loaded into it (-1 for none); see
 * map.c:294-303 and spool.c:1653. The old gate treated regions_unpacked[] as
 * a per-region map and indexed it with an absolute region number, so it read
 * far out of bounds and never actually failed: the camera was faded in over
 * geometry that had not streamed — the skybox/nodraw void. */
static int AntFarmRegionUnpacked(int region)
{
	/* the barrel is (region_x & 1) + (region_z & 1) * 2, NOT the region number -
	 * the shared jer_map helper carries that (JERICHO/docs/map-streaming.md) */
	return jer_map_region_resident(region);
}

/* Is the shot's own region ready to draw from? The engine only ever keeps
 * FOUR regions resident (regions_unpacked[4] / loading_region[4] /
 * PVS_Buffers[4] — a 2x2 barrel window), so the old "centre + 4 cardinal
 * neighbours" test could NEVER be satisfied: every cut burned its stream
 * retries and then the black cap before forcing a fallback, which is why the
 * screensaver sat on black/grey and the shot never actually moved. The
 * achievable test is: this region has data, and it is the region currently
 * unpacked into its barrel slot. */
static int AntFarmRegionsReady(int centerRegion)
{
	int totalRegions = regions_across * regions_down;

	if (centerRegion < 0 || centerRegion >= totalRegions)
		return 0;

	if (spoolinfo_offsets[centerRegion] == 0xffff)
		return 0;		/* no data here at all — re-pick instead */

	return AntFarmRegionUnpacked(centerRegion);
}

/* does this region have spool data at all? (0xffff = none — approaching it
 * would show a void forever) */
static int AntFarmRegionHasData(int region)
{
	return jer_map_region_has_data(region);
}

/* Can a shot be set up here at all? That is a question about DATA, not about
 * residency: the engine can only be made to stream a region by pointing the
 * spool at it, so a picker that demanded the destination already be resident
 * could never move anywhere (it fell back to the camera's own position, which
 * is why the tour stayed parked in one spot). Residency is waited for
 * separately, in the CUT state. */
static int AntFarmPositionHasData(const VECTOR* pos)
{
	return AntFarmRegionHasData(AntFarmRegionOf(pos));
}

/* Seed the very first takeover frame from the NEAREST usable straight to the
 * camera, so the moment the screensaver engages it sits on loaded ground
 * rather than a bare spawn point. This is only an initial position for
 * camPos/spool: the first CUT plans its shot like every other cut (a far area
 * picked by interest), so the tour is not anchored to the player. */
static void AntFarmPickNearArea(void)
{
	int bestIdx = -1;
	long long bestD2 = -1;
	int i;

	for (i = 0; i < NumDriver2Straights; i++)
	{
		DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[i];
		long long dx, dz, d2;

		if (rd->length <= 400)
			continue;

		dx = (long long)rd->Midx - camera_position.vx;
		dz = (long long)rd->Midz - camera_position.vz;
		d2 = dx * dx + dz * dz;

		if (bestD2 < 0 || d2 < bestD2)
		{
			bestD2 = d2;
			bestIdx = i;
		}
	}

	if (bestIdx < 0)
		return;

	s.areaPos.vx = Driver2StraightsPtr[bestIdx].Midx;
	s.areaPos.vy = AntFarmMapHeight(s.areaPos.vx, s.areaPos.vz);
	s.areaPos.vz = Driver2StraightsPtr[bestIdx].Midz;
	AntFarmClampToWorld(&s.areaPos);
}

/* pick a road – preferably in a different region, and ensure the region is loaded.
 * If no loaded region can be found, fallback to the current camera position (which is definitely loaded). */
/* how many civilian cars are actually moving near a point - a liveliness
 * signal the picker can score on (the engine exposes no landmark table) */
static int AntFarmTrafficNear(const VECTOR* pos, int radius)
{
	int i, n = 0;
	long long r2 = (long long)radius * radius;

	for (i = 0; i < MAX_CARS; i++)
	{
		CAR_DATA* cp = &car_data[i];
		long long dx, dz;

		if (cp->controlType != CONTROL_TYPE_CIV_AI)
			continue;

		if (ABS(cp->hd.speed) <= 8)
			continue;

		dx = (long long)cp->hd.where.t[0] - pos->vx;
		dz = (long long)cp->hd.where.t[2] - pos->vz;

		if (dx * dx + dz * dz <= r2)
			n++;
	}

	return n;
}

/* ------------------------------------------------------------------ */
/* the region block around a point (world pre-seed)                   */
/* ------------------------------------------------------------------ */
/* The engine keeps only FOUR regions resident - a 2x2 parity barrel,
 * regions_unpacked[4] - and, driving normally, fills the three neighbour slots
 * itself as you approach a region edge (map.c CheckUnpackNewRegions). A far hop
 * forces in ONLY the region under the destination, so the other three barrels
 * still hold the PREVIOUS shot's regions: the new area is a small island of
 * loaded geometry in a void. That is what "the world is empty when it loads into
 * a new region" looks like.
 *
 * These helpers fill the destination's own block the way the engine would have
 * left it: the region under the point, its x-neighbour, its z-neighbour and the
 * matching diagonal, each on the side of the region the point sits nearest (the
 * direction its view reaches furthest). Every one of the four lands in its own
 * parity barrel - (rx & 1) + (rz & 1) * 2, which flips on exactly one axis per
 * neighbour - so forcing one never evicts another the block needs. */

static int AntFarmRegionBarrel(int region)
{
	int rx = region % regions_across;
	int rz = region / regions_across;

	return (rx & 1) + (rz & 1) * 2;
}

/* The four regions a camera at `pos` needs resident, as region numbers (-1 for a
 * slot that is off the map). Returns how many were written.
 *
 * The side picked per axis MIRRORS the engine's own neighbour rule
 * (map.c CheckUnpackNewRegions: a neighbour is enqueued when the cell within the
 * region is inside `force_load_boundary` of that edge, 18 with no lead car, else
 * 13). Matching it matters: if antfarm picked the opposite neighbour it would
 * fight the engine, which would reload its side every frame and evict antfarm's
 * - a region load per frame for the whole cut. */
static int AntFarmBlockAround(const VECTOR* pos, int out[4])
{
	int region = AntFarmRegionOf(pos);
	int rx, rz, xcell, zcell, sx, sz, nx, nz, boundary;

	if (!AntFarmMapReady() || region < 0 || region >= regions_across * regions_down)
		return 0;

	rx = region % regions_across;
	rz = region / regions_across;

	/* same boundary the engine uses to decide when to pre-load a neighbour */
	boundary = (lead_car == 0) ? 18 : 13;

	/* which side of the region the point is nearest: that is the direction its
	 * view reaches furthest, so that is the neighbour worth keeping loaded */
	xcell = (pos->vx + units_across_halved) / MAP_CELL_SIZE - rx * MAP_REGION_SIZE;
	zcell = (pos->vz + units_down_halved) / MAP_CELL_SIZE - rz * MAP_REGION_SIZE;
	sx = (xcell < boundary) ? -1 : 1;
	sz = (zcell < boundary) ? -1 : 1;

	nx = rx + sx;
	nz = rz + sz;

	out[0] = region;
	out[1] = (nx >= 0 && nx < regions_across) ? region + sx : -1;
	out[2] = (nz >= 0 && nz < regions_down) ? region + sz * regions_across : -1;
	out[3] = (nx >= 0 && nx < regions_across && nz >= 0 && nz < regions_down)
		? region + sx + sz * regions_across : -1;

	return 4;
}

/* how many of the block's regions have data at all - the achievable target,
 * since an off-map or data-less neighbour can never be streamed in */
static int AntFarmBlockUsable(const int* block, int n)
{
	int i, r = 0;

	for (i = 0; i < n; i++)
		if (block[i] >= 0 && AntFarmRegionHasData(block[i]))
			r++;

	return r;
}

/* how many of the block's regions are actually resident right now */
static int AntFarmBlockResident(const int* block, int n)
{
	int i, r = 0;

	for (i = 0; i < n; i++)
		if (block[i] >= 0 && AntFarmRegionHasData(block[i]) && AntFarmRegionUnpacked(block[i]))
			r++;

	return r;
}

/* Force one region into its own parity barrel, the way the engine does when it
 * streams you into a region: clear the barrel, unpack the region, flush the spool
 * (synchronous on PC, so the geometry + PVS are in by the time this returns).
 * Skips a region already in its barrel, and one that is mid-load (the engine
 * finishes it). Returns 1 if the region is resident when this returns. */
static int AntFarmForceRegion(int region)
{
	int barrel;

	if (!AntFarmMapReady() || region < 0 || region >= regions_across * regions_down)
		return 0;

	if (!AntFarmRegionHasData(region))
		return 0;		/* a void - nothing to stream in */

	barrel = AntFarmRegionBarrel(region);

	if (regions_unpacked[barrel] == region)
		return 1;		/* already the region in its barrel */

	if (loading_region[barrel] != -1)
		return 0;		/* mid-load; the engine will finish it */

	ClearRegion(barrel);
	UnpackRegion(region, barrel);
	StartSpooling();
	UpdateSpool();

	return regions_unpacked[barrel] == region;
}

/* Stream the whole block in and report how many of its regions are resident.
 * Called once per cut, during the black, so the shot opens on a loaded
 * neighbourhood instead of one island of geometry. */
static int AntFarmStreamBlock(const int* block, int n)
{
	int i;

	for (i = 0; i < n; i++)
		if (block[i] >= 0)
			AntFarmForceRegion(block[i]);

	return AntFarmBlockResident(block, n);
}

/* a world point at the centre of a region, for seeding traffic into it */
static void AntFarmRegionCentre(int region, VECTOR* out)
{
	int rx = region % regions_across;
	int rz = region / regions_across;

	out->vx = (rx * MAP_REGION_SIZE + MAP_REGION_SIZE / 2) * MAP_CELL_SIZE - units_across_halved;
	out->vz = (rz * MAP_REGION_SIZE + MAP_REGION_SIZE / 2) * MAP_CELL_SIZE - units_down_halved;
	out->vy = 0;
	AntFarmClampToWorld(out);
}

/* On a doSpooling == 0 level (an mp arena) the engine never streams: mission.c
 * sets doSpooling only for region == 0, so ControlMap is never called, only the
 * four multiplayerregions load at level start, and current_region stays -1 for
 * the whole session. The engine's own area loader, CheckLoadAreaData, indexes
 * spoolinfo_offsets[current_region] - so with -1 the shot's texture area and
 * scenery models are never loaded (and the read is out of bounds). Point it at
 * the region we are about to use. On a normal level ControlMap sets
 * current_region every frame, so this is a no-op there. */
static void AntFarmSeedCurrentRegion(void)
{
	int r = AntFarmRegionOf(&s.spool);

	if (!doSpooling && r >= 0 && r < regions_across * regions_down)
		current_region = r;
}

/* ------------------------------------------------------------------ */
/* traffic pre-seed                                                   */
/* ------------------------------------------------------------------ */
/* The engine dribbles civilians in only a few per frame, around
 * MainPlayer.spoolXZ, so a shot that hops to a fresh area opens on an empty
 * road and a car-subject style has nothing to latch onto. This fills the area
 * at once with the engine's own spawner (PingInCivCar) - the very call the
 * game uses, so the cars are ordinary traffic, not a special case.
 *
 * It seeds the whole NEIGHBOURHOOD BLOCK, not one point: the block is what the
 * camera can see, so traffic only in the destination region still reads as an
 * empty city at the edges of the frame. The budget is split across the block's
 * usable regions and the spool is pointed at each region's centre in turn.
 *
 * "Cars do not spawn invisible": InitCar places every pinger with MapHeight(),
 * which answers 0 for a cell that is not resident - the car lands in the void
 * and is never drawn. So the whole block is streamed in first and a region that
 * is still not resident is skipped (loudly), rather than dropping a batch of
 * cars into nothing. */
static void AntFarmPreseedTraffic(int nMax)
{
	VECTOR focus;
	VECTOR* savedSpool;
	int block[4];
	int nb, usable, perRegion, k, spawned = 0, seededRegions = 0;

	if (!AntFarmMapReady())
		return;

	/* The spawner reads MainPlayer.spoolXZ; hand it the point we want the
	 * traffic around - the module's shot area while active, otherwise the
	 * player's own spool (a level start, before the first cut has picked an
	 * area). */
	if (s.active)
	{
		focus = s.spool;
	}
	else
	{
		if (MainPlayer.spoolXZ == NULL)
			return;

		focus.vx = MainPlayer.spoolXZ->vx;
		focus.vz = MainPlayer.spoolXZ->vz;
	}

	nb = AntFarmBlockAround(&focus, block);
	usable = AntFarmBlockUsable(block, nb);

	if (usable == 0)
		return;

	/* stream the whole block in before pinging into it, so no car lands on a
	 * cell that is not loaded (see the "invisible cars" note above) */
	AntFarmStreamBlock(block, nb);

	/* Free the slots a far hop leaves stranded. The engine evicts civilian
	 * traffic once it is more than 24000 units from the spool (its own ping-out
	 * in civ_ai.c), but only a few per frame - so right after a hop the slots
	 * are still full of the PREVIOUS area's cars and PingInCivCar refuses every
	 * ping, leaving the new area empty ("0 civ car(s)"). Do the same eviction at
	 * once, measured against the NEW focus, so the seed has slots to fill. Only
	 * civilian cars are touched; the pinned player car is CONTROL_TYPE_NONE. */
	{
		long long stray2 = 24000LL * 24000LL;
		int i;

		for (i = 0; i < MAX_CARS; i++)
		{
			CAR_DATA* cp = &car_data[i];
			long long dx, dz;

			if (cp->controlType != CONTROL_TYPE_CIV_AI)
				continue;

			dx = (long long)cp->hd.where.t[0] - focus.vx;
			dz = (long long)cp->hd.where.t[2] - focus.vz;

			if (dx * dx + dz * dz > stray2)
				PingOutCar(cp);
		}
	}

	savedSpool = MainPlayer.spoolXZ;

	/* ceil, so a small budget still spreads across every usable region */
	perRegion = (nMax + usable - 1) / usable;

	for (k = 0; k < nb; k++)
	{
		VECTOR seed;
		int got = 0;

		if (block[k] < 0 || !AntFarmRegionHasData(block[k]))
			continue;

		if (!AntFarmRegionUnpacked(block[k]))
		{
			s.ctx->jer_log(s.ctx,
				"[antfarm] pre-seed: region %d not resident (cars would spawn invisible)\n",
				block[k]);
			continue;
		}

		AntFarmRegionCentre(block[k], &seed);
		MainPlayer.spoolXZ = &seed;

		while (got < perRegion)
		{
			if (PingInCivCar(15900) == 0)
				break;		/* no free slot / no valid lane this ping */

			got++;
		}

		spawned += got;
		seededRegions++;
	}

	MainPlayer.spoolXZ = savedSpool;

	s.ctx->jer_log(s.ctx,
		"[antfarm] pre-seed: %d civ car(s) across %d/%d region(s) around (%d,%d)\n",
		spawned, seededRegions, usable, focus.vx, focus.vz);
}

/* ------------------------------------------------------------------ */
/* points of interest (SCAFFOLD - inert until the coordinates are filled) */
/* ------------------------------------------------------------------ */
/* The engine has no landmark table, which is exactly why shots are picked by
 * FEATURE (water beside a road, length, traffic) rather than by name. This is
 * the hook for the real thing: a per-city list of named places with a world
 * position and a framing radius, so a shot can one day frame the Loop or the
 * Malecon on purpose.
 *
 * Nothing here does anything yet, and that is deliberate: every entry has
 * valid = 0, so AntFarmPoiNear() always returns -1 and the interest scorer is
 * unaffected. To fill a row: load the city, drive to the landmark and read the
 * position (or take it from a map capture), set .x/.z, then set .valid = 1 -
 * that alone starts biasing shot selection toward it.
 */
typedef struct ANTFARM_POI
{
	const char* name;	/* landmark name */
	int x, z;		/* its world position */
	int radius;		/* how near a road must be to count */
	int valid;		/* 0 = coordinates not filled in yet */
} ANTFARM_POI;

static const ANTFARM_POI antPois[] = {
	/* Chicago - the elevated loop, the river bridges, Michigan Avenue */
	{ "The Loop (elevated)",      0, 0, 4000, 0 },
	{ "River bridges",            0, 0, 3000, 0 },
	{ "Michigan Avenue",          0, 0, 4000, 0 },
	/* Havana - the Malecon sea wall and the colonial old town */
	{ "Malecon sea front",        0, 0, 5000, 0 },
	{ "Old town (Habana Vieja)",  0, 0, 3000, 0 },
	/* Las Vegas - the Strip and its neon frontage */
	{ "The Strip",                0, 0, 6000, 0 },
	/* Rio - the beaches and the Sugarloaf */
	{ "Copacabana beach",         0, 0, 5000, 0 },
	{ "Sugarloaf (Pao de Acucar)", 0, 0, 4000, 0 },
};

/* Nearest valid point of interest to a position, or -1 (which is every call
 * today, since no row has valid = 1). */
static int AntFarmPoiNear(int x, int z)
{
	int i, best = -1;
	long long bestD2 = -1;

	for (i = 0; i < (int)(sizeof(antPois) / sizeof(antPois[0])); i++)
	{
		long long dx, dz, d2, radius2;

		if (!antPois[i].valid)
			continue;

		dx = (long long)x - antPois[i].x;
		dz = (long long)z - antPois[i].z;
		d2 = dx * dx + dz * dz;

		radius2 = (long long)antPois[i].radius * antPois[i].radius;

		if (d2 > radius2)
			continue;

		if (bestD2 < 0 || d2 < bestD2)
		{
			bestD2 = d2;
			best = i;
		}
	}

	return best;
}

/* How interesting is this road as a shot subject? Scored only from signals the
 * engine's data really offers - there is no per-level landmark or POI table,
 * and no junction surface id - so: water beside the road, sheer length, and
 * traffic actually moving there. */
static int AntFarmRoadInterest(int idx, const VECTOR* pos)
{
	DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[idx];
	int score = 0;
	int traffic;

	if (rd->length > 2600)
		score += 26;
	else if (rd->length > 1500)
		score += 14;

	if (AntFarmRoadNearWater(rd))
		score += 45;

	traffic = AntFarmTrafficNear(pos, 6000);
	if (traffic > 6)
		traffic = 6;

	score += traffic * 6;

	/* the POI scaffold: inert today (every row has valid = 0, so this is
	 * always -1), but it is wired up so filling in a landmark's coordinates
	 * is the only change needed to start framing it */
	if (AntFarmPoiNear(pos->vx, pos->vz) >= 0)
		score += 40;

	return score;
}

static int AntFarmPickFarArea(void)
{
	/* The cache must be current HERE, not only later when a shot is planned:
	 * at the FIRST activation it is still the empty one built at boot (before
	 * any level had loaded), so this function would take its "no usable roads"
	 * fallback and anchor the first cut on the camera position - which, on an
	 * auto-enable at level load, is still (0,0) because the camera has not
	 * been placed yet. That is the arbitrary first area the tour used to open
	 * on. */
	AntFarmEnsureRoadCache();

	if (g_numUsableRoads == 0) {
		/* No usable roads at all – fallback to camera position (which is loaded) */
		s.areaPos.vx = camera_position.vx;
		s.areaPos.vz = camera_position.vz;
		s.areaPos.vy = AntFarmMapHeight(s.areaPos.vx, s.areaPos.vz);
		AntFarmClampToWorld(&s.areaPos);
		return 1;
	}

	int curRegion = AntFarmRegionOf(&s.targetPos);

	/* Sample a handful of candidates and take the most interesting one, with a
	 * penalty for staying in the region we are already in: the tour has to
	 * move, and a long waterfront straight with traffic on it beats a random
	 * back street that happens to come up first. */
	{
		int best = -1, bestScore = -1, attempt;

		for (attempt = 0; attempt < 14; attempt++) {
			int idx = g_usableRoads[AntRand() % g_numUsableRoads];
			DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[idx];
			VECTOR pos;
			int score;

			if (rd->length < 200)
				continue;   /* skip very short ones */

			pos.vx = rd->Midx;
			pos.vy = AntFarmMapHeight(rd->Midx, rd->Midz);
			pos.vz = rd->Midz;
			AntFarmClampToWorld(&pos);

			/* stay off the world edge: a shot (and the pinned car) at a boundary
			 * road sits against the nodraw skybox */
			if (AntFarmNearWorldEdge(pos.vx, pos.vz))
				continue;

			/* the destination must have data — residency comes later */
			if (!AntFarmPositionHasData(&pos))
				continue;

			score = AntFarmRoadInterest(idx, &pos);

			if (AntFarmRegionOf(&pos) == curRegion)
				score -= 20;

			if (score > bestScore) {
				bestScore = score;
				best = idx;
				s.areaPos = pos;
			}
		}

		if (best >= 0)
			return 1;
	}

	/* Fallback: try any usable road that is loaded, even if same region */
	for (int attempt = 0; attempt < 30; attempt++) {
		int idx = g_usableRoads[AntRand() % g_numUsableRoads];
		DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[idx];
		if (rd->length < 200) continue;
		VECTOR pos;
		pos.vx = rd->Midx;
		pos.vy = AntFarmMapHeight(rd->Midx, rd->Midz);
		pos.vz = rd->Midz;
		AntFarmClampToWorld(&pos);
		if (AntFarmNearWorldEdge(pos.vx, pos.vz)) continue;
		if (AntFarmPositionHasData(&pos)) {
			s.areaPos = pos;
			return 1;
		}
	}

	/* Ultimate fallback: use current camera position (loaded) */
	s.areaPos.vx = camera_position.vx;
	s.areaPos.vz = camera_position.vz;
	s.areaPos.vy = AntFarmMapHeight(s.areaPos.vx, s.areaPos.vz);
	AntFarmClampToWorld(&s.areaPos);
	return 1;
}

/* pick a moving civilian car near a point (world units), or -1 */
/* has this car been the subject in the last few cuts? */
static int AntFarmCarRecent(int carId)
{
	int i;

	for (i = 0; i < s.recentCarCount; i++)
		if (s.recentCars[i] == carId)
			return 1;

	return 0;
}

static void AntFarmRememberCar(int carId)
{
	int i;

	if (carId < 0)
		return;

	for (i = ANTFARM_STYLE_MEMORY - 1; i > 0; i--)
		s.recentCars[i] = s.recentCars[i - 1];

	s.recentCars[0] = carId;

	if (s.recentCarCount < ANTFARM_STYLE_MEMORY)
		s.recentCarCount++;
}

/* How fast a car must be going for a given style to accept it: a rig or a
 * long-lens vantage needs a car genuinely underway, anything else is happy
 * with one merely moving. */
static int AntFarmModelMinSpeed(int style)
{
	int model = antStyleDefs[style].model;

	return (model == ANT_MODEL_ATTACH || model == ANT_MODEL_TRIPODZ) ? 40 : 8;
}

/* Pick a moving civilian car near the area. `radius` <= 0 means anywhere on the
 * map. A car framed in the last few cuts is heavily de-weighted so the same
 * sedan is not followed all session. */
static int AntFarmPickCarNear(const VECTOR* area, int radius, int minSpeed)
{
	int i, n = 0, pick = -1;
	long long r2 = (radius > 0) ? (long long)radius * radius : 0;

	for (i = 0; i < MAX_CARS; i++)
	{
		CAR_DATA* cp = &car_data[i];
		long long dx, dz;
		int weight;

		if (cp->controlType != CONTROL_TYPE_CIV_AI)
			continue;

		if (ABS(cp->hd.speed) <= minSpeed)
			continue;

		dx = (long long)cp->hd.where.t[0] - area->vx;
		dz = (long long)cp->hd.where.t[2] - area->vz;

		if (radius > 0 && dx * dx + dz * dz > r2)
			continue;

		weight = AntFarmCarRecent(i) ? 1 : 6;
		n += weight;

		if (AntRand() % n < weight)
			pick = i;
	}

	return pick;
}

/* Aim the shot at a car: put the area on the car so the cut streams where it
 * actually is, and remember it so the next cuts do not repeat it. */
static void AntFarmSetCarSubject(int carId)
{
	s.targetCarId = carId;

	s.areaPos.vx = car_data[carId].hd.where.t[0];
	s.areaPos.vz = car_data[carId].hd.where.t[2];
	s.areaPos.vy = AntFarmMapHeight(s.areaPos.vx, s.areaPos.vz);
	AntFarmClampToWorld(&s.areaPos);

	s.spool = s.areaPos;
	s.targetPos = s.areaPos;

	AntFarmRememberCar(carId);
}

/* vehicle length/height for framing (colBox half-lengths, may be halved in
 * place by FixCarCos — read at runtime) */
static int AntFarmCarSize(CAR_DATA* cp)
{
	if (cp->ap.carCos)
		return cp->ap.carCos->colBox.vz;

	return 300;
}

/* has this style been picked in the last few cuts? */
static int AntFarmStyleRecent(int style)
{
	int i;

	for (i = 0; i < s.recentCount; i++)
		if (s.recentStyles[i] == style)
			return 1;

	return 0;
}

static void AntFarmRememberStyle(int style)
{
	int i;

	for (i = ANTFARM_STYLE_MEMORY - 1; i > 0; i--)
		s.recentStyles[i] = s.recentStyles[i - 1];

	s.recentStyles[0] = style;

	if (s.recentCount < ANTFARM_STYLE_MEMORY)
		s.recentCount++;
}

/* Weighted style pick with a director's memory: a style seen in the last
 * few cuts is heavily de-weighted (not forbidden, or a two-style config
 * could stall). carOnly: 1 = car-capable only, 0 = road-capable only,
 * -1 = any. Overhead/Orbit fit both. */
static int AntFarmPickStyle(int carOnly)
{
	int total = 0, i, roll;
	int weight[ANTFARM_STYLE_COUNT];

	for (i = 0; i < ANTFARM_STYLE_COUNT; i++)
	{
		const ANT_STYLE_DEF* d = &antStyleDefs[i];

		weight[i] = 0;

		if (!s.stylesEnabled[i])
			continue;

		if (!AntFarmStyleImplemented(d->model))
			continue;

		if (carOnly == 1 && d->roadOnly)
			continue;

		if (carOnly == 0 && d->carFirst)
			continue;

		weight[i] = d->weight;

		if (AntFarmStyleRecent(i))
			weight[i] /= 8;

		if (weight[i] < 1)
			weight[i] = 1;

		total += weight[i];
	}

	if (total <= 0)
	{
		/* nothing matched what was asked for: fall back to any style the user
		 * actually has enabled (and whose camera exists) rather than a
		 * hard-coded one that may be switched off */
		for (i = 0; i < ANTFARM_STYLE_COUNT; i++)
		{
			if (s.stylesEnabled[i] && AntFarmStyleImplemented(antStyleDefs[i].model))
				return i;
		}

		return ANTFARM_STYLE_TRIPOD;
	}

	roll = AntRand() % total;

	for (i = 0; i < ANTFARM_STYLE_COUNT; i++)
	{
		if (weight[i] <= 0)
			continue;

		roll -= weight[i];

		if (roll < 0)
			return i;
	}

	return ANTFARM_STYLE_TRIPOD;
}

/* randomize the framing of a freshly picked shot so no two cuts look alike */
static void AntFarmInitShotVars(void)
{
	/* Which side of the road/target the camera sits on. A plain coin flip
	 * STREAKS - several shots in a row on the same flank is exactly what reads
	 * as "the camera is always on the right" - so alternate by default and keep
	 * roughly a quarter of the shots on the same side for variety. Every model
	 * that uses it (the attached rigs, the tripod vantages, the roadside and
	 * junction placements) is symmetric about the target, so both flanks are
	 * equally available. */
	if (s.lastSideSign == 0)
		s.shotSideSign = (AntRand() & 1) ? 1 : -1;
	else
		s.shotSideSign = AntRandChance(25) ? s.lastSideSign : -s.lastSideSign;

	s.lastSideSign = s.shotSideSign;
	s.shotMargin = AntRandRange(180, 360);		/* clear of the kerb */
	s.shotLookAhead = AntRandRange(800, 1100);	/* stable look-ahead */
	s.shotOrbitAmp = 0;
	s.trailSet = 0;			/* the trail cam re-seeds on the car's heading */
	s.shotOrbitPhase = AntRand() & 4095;

	{
		const ANT_STYLE_DEF* d = &antStyleDefs[s.style];

		s.shotHeight = AntRandRange(d->heightLo, d->heightHi);
		s.shotFwd = AntRandRange(d->fwdLo, d->fwdHi);
		s.shotSide = AntRandRange(d->sideLo, d->sideHi);

		if (d->zoom)
		{
			/* a zoom row sits at one end of its lens range and pushes to the
			 * other and back across the shot (see AntFarmFovTarget) */
			s.shotScrZ = d->scrZLo;
			s.shotZoomTo = d->scrZHi;
		}
		else
		{
			s.shotScrZ = AntRandRange(d->scrZLo, d->scrZHi);
			s.shotZoomTo = s.shotScrZ;
		}

		/* some rows slowly pan; the rest hold still. Most road-bound rows do
		 * pan - a parked camera on an empty road is a frozen frame, and this is
		 * a screensaver. */
		if (d->orbitHi > 0 && AntRandChance(72))
			s.shotOrbitAmp = AntRandRange(d->orbitLo, d->orbitHi);

		/* the row decides how far ahead to look: a short aim watches traffic
		 * cross the lens, a long one looks down the road */
		if (d->across)
			s.shotLookAhead = AntRandRange(0, 220);
		else if (d->aimHi > 0)
			s.shotLookAhead = AntRandRange(d->aimLo, d->aimHi);
	}

	/* safety clamp: a long lens is fine, a fisheye is not. The floor is the
	 * engine's own widest lens (ANTFARM_FOV_MIN = gCameraDefaultScrZ), so a
	 * shot can never be wider than ordinary gameplay - a style row whose whole
	 * scrZ range sits below it (e.g. overhead) simply pins to the floor. */
	if (s.shotScrZ < ANTFARM_FOV_MIN)
		s.shotScrZ = ANTFARM_FOV_MIN;
	if (s.shotScrZ > ANTFARM_FOV_MAX)
		s.shotScrZ = ANTFARM_FOV_MAX;

	if (s.shotZoomTo < ANTFARM_FOV_MIN)
		s.shotZoomTo = ANTFARM_FOV_MIN;
	if (s.shotZoomTo > ANTFARM_FOV_MAX)
		s.shotZoomTo = ANTFARM_FOV_MAX;
}

/* A shot's visible time: the cut interval scaled by how interesting the
 * scene is (long vistas dwell, ephemeral traffic does not), so the pace
 * breathes instead of ticking metronome-steady. */
static int AntFarmComputeDwell(void)
{
	const ANT_STYLE_DEF* d = &antStyleDefs[s.style];
	int base = AntIntervalMs();
	int mul = d->dwell;
	int len = 0;
	int dwell;

	if (s.targetKind == ANTFARM_TARGET_ROAD &&
		s.roadSurfId >= 0 && s.roadSurfId < NumDriver2Straights)
		len = Driver2StraightsPtr[s.roadSurfId].length;

	if (len > 3000)
		mul = mul * 130 / 100;
	else if (len > 0 && len < 900)
		mul = mul * 80 / 100;

	/* a car subject is transient - do not linger on an empty frame */
	if (s.targetKind == ANTFARM_TARGET_CAR)
		mul = mul * 70 / 100;

	if (mul < ANTFARM_DWELL_MIN)
		mul = ANTFARM_DWELL_MIN;

	if (mul > ANTFARM_DWELL_MAX)
		mul = ANTFARM_DWELL_MAX;

	/* the shot's visible time, clamped to the range a shot should last: a tour
	 * that cuts every few seconds is a slideshow, and one that dwells for
	 * minutes stops being a screensaver you can leave on */
	dwell = base * mul / 100;

	/* pace trim: the director asks for shots ~15% shorter than the interest
	 * score alone suggests, so the tour changes them a little more often
	 * (ANTFARM_PACE_PCT). Applied before the clamps so the 15 s floor still
	 * protects against a short interval. */
	dwell = dwell * ANTFARM_PACE_PCT / 100;

	if (dwell < ANTFARM_SHOT_MIN_MS)
		dwell = ANTFARM_SHOT_MIN_MS;

	if (dwell > ANTFARM_SHOT_MAX_MS)
		dwell = ANTFARM_SHOT_MAX_MS;

	return dwell;
}

/* The lens target for this frame. A zoom row sits at one end of its lens range
 * and pushes to the other and back across the shot; everything else holds the
 * lens it was given. This feeds the same smoothing as the rest of the FOV
 * handling, so the movement is a slow breathe rather than a jump. */
static int AntFarmFovTarget(void)
{
	const ANT_STYLE_DEF* d = &antStyleDefs[s.style];
	unsigned long shotMs;
	unsigned long elapsed;
	int t, factor;

	if (!d->zoom || s.shotZoomTo == s.shotScrZ)
		return s.shotScrZ;

	shotMs = (unsigned long)(s.dwellMs > 0 ? s.dwellMs : AntIntervalMs());

	/* Run the push over the FIRST THIRD of the shot (bounded below so a short
	 * dwell still zooms slowly) and hold the near end afterwards. Spreading it
	 * over the whole dwell meant a shot that got cut early - common for a
	 * long-lens vantage whose subject drives off - never moved its lens at all,
	 * so the "zoom" row read as a static frame. */
	shotMs = shotMs / 3;

	if (shotMs < ANTFARM_ZOOM_MIN_MS)
		shotMs = ANTFARM_ZOOM_MIN_MS;

	elapsed = AntTicks() - s.shotStart;

	t = (elapsed >= shotMs) ? 1000 : (int)(elapsed * 1000 / shotMs);

	/* half a sine: 0 at both ends of the shot, 4096 (= 1.0) in the middle */
	factor = RSIN((t * 2048) / 1000);

	return s.shotScrZ + (int)(((long)(s.shotZoomTo - s.shotScrZ) * factor) / 4096);
}

/* ------------------------------------------------------------------ */
/* the follow (trail) cam                                             */
/* ------------------------------------------------------------------ */
/* REWRITTEN FROM SCRATCH. The old follow cam cycled between a chase-behind,
 * an overhead and a chase-front framing every few seconds and let the camera
 * lerp 12% of the way to the new framing per frame: the camera visibly jumped
 * and "switched sides" mid-shot, which read as snappy and horrible.
 *
 * The replacement is ONE continuous perspective - a damped trail cam. There is
 * no mode to switch to, so nothing can jump:
 *   - the camera trails the car on its heading, at a distance and height
 *     scaled to the car's own body (a bus and a sports car both get a camera
 *     that sits outside the panels),
 *   - the yaw follows the car through a SLOW, short-way-round slew, so a turn
 *     draws the camera around the corner instead of whipping it,
 *   - roll and pitch are never inherited: the horizon stays level,
 *   - the aim sits ahead of the car, so the car rides low in frame and the
 *     road reads beyond it.
 * Speeds grow the trail distance a little, so the shot opens up at speed and
 * stays intimate in traffic. */
static void AntFarmFollowCam(CAR_DATA* cp, const VECTOR* carPos, int dir, int h,
	VECTOR* desired, VECTOR* aim, int* outLerp)
{
	const ANT_STYLE_DEF* d = &antStyleDefs[s.style];
	int vz = 300, vy = 120;
	int back, high, side, aimAhead;
	int speed = ABS(cp->hd.speed);
	int yaw;

	if (cp->ap.carCos)
	{
		vz = cp->ap.carCos->colBox.vz;
		vy = cp->ap.carCos->colBox.vy;
	}

	if (vz < 200)
		vz = 200;

	if (vy < 80)
		vy = 80;

	/* A follow row that sets its forward range opts into TABLE-DRIVEN framing:
	 * height -> camera height, fwd -> trail distance, side -> a lateral (rear
	 * 3/4) offset, aim -> how far ahead to look. A row that leaves fwd at 0
	 * (Chase cam) keeps the legacy computed trail below, unchanged. */
	if (d->fwdHi > 0)
	{
		back = s.shotFwd;
		high = s.shotHeight;
		side = s.shotSide * s.shotSideSign;
		aimAhead = (s.shotLookAhead > 0) ? s.shotLookAhead : 700;
	}
	else
	{
		/* framing: back off the tail by the body length plus a margin */
		back = vz * 2 + vy + 420;

		if (back < 700)
			back = 700;

		if (back > 1400)
			back = 1400;

		/* a little more room at speed (hd.speed is a signed fixed-ish count) */
		if (speed > 8)
		{
			back += speed * 3;

			if (back > 1900)
				back = 1900;
		}

		high = 190 + vy / 2;

		if (high > 420)
			high = 420;

		if (high < 150)
			high = 150;

		side = 0;
		aimAhead = 600 + speed * 4;
	}

	/* never put the trail cam at road level */
	if (high < 40)
		high = 40;

	/* The yaw the camera WANTS: the car's own heading (so it sits behind the
	 * car). The slow slew toward it happens in the state below, one frame at a
	 * time - that is what removes the whip. */
	yaw = dir & 0xfff;

	if (!s.trailSet)
	{
		/* seed the trail on the car's heading so the first frame is already a
		 * sensible behind-shot rather than a swing in from wherever the
		 * gameplay camera happened to be */
		int right = (yaw + 3072) & 0xfff;

		s.trailYaw = yaw;
		s.trailPos.vx = carPos->vx - FIXEDH(RSIN(yaw) * back)
			+ FIXEDH(RSIN(right) * side);
		s.trailPos.vz = carPos->vz - FIXEDH(RCOS(yaw) * back)
			+ FIXEDH(RCOS(right) * side);
		s.trailPos.vy = -(h + high);
		s.trailSet = 1;
	}

	/* --- yaw slew: at most a few hundred units of angle per frame, and
	 * always the short way round --- */
	{
		int d = (yaw + 4096 - s.trailYaw) & 0xfff;

		if (d > 2048)
			d -= 4096;

		s.trailYaw = (s.trailYaw + d / 12) & 0xfff;
	}

	/* --- position: ease toward the ideal trail point at a fixed, gentle rate
	 * (damped, not snapped) --- */
	{
		int right = (s.trailYaw + 3072) & 0xfff;
		int idealX = carPos->vx - FIXEDH(RSIN(s.trailYaw) * back)
			+ FIXEDH(RSIN(right) * side);
		int idealZ = carPos->vz - FIXEDH(RCOS(s.trailYaw) * back)
			+ FIXEDH(RCOS(right) * side);
		int idealY = -(h + high);

		s.trailPos.vx += (idealX - s.trailPos.vx) * 6 / 100;
		s.trailPos.vz += (idealZ - s.trailPos.vz) * 6 / 100;
		s.trailPos.vy += (idealY - s.trailPos.vy) * 8 / 100;
	}

	*desired = s.trailPos;

	/* aim a little ahead of the car so it sits low in frame */
	aim->vx = carPos->vx + FIXEDH(RSIN(dir) * aimAhead);
	aim->vz = carPos->vz + FIXEDH(RCOS(dir) * aimAhead);
	aim->vy = -(carPos->vy + 30);

	/* the position is already smoothed above, so the generic lerp is a no-op */
	*outLerp = 100;
}

/* A ROAD-model shot that keeps a CAR framed while the camera moves with it:
 * hold an offset in the car's own frame (longitudinal `fwd` ahead of it,
 * lateral `side` off its flank, `high` above the ground) and aim at the car, so
 * the car holds its place in frame and the city travels past. The trail cam
 * (AntFarmFollowCam) is the behind variant of the same idea; these are the
 * beside (ROADSIDE/JUNCTION) and ahead (DOLLY/CRANE) variants. */
static void AntFarmTrackCarCam(const VECTOR* carPos, int dir, int h, int fwd,
	int side, int high, VECTOR* desired, VECTOR* aim)
{
	int right = (dir + 3072) & 0xfff;

	desired->vx = carPos->vx + FIXEDH(RSIN(dir) * fwd) + FIXEDH(RSIN(right) * side);
	desired->vz = carPos->vz + FIXEDH(RCOS(dir) * fwd) + FIXEDH(RCOS(right) * side);
	desired->vy = -(h + high);

	aim->vx = carPos->vx;
	aim->vz = carPos->vz;
	aim->vy = -(carPos->vy + 40);
}

/* ------------------------------------------------------------------ */
/* shot planning (called during the black CUT)                        */
/* ------------------------------------------------------------------ */

/* point the shot's road reference at s.roadSurfId (the area road): pick a
 * lane + distance and set the spool anchor. Sampling near a straight's END
 * frames junctions (junctions have no centre of their own). */
static void AntFarmSetupRoadShot(void)
{
	const ANT_STYLE_DEF* d = &antStyleDefs[s.style];
	DRIVER2_STRAIGHT* rd;
	int nLanes;
	int len;

	AntFarmEnsureRoadCache();

	if (s.roadSurfId < 0 || s.roadSurfId >= NumDriver2Straights)
	{
		s.targetPos = s.areaPos;
		return;
	}

	rd = &Driver2StraightsPtr[s.roadSurfId];
	len = rd->length;

	nLanes = ROAD_WIDTH_IN_LANES(rd);
	s.roadLane = (nLanes > 0) ? (AntRand() % nLanes) : 0;

	if (d->model == ANT_MODEL_DOLLY || d->model == ANT_MODEL_CRANE)
	{
		/* Start at the beginning of the road: the dolly advances a little every
		 * frame and continues onto the connected road at a junction, so it
		 * never needs a run-up before the road starts. */
		s.roadDist = 0;
		s.junctionCorner = 0;
		s.shotLookAhead = 1000 + (AntRand() % 400);
	}
	else if (d->model == ANT_MODEL_JUNCTION)
	{
		int tries;

		/* A junction row must actually sit on a JUNCTION, not on a road end that
		 * opens onto nothing: stepping past a boundary road end finds no
		 * neighbouring surface, and a camera (and the pinned player car) parked
		 * there looks off the edge of the world - the void a junction shot showed.
		 * Probe the end and take the first one that really meets another road,
		 * trying the other end and then a few other roads. */
		for (tries = 0; tries < 10; tries++)
		{
			int endAtFar = (AntRand() & 1);
			int ex, ez, eh;

			if (tries > 0)
			{
				int cand = AntFarmPickSurface(400);

				if (cand >= 0 && cand < NumDriver2Straights &&
					!AntFarmNearWorldEdge(Driver2StraightsPtr[cand].Midx,
						Driver2StraightsPtr[cand].Midz))
				{
					s.roadSurfId = cand;
					len = Driver2StraightsPtr[cand].length;
				}
			}

			int jnNeigh = -1;

			if (AntFarmJunctionEnd(s.roadSurfId, s.roadLane, endAtFar, &ex, &ez, &eh,
				&jnNeigh))
			{
				s.roadDist = endAtFar ? len : 0;
				s.junctionCorner = endAtFar ? 1 : 0;

				s.ctx->jer_log(s.ctx,
					"[antfarm] junction shot: road %d %s end %d,%d -> %s junction found\n",
					s.roadSurfId, endAtFar ? "far" : "near", ex, ez,
					IS_CURVED_SURFACE(jnNeigh) ? "curve" : "straight");
				break;
			}

			if (tries == 9)
			{
				/* no crossroads found nearby: watch a road end anyway, but say so */
				s.roadDist = endAtFar ? len : 0;
				s.junctionCorner = endAtFar ? 1 : 0;
				s.ctx->jer_log(s.ctx,
					"[antfarm] junction shot: no junction found near road %d, using its end\n",
					s.roadSurfId);
			}
		}
	}
	else if (AntRandChance(40))
	{
		/* roadside: sometimes frame a road END, where junctions cluster */
		int endShot = (AntRand() & 1) ? 1 : -1;	/* 1 far end, -1 near end */

		s.roadDist = (endShot > 0) ? (len - 300 - (AntRand() % 500))
			: (300 + (AntRand() % 500));

		if (AntRandChance(45))
		{
			s.roadDist = (endShot > 0) ? (len + 260 + (AntRand() % 320))
				: (-260 - (AntRand() % 320));
			s.junctionCorner = 1;
		}
		else
		{
			s.junctionCorner = 0;
		}
	}
	else
	{
		s.roadDist = len / 2 + (AntRand() % (len / 4)) - len / 8;
		s.junctionCorner = 0;
	}

	/* corner shots may sit just past either end of the road */
	if (s.roadDist < -150)
		s.roadDist = -150;

	if (s.roadDist > len + 150)
		s.roadDist = len + 150;

	{
		int x, z, heading;

		if (AntFarmShotRoadPoint(s.roadSurfId, s.roadDist, s.roadLane, &x, &z, &heading))
		{
			s.targetPos.vx = x;
			s.targetPos.vy = AntFarmMapHeight(x, z);
			s.targetPos.vz = z;
		}
		else
		{
			s.targetPos = s.areaPos;
		}
	}
}

/* Helper to pick style and target kind */
static void AntFarmPickStyleAndTarget(void)
{
	s.style = AntFarmPickStyle(-1);
	AntFarmRememberStyle(s.style);

	if (antStyleDefs[s.style].carFirst) {
		s.targetKind = ANTFARM_TARGET_CAR;
	}
	else if (!antStyleDefs[s.style].roadOnly) {
		/* overhead/orbit can watch either */
		s.targetKind = (AntRand() & 1) ? ANTFARM_TARGET_CAR : ANTFARM_TARGET_ROAD;
	}
	else {
		s.targetKind = ANTFARM_TARGET_ROAD;
	}
}

/* Plan the shot: for road targets, pick a road near the area and set up the shot.
 * For car targets, just mark it – the car will be picked later. */
static void AntFarmPlanShot(void)
{
	s.targetCarId = -1;

	AntFarmEnsureRoadCache();

	if (s.targetKind == ANTFARM_TARGET_ROAD) {
		int idx = -1;

		/* a waterfront row asks for a road that really runs beside water */
		if (antStyleDefs[s.style].nearWater)
			idx = AntFarmPickWaterRoad(s.areaPos.vx, s.areaPos.vz);

		if (idx < 0)
			idx = AntFarmPickRoadNear(s.areaPos.vx, s.areaPos.vz);

		if (idx >= 0) {
			if ((antStyleDefs[s.style].model == ANT_MODEL_DOLLY ||
				antStyleDefs[s.style].model == ANT_MODEL_CRANE) &&
				Driver2StraightsPtr[idx].length < 1600) {
				int better = AntFarmPickSurface(1600);
				if (better >= 0) idx = better;
			}
			s.roadSurfId = idx;
			AntFarmSetupRoadShot();
		}
		else {
			/* no road found - fall back to a safe hover above areaPos */
			s.roadSurfId = -1;
			s.targetPos = s.areaPos;
		}
	}
	else {
		s.targetPos = s.areaPos;
	}
	AntFarmInitShotVars();
}

/* ------------------------------------------------------------------ */
/* adopt the engine's debug -seed so a run is reproducible when asked */
static int AntFarmOnGameStart(void* userdata, void* args)
{
	JER_ARGS_GAME_START* a = (JER_ARGS_GAME_START*)args;

	(void)userdata;

	if (a != NULL && a->seed != 0)
		AntFarmSetRunSeed((unsigned int)a->seed);

	/* A level (re)start invalidates every road/area reference the tour holds
	 * (road indices, the area, the pinned car). If the mode is running, hand
	 * back and re-engage on the NEW level instead of shooting at the old
	 * level's roads - which is exactly what broke the camera when a level was
	 * restarted from the pause menu. */
	if (s.active)
	{
		/* The level is being rebuilt, so MainPlayer.playerCarId may already point
		 * at a different car. Forget the saved car slot FIRST so the hand-back
		 * cannot write the old level's car state into the new one; every other
		 * global is restored normally and the mode re-engages on the new level. */
		s.savedPlayerCarControlType = 0;
		AntFarmSuspend();
	}

	/* Pre-seed the new level's traffic at once (when the screensaver is wanted),
	 * so the world is already alive and a car-subject shot has something to
	 * frame. Skipped when the mode is off, and skipped in a live mp session -
	 * spawning civilian traffic there is mp's business, not ours. */
	if (!jer_net_is_active() && (s.active || s.pendingEnable))
		AntFarmPreseedTraffic(maxCivCars);

	return JER_RESULT_CONTINUE;
}

/* ------------------------------------------------------------------ */
/* rogue-car (lead AI) events                                         */
/* ------------------------------------------------------------------ */

static int AntFarmLeadTotaled(void)
{
	CAR_DATA* cp;

	if (s.targetCarId < 0 || s.targetCarId >= MAX_CARS)
		return 1;

	cp = &car_data[s.targetCarId];

	if (cp->controlType != CONTROL_TYPE_LEAD_AI)
		return 1;

	if (cp->totalDamage >= ANTFARM_LEAD_TOTAL)
		return 1;

	return 0;
}

/* the rogue car left the playable world (drove off the map or fell into
 * the void) — the event must end immediately, before the camera or the
 * pinned player car follow it out */
static int AntFarmLeadEscaped(void)
{
	CAR_DATA* cp;
	int maxX, maxZ;

	if (s.targetCarId < 0 || s.targetCarId >= MAX_CARS)
		return 0;

	cp = &car_data[s.targetCarId];

	maxX = units_across_halved - 3000;
	maxZ = units_down_halved - 3000;

	if (cp->hd.where.t[0] < -maxX || cp->hd.where.t[0] > maxX ||
		cp->hd.where.t[2] < -maxZ || cp->hd.where.t[2] > maxZ)
		return 1;

	if (cp->hd.where.t[1] < -6000 || cp->hd.where.t[1] > 8000)
		return 1;

	return 0;
}

static void AntFarmStartLead(void)
{
	int newSlot = -1, i;
	CAR_DATA* src = &car_data[s.targetCarId];
	LONGVECTOR4 pos;

	for (i = 0; i < MAX_CARS; i++)
	{
		if (car_data[i].controlType == CONTROL_TYPE_NONE && reservedSlots[i] == 0)
		{
			newSlot = i;
			break;
		}
	}

	if (newSlot < 0)
	{
		s.ctx->jer_log(s.ctx, "[antfarm] no free slot — rogue event skipped\n");
		return;
	}

	pos[0] = src->hd.where.t[0];
	pos[1] = src->hd.where.t[1];
	pos[2] = src->hd.where.t[2];
	pos[3] = 0;

	InitCar(&car_data[newSlot], src->hd.direction & 0xfff, &pos,
		CONTROL_TYPE_LEAD_AI, src->ap.model, src->ap.palette & 255, NULL);

	src->controlType = CONTROL_TYPE_NONE;

	s.targetCarId = newSlot;
	s.leadMode = 1;
	s.leadEnding = 0;
	s.style = ANTFARM_STYLE_CHASE;
	s.targetKind = ANTFARM_TARGET_CAR;
	AntFarmInitShotVars();

	CopsAllowed = 1;
	*GetPlayerFelony(&MainPlayer) = 2500;

	s.ctx->jer_log(s.ctx, "[antfarm] rogue car went rogue — cops engaged\n");
}

static void AntFarmEndLead(void)
{
	CopsAllowed = s.savedCopsAllowed;
	*GetPlayerFelony(&MainPlayer) = (short)s.savedPlayerFelony;

	if (s.targetCarId >= 0 && s.targetCarId < MAX_CARS)
		car_data[s.targetCarId].controlType = CONTROL_TYPE_NONE;

	s.targetCarId = -1;
	s.leadMode = 0;
	s.leadEnding = 0;

	s.ctx->jer_log(s.ctx, "[antfarm] rogue car ended — back to touring\n");
}

/* ------------------------------------------------------------------ */
/* world recovery ("get back to a road with the world loaded")        */
/* ------------------------------------------------------------------ */

/* The pretty bow. If the camera is sitting in a region that the streamer never
 * unpacked - a shot over the void, or scenery that simply is not there - do not
 * endure it: put the tour back on solid ground.
 *
 * It re-anchors on the NEAREST usable road to the camera (a road the level
 * certainly has), points the spool at it, and asks the SHARED world-spool
 * helper (jer_map_spool_to) to stream that region in by the engine's own
 * level-start path - geometry, roadmap and texture AREA, so MapHeight answers
 * properly and the scenery has its pages. Then it re-enters the ordinary CUT,
 * which plans a fresh shot from there like any other cut.
 *
 * The same helper is what forces a far hop's region in during the CUT, so there
 * is one code path for "make the map stream to here", used by this module and
 * by the arena module. */
static void AntFarmRecoverToRoad(void)
{
	unsigned long now = AntTicks();

	AntFarmPickNearArea();		/* nearest usable road to the camera -> s.areaPos */
	s.spool = s.areaPos;
	s.targetPos = s.areaPos;

	MainPlayer.spoolXZ = &s.spool;
	AntFarmSeedCurrentRegion();
	jer_map_spool_to(s.spool.vx, s.spool.vz);

	/* the block around the new anchor too, so the re-planned shot opens on a
	 * loaded neighbourhood rather than one island of geometry */
	{
		int block[4];
		int nb = AntFarmBlockAround(&s.spool, block);

		AntFarmStreamBlock(block, nb);
	}

	s.recoveries++;
	s.ctx->jer_log(s.ctx,
		"[antfarm] world recovery #%d: re-anchored on the road at %d,%d (region %d)\n",
		s.recoveries, s.spool.vx, s.spool.vz, AntFarmRegionOf(&s.spool));

	/* straight to black and re-plan - no half-faded reveal over a void */
	s.state = ANTFARM_STATE_CUT;
	s.cutInit = 0;
	s.fade = 255;
	s.stateStart = now;
	s.cutStart = now;
	s.camSnapped = 0;
	s.vantageSet = 0;
	s.trailSet = 0;
	s.stuckSince = 0;
}

/* ------------------------------------------------------------------ */
/* camera                                                             */
/* ------------------------------------------------------------------ */

/* (AntFarmStaticTrack lived here. It relocated its roadside spot whenever the
 * subject passed or drifted away, which made the shot jump between vantage
 * points - the "hysterical" camera. The Static track style is retired, so the
 * function is gone with it.) */

/* Improved camera position finder: tries to find a clear line-of-sight
 * position near the desired, using multiple candidate offsets. */
static int AntFarmFindClearCamera(const VECTOR* aim, const VECTOR* desired, VECTOR* outCam)
{
	VECTOR candidates[32];
	int numCandidates = 0;
	VECTOR delta;
	int i;

	/* compute vector from aim to desired */
	delta.vx = desired->vx - aim->vx;
	delta.vy = desired->vy - aim->vy;
	delta.vz = desired->vz - aim->vz;

	/* 1) Try the desired position itself */
	candidates[numCandidates++] = *desired;

	/* 2) Pull back fractions: 0.9, 0.8, ..., 0.1 */
	for (int frac = 9; frac >= 1; frac--) {
		VECTOR pos;
		float t = frac / 10.0f;
		pos.vx = aim->vx + (int)(delta.vx * t);
		pos.vy = aim->vy + (int)(delta.vy * t);
		pos.vz = aim->vz + (int)(delta.vz * t);
		candidates[numCandidates++] = pos;
		if (numCandidates >= 32) break;
	}

	/* 3) Rotate around aim: try different azimuth angles (0, 45, 90, ...) at 80% and 120% distance.
	 * The eight steps are fixed, so their cos/sin are built once and kept - the
	 * same expression the per-frame code used, just not recomputed every frame. */
	static float antAzim[8][2];
	static int antAzimInit = 0;

	if (!antAzimInit)
	{
		int a;

		for (a = 0; a < 8; a++)
		{
			float rad = (a * 45) * 3.14159f / 180.0f;

			antAzim[a][0] = cos(rad);
			antAzim[a][1] = sin(rad);
		}

		antAzimInit = 1;
	}

	for (int ang = 0; ang < 8; ang++) {
		float cosA = antAzim[ang][0];
		float sinA = antAzim[ang][1];
		/* rotate the delta vector around the Y axis */
		int rx = (int)(delta.vx * cosA - delta.vz * sinA);
		int rz = (int)(delta.vx * sinA + delta.vz * cosA);
		/* two distances: 0.8 and 1.2 of original */
		for (int dscale = 8; dscale <= 12; dscale += 4) {
			VECTOR pos;
			pos.vx = aim->vx + (rx * dscale) / 10;
			pos.vy = aim->vy + (delta.vy * dscale) / 10;  /* keep same vertical ratio */
			pos.vz = aim->vz + (rz * dscale) / 10;
			candidates[numCandidates++] = pos;
			if (numCandidates >= 32) break;
		}
		if (numCandidates >= 32) break;
	}

	/* 4) Try higher/lower positions */
	for (int hoff = -200; hoff <= 200; hoff += 100) {
		VECTOR pos = *desired;
		pos.vy += hoff;
		candidates[numCandidates++] = pos;
		if (numCandidates >= 32) break;
	}

	/* Now test each candidate */
	for (i = 0; i < numCandidates; i++) {
		VECTOR cam = candidates[i];
		VECTOR camWorld = cam;
		VECTOR aimWorld = *aim;
		camWorld.vy = -camWorld.vy;
		aimWorld.vy = -aimWorld.vy;

		/* Clamp above ground */
		AntFarmClampAboveGround(&cam);

		/* Check line-of-sight */
		if (lineClear(&camWorld, &aimWorld) == 0)
			continue;

		/* Additional check: ensure camera is not too low or too high */
		int ground = -AntFarmMapHeight(cam.vx, cam.vz);
		if (cam.vy > ground - 40)  /* at least 40 units above ground */
			continue;

		/* Also ensure the camera is not inside geometry by using the collider */
		CAR_DATA* jcam = &car_data[CAMERA_COLLIDER_CARID];
		ClearMem((char*)jcam, sizeof(CAR_DATA));
		jcam->controlType = CONTROL_TYPE_CAMERACOLLIDER;
		jcam->hd.direction = s.camAngle.vy & 0xfff;

		jcam->hd.where.t[0] = cam.vx;
		jcam->hd.where.t[1] = -cam.vy;
		jcam->hd.where.t[2] = cam.vz;

		jcam->hd.oBox.location.vx = cam.vx;
		jcam->hd.oBox.location.vy = -cam.vy;
		jcam->hd.oBox.location.vz = cam.vz;

		CheckScenaryCollisions(jcam);

		cam.vx = jcam->hd.where.t[0];
		cam.vy = -jcam->hd.where.t[1];
		cam.vz = jcam->hd.where.t[2];

		/* Clamp after collider */
		AntFarmClampAboveGround(&cam);

		/* Re-check LOS after collider */
		camWorld = cam;
		camWorld.vy = -camWorld.vy;
		if (lineClear(&camWorld, &aimWorld) == 0)
			continue;

		/* Valid position found */
		*outCam = cam;
		return 1;
	}

	/* Fallback: just use a position directly above the aim at a safe height */
	{
		int ground = -AntFarmMapHeight(aim->vx, aim->vz);
		outCam->vx = aim->vx;
		outCam->vz = aim->vz;
		outCam->vy = ground - 150;
		return 1;
	}
}

/* The road a travelling shot should continue onto at a junction: among the
 * roads this one connects to (ConnectIdx, the road graph the level data
 * carries - nothing else in the engine reads it), the one whose heading best
 * continues ours. -1 if there is no usable continuation. */
static int AntFarmNextRoad(int roadId, int heading)
{
	DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[roadId];
	int best = -1;
	int bestDot = -0x7fffffff;
	int i;

	for (i = 0; i < 4; i++)
	{
		int c = rd->ConnectIdx[i];
		int ang, dot;

		if (c == roadId || (!IS_STRAIGHT_SURFACE(c) && !IS_CURVED_SURFACE(c)))
			continue;

		if (AntFarmRoadLen(c) < 200)
			continue;

		ang = AntFarmRoadHeading(c);
		dot = RSIN(ang) * RSIN(heading) + RCOS(ang) * RCOS(heading);

		if (dot > bestDot)
		{
			bestDot = dot;
			best = c;
		}
	}

	/* ConnectIdx is not populated in these level files (nothing in the engine
	 * reads it), so if it gave us nothing, step just PAST this road's end and
	 * ask the engine which road is there - that is exactly how civ AI tracks
	 * its current road (cs->currentRoad = GetSurfaceIndex(...)). */
	if (best < 0)
	{
		VECTOR end = { 0, 0, 0 };
		VECTOR tip;
		int endHeading = 0;
		int surf;

		AntFarmShotRoadRender(rd->length, &end, &endHeading);

		tip.vx = end.vx + FIXEDH(RSIN(endHeading) * 200);
		tip.vy = end.vy;
		tip.vz = end.vz + FIXEDH(RCOS(endHeading) * 200);

		surf = GetSurfaceIndex(&tip);

		if (surf != roadId &&
			(IS_STRAIGHT_SURFACE(surf) || IS_CURVED_SURFACE(surf)) &&
			AntFarmRoadLen(surf) >= 200)
			best = surf;
	}

	return best;
}

/* Advance a travelling shot by this frame's share of the road, handing over to
 * the connected road when this one runs out. The old form was parameterised by
 * distance along ONE straight, so the camera parked on that road's end: the aim
 * pinned to the final point and it simply hovered there - "it only goes down
 * the road so far and cannot navigate intersections". */
static void AntFarmAdvanceDolly(unsigned long now)
{
	int len = AntFarmRoadLen(s.roadSurfId);
	unsigned long shotMs = (unsigned long)(s.dwellMs > 0 ? s.dwellMs : AntIntervalMs());
	unsigned long dt = now - s.lastDollyMs;
	long long advance;

	s.lastDollyMs = now;

	if (dt > 250)		/* a hitch must not teleport the camera */
		dt = 250;

	/* Cover about a road and a half over the shot: enough to carry the dolly
	 * through a junction (so intersections are actually navigated) while
	 * keeping the pace calm. */
	advance = (long long)(len + len / 2 + 800) * (long long)dt / (long long)shotMs;
	s.roadDist += (int)advance;

	while (s.roadDist > len && s.handoffs < 8)
	{
		VECTOR tip = { 0, 0, 0 };
		int heading = 0;
		int next;

		AntFarmShotRoadRender(len, &tip, &heading);

		next = AntFarmNextRoad(s.roadSurfId, heading);

		if (next < 0)
			break;

		s.roadDist -= len;
		s.roadSurfId = next;
		s.handoffs++;
		len = AntFarmRoadLen(next);

		s.ctx->jer_log(s.ctx,
			"[antfarm] dolly continued onto the next road (%s, junction %d)\n",
			IS_CURVED_SURFACE(next) ? "curve" : "straight", s.handoffs);
	}
}

static void AntFarmComputeCamera(VECTOR* outPos, SVECTOR* outAngle)
{
	const ANT_STYLE_DEF* d = &antStyleDefs[s.style];
	VECTOR desired = { 0, 0, 0 };
	VECTOR aim = { 0, 0, 0 };
	unsigned long now = AntTicks();
	int lerp;

	if (s.targetKind == ANTFARM_TARGET_CAR)
	{
		CAR_DATA* cp = AntFarmValidCar();
		VECTOR carPos;
		int dir, h;

		if (cp == NULL)
		{
			*outPos = s.camPos;
			*outAngle = s.camAngle;
			return;
		}

		carPos.vx = cp->hd.where.t[0];
		carPos.vy = cp->hd.where.t[1];
		carPos.vz = cp->hd.where.t[2];

		dir = cp->hd.direction;
		h = AntFarmMapHeight(carPos.vx, carPos.vz);

		if (d->model == ANT_MODEL_ATTACH)
		{
			/* Rig on the car. Offsets are in the car's own frame - forward along
			 * its heading, then to its right - so the rig rides the body. Yaw
			 * only (no roll/pitch), which keeps the horizon level and the shot
			 * watchable rather than nauseating. `behind` sits a rig at the tail,
			 * and the per-shot side sign picks which flank. */
			int fwd = s.shotFwd * (d->behind ? -1 : 1);
			int side = s.shotSide * s.shotSideSign;
			int right = (dir + 3072) & 0xfff;

			/* Scale the rig to the car's own body, so a bus and a sports car
			 * both get a camera that sits just outside the panels. The nominal
			 * body is colBox.vz=300 / vx=130 (see AntFarmCarSize). */
			if (cp->ap.carCos)
			{
				int vz = cp->ap.carCos->colBox.vz;
				int vx = cp->ap.carCos->colBox.vx;
				int scale;

				if (vz < 200) vz = 200;
				if (vx < 80) vx = 80;

				scale = vz * 100 / 300;
				if (scale < 60) scale = 60;
				if (scale > 200) scale = 200;
				fwd = fwd * scale / 100;

				scale = vx * 100 / 130;
				if (scale < 60) scale = 60;
				if (scale > 220) scale = 220;
				side = side * scale / 100;
			}

			desired.vx = carPos.vx + FIXEDH(RSIN(dir) * fwd) + FIXEDH(RSIN(right) * side);
			desired.vz = carPos.vz + FIXEDH(RCOS(dir) * fwd) + FIXEDH(RCOS(right) * side);
			desired.vy = -(h + s.shotHeight);
			lerp = 100 / d->settle;

			/* look a little way ahead of the car rather than at it, so the
			 * car sits in frame and the road reads beyond it */
			aim.vx = carPos.vx + FIXEDH(RSIN(dir) * s.shotLookAhead);
			aim.vz = carPos.vz + FIXEDH(RCOS(dir) * s.shotLookAhead);
			aim.vy = -(carPos.vy + 40);
		}
		else if (d->model == ANT_MODEL_TRIPODZ)
		{
			/* A fixed vantage, set up from the car when the shot begins and then
			 * left alone: the car drives through the frame while the lens pushes
			 * in and back out (the row's zoom) and the camera just follows it in
			 * yaw. That yaw tracking is the "pan" a tripod would do. */
			if (!s.vantageSet)
			{
				int right = (dir + 3072) & 0xfff;
				int fwd = s.shotFwd;
				int side = s.shotSide * s.shotSideSign;

				s.shotVantage.vx = carPos.vx + FIXEDH(RSIN(dir) * fwd) + FIXEDH(RSIN(right) * side);
				s.shotVantage.vz = carPos.vz + FIXEDH(RCOS(dir) * fwd) + FIXEDH(RCOS(right) * side);
				s.shotVantage.vy = -AntFarmMapHeight(s.shotVantage.vx, s.shotVantage.vz)
					- s.shotHeight;
				s.vantageSet = 1;
			}

			desired = s.shotVantage;
			lerp = 100 / d->settle;

			aim = carPos;
			aim.vy = -(carPos.vy + 30);
		}
			else if (d->model == ANT_MODEL_ORBIT)
		{
			/* ORBIT around a car: same idea as the road orbit, centred on the
			 * car instead of a point on the road */
			int radius = 900 + s.shotHeight;
			int ang = (s.shotOrbitPhase + (int)(((now - s.shotStart)
				% ANTFARM_ORBIT_PERIOD_MS) * 4096 / ANTFARM_ORBIT_PERIOD_MS)) & 4095;

			desired.vx = carPos.vx + FIXEDH(RSIN(ang) * radius);
			desired.vz = carPos.vz + FIXEDH(RCOS(ang) * radius);
			desired.vy = -(h + s.shotHeight);
			lerp = 100 / d->settle;

			aim = carPos;
			aim.vy = -(carPos.vy + 50);
		}
		else if (d->model == ANT_MODEL_ROADSIDE || d->model == ANT_MODEL_JUNCTION)
		{
			/* A road vantage that keeps a CAR framed: hold a lateral offset off
			 * the car's flank (clear of its body) at the row's height and aim at
			 * the car, so the camera travels alongside it and the car holds its
			 * place in frame while the city moves past. */
			int side = (s.shotSide + s.shotMargin) * s.shotSideSign;

			AntFarmTrackCarCam(&carPos, dir, h, 0, side, s.shotHeight,
				&desired, &aim);
			lerp = 100 / d->settle;
		}
		else if (d->model == ANT_MODEL_DOLLY || d->model == ANT_MODEL_CRANE)
		{
			/* A travelling shot that keeps a CAR framed: run the camera AHEAD of
			 * the car at the row's height and aim back at it, so the car drives
			 * toward the lens (a leading shot). */
			int fwd = ANTFARM_TRACK_LEAD + s.shotFwd;

			AntFarmTrackCarCam(&carPos, dir, h, fwd, s.shotSide * s.shotSideSign,
				s.shotHeight, &desired, &aim);
			lerp = 100 / d->settle;
		}
		else
		{
			/* FOLLOW: the damped trail cam (see AntFarmFollowCam). It smooths
			 * its own position, so the generic per-frame lerp is disabled for
			 * it (outLerp = 100) - no double smoothing, no snap. */
			AntFarmFollowCam(cp, &carPos, dir, h, &desired, &aim, &lerp);
		}

		s.spool = carPos;
		s.targetPos = carPos;
	}
	else	/* ANTFARM_TARGET_ROAD */
	{
		VECTOR roadPt = { 0, 0, 0 };
		int heading = 0;

		if (s.roadSurfId < 0 || s.roadSurfId >= NumDriver2Straights) {
			/* fallback: hover above areaPos */
			desired = s.areaPos;
			desired.vy = -AntFarmMapHeight(desired.vx, desired.vz) - s.shotHeight;
			aim = s.areaPos;
			aim.vy = desired.vy + 100;
			lerp = 100 / antStyleDefs[s.style].settle;
		}
		else {
			if (AntFarmShotRoadRender(s.roadDist, &roadPt, &heading) == 0)
			{
				*outPos = s.camPos;
				*outAngle = s.camAngle;
				return;
			}

			if (d->model == ANT_MODEL_ROADSIDE)
			{
				DRIVER2_STRAIGHT* rd = &Driver2StraightsPtr[s.roadSurfId];
				int count = ROAD_LANES_COUNT(rd);
				int sideShift = count * 128 - (s.roadLane * 128);
				int dirBit = ROAD_LANE_DIR(rd, s.roadLane);
				int laneSideFromC = sideShift * ((dirBit == 0) ? 1 : -1);
				int camOffFromCentre = s.shotSideSign * (count * 128 + s.shotMargin);
				int side = (heading + (s.shotSideSign > 0 ? 1024 : 3072)) & 0xfff;
				int off = camOffFromCentre - laneSideFromC;
				int sway = RSIN((now / 200) & 4095) >> 9;
				int bobY = RSIN((now / 130) & 4095) >> 10;

				/* a style with an orbit amplitude pans slowly on its fixed side;
				 * its distance from the road is the table's sideLo/Hi */
				if (s.shotOrbitAmp > 0)
				{
					int sweepPhase = (s.shotOrbitPhase + now / 100) & 4095;
					int sweep = FIXEDH(RSIN(sweepPhase) * s.shotOrbitAmp);

					side = (side + 4096 + sweep) & 0xfff;
				}

				desired.vx = roadPt.vx + FIXEDH(RSIN(side) * off) + sway;
				desired.vy = roadPt.vy - s.shotHeight + bobY;
				desired.vz = roadPt.vz + FIXEDH(RCOS(side) * off);

				int aimDist = s.junctionCorner ? (s.roadDist - s.shotLookAhead)
					: (s.roadDist + s.shotLookAhead);

				if (aimDist < 0)
					aimDist = 0;

				if (aimDist > AntFarmRoadLen(s.roadSurfId))
					aimDist = AntFarmRoadLen(s.roadSurfId);

				if (AntFarmShotRoadRender(aimDist, &aim, &heading) == 0)
				{
					aim = roadPt;
				}

				aim.vy = aim.vy - 12 - AntFarmRoadAimLift(s.shotHeight);
			}
			else if (d->model == ANT_MODEL_ORBIT)
			{
				/* slow circle around a point on the road */
				int radius = 900 + s.shotHeight;
				int ang = (s.shotOrbitPhase + (int)(((now - s.shotStart)
					% ANTFARM_ORBIT_PERIOD_MS) * 4096 / ANTFARM_ORBIT_PERIOD_MS)) & 4095;

				desired.vx = roadPt.vx + FIXEDH(RSIN(ang) * radius);
				desired.vz = roadPt.vz + FIXEDH(RCOS(ang) * radius);
				desired.vy = roadPt.vy - s.shotHeight;

				aim = roadPt;
				aim.vy = roadPt.vy - 20;
			}
			else if (d->model == ANT_MODEL_CRANE)
			{
				/* slow rise from road level, revealing the street ahead */
				VECTOR camPt = { 0, 0, 0 };
				VECTOR aimPt = { 0, 0, 0 };
				int dummyHeading = 0;
				int len, curDist, aimDist, curH, t;
				unsigned long shotMs = (unsigned long)(s.dwellMs > 0 ? s.dwellMs : AntIntervalMs());
				unsigned long shotElapsed = now - s.shotStart;

				t = (shotElapsed >= shotMs) ? 1000
					: (int)(shotElapsed * 1000 / shotMs);

				AntFarmAdvanceDolly(now);

				len = AntFarmRoadLen(s.roadSurfId);
				curDist = (s.roadDist < 0) ? 0 : (s.roadDist > len ? len : s.roadDist);

				AntFarmShotRoadRender(curDist, &camPt, &dummyHeading);
				desired.vx = camPt.vx;
				desired.vz = camPt.vz;

				curH = ANTFARM_CRANE_LOW + (s.shotHeight - ANTFARM_CRANE_LOW) * t / 1000;
				desired.vy = -AntFarmMapHeight(desired.vx, desired.vz) - curH;

				aimDist = curDist + s.shotLookAhead;
				if (aimDist > len) aimDist = len;

				AntFarmShotRoadRender(aimDist, &aimPt, &dummyHeading);
				aim = aimPt;
				aim.vy = aimPt.vy - 40 - AntFarmRoadAimLift(curH);
			}
			else if (d->model == ANT_MODEL_JUNCTION)
			{
				/* A parked vantage on a junction mouth: sit off the corner and
				 * above the traffic, and slide the AIM slowly ACROSS the mouth
				 * rather than down the lane - so cars entering and leaving the
				 * junction cross the frame. The mouth is the road END the shot was
				 * planned onto (see AntFarmSetupRoadShot); junctionCorner says which
				 * of the two ends it is. */
				VECTOR mouth = roadPt;
				int endDist = s.junctionCorner ? (int)Driver2StraightsPtr[s.roadSurfId].length : 0;
				int dummyHeading = 0;
				int side = (heading + (s.shotSideSign > 0 ? 1024 : 3072)) & 0xfff;
				int back = -(s.shotLookAhead + 350);
				int sweep = 0;

				if (AntFarmShotRoadRender(endDist, &mouth, &dummyHeading) == 0)
					mouth = roadPt;

				if (s.shotOrbitAmp > 0)
					sweep = FIXEDH(RSIN((s.shotOrbitPhase + now / 90) & 4095) * s.shotOrbitAmp);

				desired.vx = mouth.vx + FIXEDH(RSIN(side) * s.shotSide)
					+ FIXEDH(RSIN(heading) * back);
				desired.vz = mouth.vz + FIXEDH(RCOS(side) * s.shotSide)
					+ FIXEDH(RCOS(heading) * back);
				desired.vy = mouth.vy - s.shotHeight;

				aim.vx = mouth.vx + FIXEDH(RSIN((heading + 1024) & 0xfff) * sweep);
				aim.vz = mouth.vz + FIXEDH(RCOS((heading + 1024) & 0xfff) * sweep);
				aim.vy = mouth.vy - 20 - AntFarmRoadAimLift(s.shotHeight);
			}
			else	/* ANT_MODEL_DOLLY */
			{
				VECTOR camPt = { 0, 0, 0 };
				VECTOR aimPt = { 0, 0, 0 };
				int dummyHeading = 0;
				int len, curDist, aimDist;

				AntFarmAdvanceDolly(now);

				len = AntFarmRoadLen(s.roadSurfId);
				curDist = (s.roadDist < 0) ? 0 : (s.roadDist > len ? len : s.roadDist);

				AntFarmShotRoadRender(curDist, &camPt, &dummyHeading);
				desired.vx = camPt.vx;
				desired.vz = camPt.vz;
				desired.vy = -(AntFarmMapHeight(desired.vx, desired.vz)) - s.shotHeight
					+ (RSIN((now / 11) & 4095) >> 6);

				aimDist = curDist + s.shotLookAhead;
				if (aimDist > len) aimDist = len;

				AntFarmShotRoadRender(aimDist, &aimPt, &dummyHeading);
				aim = aimPt;
				aim.vy = aimPt.vy - 60 - AntFarmRoadAimLift(s.shotHeight);
			}
		}

		lerp = 100 / antStyleDefs[s.style].settle;
	}

	/* A degenerate pair (aim == camera) gives PointAtTarget no direction at
	 * all, which shows up as the view whipping to a random angle mid-shot. */
	{
		long long adx = (long long)aim.vx - desired.vx;
		long long adz = (long long)aim.vz - desired.vz;

		if (adx * adx + adz * adz < 400 * 400)
		{
			/* push the aim along the current view direction */
			aim.vx += FIXEDH(RSIN(s.camAngle.vy) * 500);
			aim.vz += FIXEDH(RCOS(s.camAngle.vy) * 500);
		}
	}

	s.aimPos = aim;
	/* Use the new clear camera finder to avoid scenery collisions. An attached
	 * rig is deliberately inches off the body, so pulling it back for
	 * line-of-sight would tear it off the car - it keeps its position and only
	 * the ground clamp applies. */
	if (d->model == ANT_MODEL_ATTACH)
	{
		AntFarmClampAboveGround(&desired);
	}
	else
	{
		VECTOR clearCam;

		if (AntFarmFindClearCamera(&aim, &desired, &clearCam))
		{
			desired = clearCam;
		}
		else
		{
			/* fallback: use desired as is, but clamped */
			AntFarmClampAboveGround(&desired);
		}
	}

	if (!s.camSnapped)
	{
		s.camPos = desired;
		s.camSnapped = 1;
	}
	else
	{
		s.camPos.vx += (desired.vx - s.camPos.vx) * lerp / 100;
		s.camPos.vy += (desired.vy - s.camPos.vy) * lerp / 100;
		s.camPos.vz += (desired.vz - s.camPos.vz) * lerp / 100;
	}

	{
		SVECTOR ang;
		PointAtTarget(&s.camPos, &aim, &ang);

		/* NOTE: the road-following models' upward pitch bias
		 * (ANTFARM_ROAD_PITCH_UP) is NOT applied here. This angle is thrown
		 * away by AntFarmOnCamera, which recomputes PointAtTarget from the
		 * clamped camera and the aim and then slews s.camAngle toward THAT -
		 * so a bias written into `ang` here never reached the screen. It now
		 * lands on the angle that is actually rendered, in AntFarmOnCamera. */
		*outPos = s.camPos;
		*outAngle = ang;
	}
}

/* ------------------------------------------------------------------ */
/* lifecycle                                                          */
/* ------------------------------------------------------------------ */

/* Hand the engine back exactly as AntFarmSetActive(0) but KEEP the mode
 * wanted, so it re-engages by itself as soon as the game is playable again.
 * This is what "on" means for AntFarm: a pause, a cutscene, a replay or a
 * level restart SUSPENDS the screensaver, it never silently switches it off.
 * Turning it off for good is the pause-menu row or F9. */
static void AntFarmSuspend(void)
{
	AntFarmSetActive(0);
	s.pendingEnable = 1;

	s.ctx->jer_log(s.ctx, "[antfarm] suspended (re-engages when playable)\n");
}

static void AntFarmSetActive(int on)
{
	if (!on)
		s.pendingEnable = 0;

	if (on == s.active)
		return;

	if (on)
	{
		/* A live multiplayer session owns the camera, the player and the sim; the
		 * screensaver must never take them over under a match. This is a RUNTIME
		 * gate, not a manifest one: mp is a core, default-enabled module, so
		 * `incompatible = ["mp"]` would disable Ant Farm permanently. A paused /
		 * finished session (jer_net_is_active() == 0) leaves it free to run. */
		if (jer_net_is_active())
		{
			s.ctx->jer_log(s.ctx,
				"[antfarm] refused: a multiplayer session is live\n");
			return;
		}

		if (game_over || gInGameCutsceneActive || quick_replay ||
			NumPlayers != 1 || NoPlayerControl || !AntFarmMapReady())
		{
			s.ctx->jer_log(s.ctx, "[antfarm] refused: not in a playable single-player state\n");
			return;
		}

		s.savedStopPadReads = gStopPadReads;
		s.savedDoOverlays = gDoOverlays;
		s.savedSpoolXZ = MainPlayer.spoolXZ;
		s.savedCopsAllowed = CopsAllowed;
		s.savedMasterVolume = gMasterVolume;
		s.savedPlayerFelony = *GetPlayerFelony(&MainPlayer);
		s.savedScrZ = scr_z;
		s.savedCameraCar = CameraCar;

		gStopPadReads = 1;
		gDoOverlays = 0;
		CopsAllowed = 0;

		/* Restore the game's own (neutral) master level for the watch. The PSX
		 * volume scale puts 0 at UNITY and -10000 at silence, and the music (XM)
		 * and CD audio both pass through it, so the module keeps it at the level
		 * the game itself considers normal while it runs and hands the player's
		 * own value back on exit. The player's car ENGINE is silenced separately
		 * (AntFarmOnCarEngineSound) - the volume alone never did that, which is
		 * why the idle used to be audible while the readme claimed otherwise. */
		SetMasterVolume(0);

		/* Silence the PLAYER'S OWN car engine - it is pinned and hidden, but its
		 * idle loop keeps sounding, which is the one noise a screensaver must not
		 * have. Done through the CAR_ENGINE_SOUND hook (see
		 * AntFarmOnCarEngineSound), so only the player's car is silenced. */
		s.ctx->jer_log(s.ctx, "[antfarm] player car engine silenced\n");

		s.savedPlayerCarControlType = 0;

		if (MainPlayer.playerType == PLAYER_TYPE_CAR &&
			MainPlayer.playerCarId >= 0 && MainPlayer.playerCarId < MAX_CARS)
		{
			CAR_DATA* pcar = &car_data[MainPlayer.playerCarId];

			s.savedPlayerCarControlType = pcar->controlType;
			s.savedPlayerReservedSlot = reservedSlots[MainPlayer.playerCarId];
			s.savedPlayerCarPos[0] = pcar->hd.where.t[0];
			s.savedPlayerCarPos[1] = pcar->hd.where.t[1];
			s.savedPlayerCarPos[2] = pcar->hd.where.t[2];
		}

		s.active = 1;
		s.camSnapped = 0;
		s.fade = 0;
		s.state = ANTFARM_STATE_SHOW;
		s.stateStart = AntTicks();
		s.shotStart = s.stateStart;
		s.fadeInMs = ANTFARM_FADE_MS;
		s.firstShot = 1;	/* the activation shot reveals fast (see the CUT state) */
		s.cutCount = 0;
		s.leadMode = 0;
		s.leadEnding = 0;
		s.targetCarId = -1;
		s.roadSurfId = -1;

		s.fovCurrent = scr_z;		/* breathe out from the gameplay lens */
		s.recentCount = 0;
		s.recentCarCount = 0;
		s.dwellMs = AntIntervalMs();
		s.holdSince = 0;
		s.voidHolds = 0;
		/* seed the void guard's hold with the camera we are taking over from -
		 * it is definitely over loaded geometry, so the first frame after
		 * activation can never render a void */
		s.holdPos = camera_position;
		s.holdAngle = camera_angle;
		s.stuckSince = 0;
		s.recoveries = 0;
		s.captionUntil = 0;
		s.stillSince = 0;
		s.lastDollyMs = AntTicks();
		s.handoffs = 0;
		s.lastCellX = 0x7fffffff;
		s.lastCellZ = 0x7fffffff;

		s.shotDistMin = 0x7fffffff;
		s.shotDistMax = 0;
		s.fovMin = 0x7fffffff;
		s.fovMax = 0;
		s.pitchMin = 0x7fffffff;
		s.pitchMax = -0x7fffffff;

		s.camPos.vx = camera_position.vx;
		s.camPos.vy = camera_position.vy;
		s.camPos.vz = camera_position.vz;
		s.camAngle = camera_angle;

		s.targetPos.vx = camera_position.vx;
		s.targetPos.vy = camera_position.vy;
		s.targetPos.vz = camera_position.vz;

		AntFarmPickNearArea();
		s.spool = s.areaPos;
		s.targetPos = s.areaPos;

		AntFarmPinPlayerCar();
		MainPlayer.spoolXZ = &s.spool;

		/* Fill the world around the focus straight away (activated or on a
		 * re-engage) so the screensaver does not open on an empty city; the
		 * per-cut seed below then tops the traffic up at whatever area each
		 * shot actually hops to. */
		AntFarmPreseedTraffic(maxCivCars);

		/* Do NOT plan and reveal a shot straight from activation: that showed a
		 * frame whose region and texture pages had not streamed yet, which is
		 * the grey/skybox first shot. Enter the ordinary CUT instead and let the
		 * normal machinery plan and stream the first shot - the cut is black, so
		 * the only cost is the first cut's length. The area picked above is only
		 * the initial camera/spool seed; the first cut then hops to a far area
		 * exactly like every other cut. */
		s.state = ANTFARM_STATE_CUT;
		s.cutInit = 0;
		s.fade = 255;
		s.stateStart = AntTicks();
		s.shotStart = 0;	/* no shot revealed yet (set when the first FADE_IN starts) */
		s.cutStart = s.stateStart;

		{
			char styleList[220];  /* all 20 style keys fit - 80 silently truncated the log */
			int n = 0, j;

			styleList[0] = '\0';

			for (j = 0; j < ANTFARM_STYLE_COUNT && n < (int)sizeof(styleList) - 16; j++)
			{
				if (!s.stylesEnabled[j])
					continue;

				n += snprintf(styleList + n, sizeof(styleList) - (size_t)n, "%s%s",
					(n > 0) ? "," : "", antStyleDefs[j].key);
			}

			s.ctx->jer_log(s.ctx,
				"[antfarm] enabled (interval %ds, styles %s, lead=%d%%)\n",
				AntIntervalMs() / 1000, styleList, s.leadEnabled ? s.leadChance : 0);
		}
	}
	else
	{
		if (s.leadMode)
			AntFarmEndLead();

		gStopPadReads = s.savedStopPadReads;
		gDoOverlays = s.savedDoOverlays;
		CopsAllowed = s.savedCopsAllowed;
		SetMasterVolume(s.savedMasterVolume);

		/* give the projection distance and the tracked car back too - both were
		 * mutated every active frame and never restored */
		SetGeomScreen(scr_z = s.savedScrZ);
		CameraCar = s.savedCameraCar;

		MainPlayer.spoolXZ = s.savedSpoolXZ;

		if (s.savedPlayerCarControlType != 0 &&
			MainPlayer.playerCarId >= 0 && MainPlayer.playerCarId < MAX_CARS)
		{
			CAR_DATA* pcar = &car_data[MainPlayer.playerCarId];

			pcar->controlType = (u_char)s.savedPlayerCarControlType;
			reservedSlots[MainPlayer.playerCarId] = (u_char)s.savedPlayerReservedSlot;
			pcar->hd.where.t[0] = s.savedPlayerCarPos[0];
			pcar->hd.where.t[1] = s.savedPlayerCarPos[1];
			pcar->hd.where.t[2] = s.savedPlayerCarPos[2];
			pcar->st.n.fposition[0] = s.savedPlayerCarPos[0] << 4;
			pcar->st.n.fposition[1] = s.savedPlayerCarPos[1] << 4;
			pcar->st.n.fposition[2] = s.savedPlayerCarPos[2] << 4;
			pcar->st.n.linearVelocity[0] = 0;
			pcar->st.n.linearVelocity[1] = 0;
			pcar->st.n.linearVelocity[2] = 0;
			pcar->st.n.angularVelocity[0] = 0;
			pcar->st.n.angularVelocity[1] = 0;
			pcar->st.n.angularVelocity[2] = 0;
		}

		s.active = 0;
		s.fade = 0;

		s.ctx->jer_log(s.ctx,
			"[antfarm] disabled (cuts: %d; void guards: %d; recoveries: %d; restored pads=%d overlays=%d cops=%d vol=%d)\n",
			s.cutCount, s.voidHolds, s.recoveries, s.savedStopPadReads,
			s.savedDoOverlays, s.savedCopsAllowed, s.savedMasterVolume);
	}
}

static void AntFarmToggle(void)
{
	/* The intent is "wanted", not just "running": pausing suspends the mode
	 * (it is wanted but not active), so an off request must clear the want too
	 * or it would come straight back when the pause closes. */
	if (s.active || s.pendingEnable)
	{
		AntFarmSetActive(0);			/* also clears pendingEnable */
		jer_config_set_bool(ANT_MOD_ID, "enabled", 0);
	}
	else
	{
		s.pendingEnable = 1;
		AntFarmSetActive(1);
		jer_config_set_bool(ANT_MOD_ID, "enabled", 1);
	}
}

static void AntFarmCheckF9(void)
{
#ifndef PSX
	const Uint8* keys = SDL_GetKeyboardState(NULL);
	int down = (keys != NULL) && keys[SDL_SCANCODE_F9];

	if (down && !s.f9Down)
		AntFarmToggle();

	s.f9Down = down;
#endif
}

/* ------------------------------------------------------------------ */
/* JERICHO hooks                                                      */
/* ------------------------------------------------------------------ */

static void AntFarmPinPlayerCar(void);

static int AntFarmOnFrame(void* userdata, void* args)
{
	unsigned long now;

	(void)userdata;
	(void)args;

	AntFarmCheckF9();

	now = AntTicks();

	/* A config-enabled screensaver turns itself on as soon as the game is in
	 * a playable single-player state. This used to sit BELOW the !active
	 * early-return below, so it could never run — "enabled = 1" did nothing
	 * and the mode only ever started from F9 / the pause menu.
	 * A live mp session is not ours to take over, so it also keeps the mode
	 * wanted-but-off until the session ends (mp is core and always present). */
	if (s.pendingEnable && !s.active && pauseflag == 0 && AntFarmMapReady() &&
		!game_over && !gInGameCutsceneActive && !quick_replay &&
		NumPlayers == 1 && !NoPlayerControl && !jer_net_is_active())
	{
		AntFarmSetActive(1);

		if (s.active)
			s.pendingEnable = 0;
	}

	if (!s.active)
		return JER_RESULT_CONTINUE;

	if (gInGameCutsceneActive || quick_replay || game_over || jer_net_is_active())
	{
		/* The engine is driving the screen (a cutscene, a replay, the game-over
		 * screen) or an mp session needs the camera and the player's car back.
		 * Suspend, but stay wanted: the screensaver re-engages when the game is
		 * playable again - "on" means on, neither a cutscene nor a match must
		 * switch it off. */
		AntFarmSuspend();
		return JER_RESULT_CONTINUE;
	}

	if (s.state != ANTFARM_STATE_SHOW && now - s.stateStart >= 30000)
	{
		s.ctx->jer_log(s.ctx, "[antfarm] watchdog: state %d stuck — recovering\n", s.state);
		s.fade = 0;
		s.state = ANTFARM_STATE_SHOW;
		s.stateStart = now;
	}

	if (s.leadMode)
	{
		if (AntFarmLeadEscaped())
		{
			AntFarmEndLead();
			s.state = ANTFARM_STATE_FADE_OUT;
			s.stateStart = now;
			return JER_RESULT_CONTINUE;
		}

		if (AntFarmLeadTotaled())
		{
			if (!s.leadEnding)
			{
				s.leadEnding = 1;
				s.leadEndStart = now;
				s.ctx->jer_log(s.ctx, "[antfarm] rogue car wrecked — holding\n");
			}

			if (now - s.leadEndStart >= ANTFARM_LEAD_END_MS)
			{
				AntFarmEndLead();
				s.state = ANTFARM_STATE_FADE_OUT;
				s.stateStart = now;
			}

			return JER_RESULT_CONTINUE;
		}

		CopsAllowed = 1;
		*GetPlayerFelony(&MainPlayer) = 2500;
	}

	/* when a shot ends, report what it did: the model, the subject kind, the
	 * distance the camera kept from its subject and the lens range it used.
	 * That makes a rig distinguishable from a roadside shot (it hugs its car)
	 * and a zoom row from a fixed lens, from the log alone. */
	if (s.state != s.lastState)
	{
		if (s.state == ANTFARM_STATE_FADE_OUT && s.shotStart != 0 &&
			s.shotDistMax > 0)
		{
			s.ctx->jer_log(s.ctx,
				"[antfarm] shot #%d model=%s subject=%s dist %d..%d fov %d..%d pitch %d..%d\n",
				s.cutCount, AntFarmModelName(antStyleDefs[s.style].model),
				(s.targetKind == ANTFARM_TARGET_CAR) ? "car" : "road",
				s.shotDistMin, s.shotDistMax, s.fovMin, s.fovMax,
				s.pitchMin, s.pitchMax);
		}

		s.lastState = s.state;
	}

	switch (s.state)
	{
	case ANTFARM_STATE_SHOW:
		if (!s.leadMode && s.targetKind == ANTFARM_TARGET_CAR &&
			AntFarmValidCar() == NULL)
		{
			/* The subject despawned mid-shot (civilian AI recycles slots). Swap
			 * to another car and keep the angle rather than cutting at once, so
			 * the camera actually gets to settle on its subject. */
			int car = AntFarmPickCarNear(&s.areaPos, 0, AntFarmModelMinSpeed(s.style));

			if (car >= 0)
			{
				AntFarmSetCarSubject(car);
				s.ctx->jer_log(s.ctx, "[antfarm] subject car gone - switched to car %d\n", car);
			}
			else
			{
				s.state = ANTFARM_STATE_FADE_OUT;
				s.stateStart = now;
				break;
			}
		}

		/* Handle the follow cam: nothing to cycle any more. The trail cam is ONE
		 * continuous framing (see AntFarmFollowCam) - the old car-mode cycling
		 * that swapped chase-behind / overhead / chase-front every few seconds is
		 * what made the follow shot read as snappy and side-switching. */

		/* A rig on a parked car (or a long lens pointed at one) is a frozen
		 * frame, which is the one thing a screensaver must not show: if the
		 * subject stops moving, cut away rather than stare at it. */
		if (!s.leadMode && !s.leadEnding)
		{
			int model = antStyleDefs[s.style].model;

			if (model == ANT_MODEL_ATTACH || model == ANT_MODEL_TRIPODZ)
			{
				CAR_DATA* cp = AntFarmValidCar();

				/* A long-lens vantage watches a car drive away: once it is out
				 * of any useful range the shot is over - a pan ends when the
				 * subject recedes, it does not watch it leave the map. */
				if (cp != NULL && model == ANT_MODEL_TRIPODZ)
				{
					int dx = camera_position.vx - s.targetPos.vx;
					int dz = camera_position.vz - s.targetPos.vz;

					if (AntFarmDist(dx, dz) > s.shotFwd * 3 + 1500)
					{
						s.ctx->jer_log(s.ctx,
							"[antfarm] subject out of range - cutting away\n");
						s.state = ANTFARM_STATE_FADE_OUT;
						s.stateStart = now;
						break;
					}
				}

				if (cp != NULL && cp->hd.speed > -40 && cp->hd.speed < 40)
				{
					if (s.stillSince == 0)
						s.stillSince = now;

					if (now - s.stillSince >= ANTFARM_STILL_MS)
					{
						s.ctx->jer_log(s.ctx,
							"[antfarm] subject parked - cutting away\n");
						s.stillSince = 0;
						s.state = ANTFARM_STATE_FADE_OUT;
						s.stateStart = now;
						break;
					}
				}
				else
				{
					s.stillSince = 0;
				}
			}
		}

		/* Also obey the normal cut interval */
		if (!s.leadEnding &&
			now - s.stateStart >= (unsigned long)(s.dwellMs > 0 ? s.dwellMs : AntIntervalMs()))
		{
			s.state = ANTFARM_STATE_FADE_OUT;
			s.stateStart = now;
		}
		break;

	case ANTFARM_STATE_FADE_OUT:
		s.fade = (int)((now - s.stateStart) * 255 / ANTFARM_FADE_MS);

		if (s.fade >= 255)
		{
			s.fade = 255;
			s.state = ANTFARM_STATE_CUT;
			s.stateStart = now;
			s.cutInit = 0;
		}
		break;

	case ANTFARM_STATE_CUT:
		if (!s.cutInit)
		{
			s.cutInit = 1;
			s.cutStart = now;
			s.cutEnter = now;
			s.cutWaitForCar = 0;
			s.streamRetries = 0;
			s.streamDone = 0;
			s.shotPlanned = 0;
			s.seededThisCut = 0;	/* the cut's area is seeded once its region is in */
			s.blockReady = 0;	/* the destination block starts un-streamed */
			s.blockUsable = 0;
			s.holdSince = 0;
			s.vantageSet = 0;	/* a fixed vantage is resolved per shot */

			{
				long long dx = (long long)s.areaPos.vx - camera_position.vx;
				long long dz = (long long)s.areaPos.vz - camera_position.vz;

				s.jumpDist2 = dx * dx + dz * dz;
			}

			if (s.leadMode)
			{
				s.style = AntFarmPickStyle(1);
				AntFarmInitShotVars();
				s.shotPlanned = 1;
			}
			else
			{
				/* EVERY cut - the first one included - picks a fresh far area and a
				 * style by interest. The first cut used to keep the player's own
				 * neighbourhood and force a scenery angle on the theory that "at
				 * activation the civilian traffic has barely spawned". That is true of
				 * a fresh session, but not of a mid-game toggle: toggling on while
				 * driving then always opened on a parked camera pointed at the road
				 * you were just on - a static first shot with no subject. */

				/* Pick a far area that is loaded; if none, it will fallback to current position */
				AntFarmPickFarArea();
				s.spool = s.areaPos;
				s.targetPos = s.areaPos;

				AntFarmPickStyleAndTarget();

				s.cutWaitForCar = (s.targetKind == ANTFARM_TARGET_CAR);
			}
			s.camSnapped = 0;
		}

		if (!s.leadMode)
		{
			int spoolRegion = AntFarmRegionOf(&s.spool);
			int regionsReady;
			int nodesReady = (NumDriver2Straights > 0);
			int block[4];
			int blockCount, blockUsable, blockReady, allReady;

			/* The engine only ever pre-loads NEIGHBOURING regions as you move
			 * (CheckUnpackNewRegions / force_load_boundary — map.c:222-286), so
			 * the region a far hop lands in is NEVER put into a barrel. That is
			 * why the residency gate could not pass, every cut hit the black
			 * cap, and the shot was forced through into unloaded geometry
			 * (skybox/nodraw). Force the destination region in ourselves.
			 *
			 * (jer_map_spool_to is the shared version of this - the arena module
			 * uses it; antfarm keeps its own here because it also drives the
			 * camera, and this sequence predates the helper.) */
			/* The streamer follows MainPlayer.spoolXZ, and jer_map_spool_to reads
			 * it - so hand it the destination BEFORE asking for the stream. */
			MainPlayer.spoolXZ = &s.spool;

			/* On a doSpooling==0 level (an mp arena) ControlMap never runs, so
			 * the engine's current_region stays -1 and its area loader reads
			 * spoolinfo_offsets[-1]; seed it here. See AntFarmSeedCurrentRegion. */
			AntFarmSeedCurrentRegion();

			/* Force the destination in through the SHARED world-spool helper.
			 * It uses the engine's own level-start path, so the barrel's
			 * geometry and roadmap are loaded too (the hand-rolled
			 * UnpackRegion + spool flush this module used to do marked the region
			 * unpacked WITHOUT that bookkeeping, and MapHeight could still answer
			 * 0 for ground that was "loaded"), and it asks for the destination's
			 * texture AREA as well, so geometry and pages land in the same
			 * frame. Same call the CUT and the recovery path use - one code path
			 * for "make the map stream to here". */
			if (spoolRegion >= 0 && spoolRegion < regions_across * regions_down &&
				!AntFarmRegionUnpacked(spoolRegion))
			{
				jer_map_spool_to(s.spool.vx, s.spool.vz);
			}

			regionsReady = (AntFarmRegionHasData(spoolRegion) && AntFarmRegionsReady(spoolRegion));

			/* Fill the WHOLE block around the destination, not just its own
			 * region. The engine keeps four regions resident (a parity 2x2
			 * barrel) and a far hop forces only the one, so the other three
			 * barrels still hold the previous shot's regions: the new area opens
			 * as a small island of geometry (or nothing) around the shot - "the
			 * world is empty when it loads into a new region". blockUsable is how
			 * many of the block's regions could be loaded (on the map, with
			 * data); blockReady is how many are resident now, and the cut waits
			 * for all of the usable ones. */
			blockCount = AntFarmBlockAround(&s.spool, block);
			blockUsable = AntFarmBlockUsable(block, blockCount);
			blockReady = AntFarmStreamBlock(block, blockCount);

			s.blockReady = blockReady;
			s.blockUsable = blockUsable;

			allReady = (regionsReady && nodesReady && blockReady >= blockUsable);

			if (!allReady && !s.streamDone)
			{
				if (now - s.cutStart >= ANTFARM_STREAM_TIMEOUT_MS)
				{
					if (s.streamRetries < 3)
					{
						s.streamRetries++;
						s.cutStart = now;

						/* Attempt to pick a new loaded area; if fails, keep current position */
						if (AntFarmPickFarArea())
						{
							s.spool = s.areaPos;
							s.targetPos = s.areaPos;
						}
						/* else keep existing spool (which is loaded) */
						s.camSnapped = 0;
					}
					else
					{
						s.ctx->jer_log(s.ctx, "[antfarm] warning: area stream timeout — forcing progression with fallback position\n");
						/* Force use of current camera position as fallback (which is loaded) */
						s.areaPos.vx = camera_position.vx;
						s.areaPos.vz = camera_position.vz;
						s.areaPos.vy = AntFarmMapHeight(s.areaPos.vx, s.areaPos.vz);
						AntFarmClampToWorld(&s.areaPos);
						s.spool = s.areaPos;
						s.targetPos = s.areaPos;
						s.streamDone = 1;
						s.cutStart = now;
					}
				}

				if (now - s.cutEnter >= ANTFARM_BLACK_CAP_MS)
				{
					{
						int brx = spoolRegion % regions_across;
						int brz = spoolRegion / regions_across;
						int barrel = (brx & 1) + (brz & 1) * 2;

						s.ctx->jer_log(s.ctx,
							"[antfarm] diag: area %d,%d -> region %d (rx=%d rz=%d barrel=%d unpacked=%d loading=%d data=%d) block %d/%d engine: current=%d rx=%d rz=%d cell=%d,%d\n",
							s.areaPos.vx, s.areaPos.vz, spoolRegion, brx, brz, barrel,
							regions_unpacked[barrel], loading_region[barrel],
							(spoolinfo_offsets[spoolRegion] == 0xffff) ? 0 : 1,
							blockReady, blockUsable,
							current_region, region_x, region_z,
							current_barrel_region_xcell, current_barrel_region_zcell);
					}

					s.ctx->jer_log(s.ctx, "[antfarm] warning: black cap hit — forcing progression with fallback position\n");
					/* Use current camera position as fallback */
					s.areaPos.vx = camera_position.vx;
					s.areaPos.vz = camera_position.vz;
					s.areaPos.vy = AntFarmMapHeight(s.areaPos.vx, s.areaPos.vz);
					AntFarmClampToWorld(&s.areaPos);
					s.spool = s.areaPos;
					s.targetPos = s.areaPos;
					s.streamDone = 1;
					s.cutStart = now;
				}

				break;
			}

			if (!s.streamDone && (allReady || s.streamRetries >= 3))
			{
				s.streamDone = 1;
				s.spool = s.targetPos;
				AntFarmPinPlayerCar();
				MainPlayer.spoolXZ = &s.spool;
				s.cutStart = now;
			}

			/* The destination region is in, so now it is safe to seed traffic
			 * around the area the shot will actually use (once per cut). The
			 * spawner places cars with MapHeight(), so seeding any earlier -
			 * before the region is resident - would drop them into the void. */
			if (s.streamDone && !s.seededThisCut)
			{
				s.seededThisCut = 1;
				AntFarmPreseedTraffic(maxCivCars);
			}

			if (s.streamDone && !s.shotPlanned)
			{
				if (s.targetKind == ANTFARM_TARGET_CAR)
				{
					int minSpeed = AntFarmModelMinSpeed(s.style);
					int car = AntFarmPickCarNear(&s.areaPos, 14000, minSpeed);

					if (car < 0)
						car = AntFarmPickCarNear(&s.areaPos, 0, minSpeed);

					if (car >= 0)
					{
						/* plan FIRST, then attach the car: PlanShot resets
						 * targetCarId, so doing it the other way round invalidated
						 * the car we had just picked and every car shot then cut on
						 * its first SHOW frame (a one-second shot with the camera
						 * still nowhere near the car). */
						AntFarmPlanShot();
						AntFarmSetCarSubject(car);
						s.cutWaitForCar = 0;
						s.shotPlanned = 1;
					}
					else if (now - s.cutStart >= ANTFARM_CAR_WAIT_MS)
					{
						int rs = AntFarmPickStyle(0);

						if (antStyleDefs[rs].carFirst == 0)
						{
							s.targetKind = ANTFARM_TARGET_ROAD;
							s.style = rs;
							AntFarmPlanShot();
							s.shotPlanned = 1;
						}

						/* else: only car-locked styles are enabled, so keep looking for
						 * traffic - shotPlanned stays 0, so the cut cannot reveal a shot
						 * with no subject on it */
					}
				}
				else
				{
					AntFarmPlanShot();
					s.shotPlanned = 1;
				}
			}

			/* A car subject re-anchors s.spool onto the car
			 * (AntFarmSetCarSubject), which can sit in a region outside the block
			 * streamed above - the anywhere-fallback pick is not bounded to the
			 * area. Force the block around the FINAL anchor in too, so the subject
			 * is framed on loaded geometry; the force is synchronous, so this
			 * needs no extra waiting. */
			if (s.streamDone && s.shotPlanned)
			{
				int b2[4];
				int n2 = AntFarmBlockAround(&s.spool, b2);

				s.blockReady = AntFarmStreamBlock(b2, n2);
				s.blockUsable = AntFarmBlockUsable(b2, n2);
			}
		}

		/* How long the black CUT is held before the shot is revealed. Every
		 * later cut waits the normal hold (it covers a far hop's streaming and
		 * lets the destination's texture pages land), but the ACTIVATION shot
		 * waits for nothing except its own readiness: it reveals the moment its
		 * region is resident and the shot is planned, so the screensaver does
		 * not open on seconds of black. The streaming gate above has already
		 * run, so reaching here means the region is in. */
		{
			unsigned long holdMs = s.firstShot ? 0
				: (unsigned long)(ANTFARM_CUT_HOLD_MS + ANTFARM_TEX_SETTLE_MS
					+ (s.jumpDist2 > 0 ? (s.jumpDist2 / 30000 > 2000 ? 2000 : (int)(s.jumpDist2 / 30000)) : 0));

			if (!(s.shotPlanned &&
				(s.targetKind != ANTFARM_TARGET_CAR || AntFarmValidCar() != NULL) &&
				now - s.cutStart >= holdMs))
				break;
		}

		{
			if (!s.leadMode && s.leadEnabled &&
				s.targetKind == ANTFARM_TARGET_CAR &&
				MainPlayer.playerType == PLAYER_TYPE_CAR &&
				(AntRand() % 100) < s.leadChance)
			{
				AntFarmStartLead();
			}

			s.state = ANTFARM_STATE_FADE_IN;
			s.stateStart = now;
			s.shotStart = now;
			/* the activation shot fades in over ANTFARM_FIRST_FADE_MS; every
			 * later shot gets the normal transition. Recorded per transition so
			 * the FADE_IN ramp reads the right duration, and the flag cleared
			 * so only the FIRST shot is fast. */
			s.fadeInMs = s.firstShot ? ANTFARM_FIRST_FADE_MS : ANTFARM_FADE_MS;

			if (s.firstShot)
				s.ctx->jer_log(s.ctx, "[antfarm] first shot: fading in over %dms\n",
					ANTFARM_FIRST_FADE_MS);

			s.firstShot = 0;
			s.dwellMs = AntFarmComputeDwell();
			s.camSnapped = 0;	/* snap onto the new shot under the black */
			s.lastDollyMs = now;
			s.handoffs = 0;
			s.shotDistMin = 0x7fffffff;
			s.shotDistMax = 0;
			s.fovMin = 0x7fffffff;
			s.fovMax = 0;
			s.pitchMin = 0x7fffffff;
			s.pitchMax = -0x7fffffff;

			/* an occasional place-name caption, not on every shot */
			if (s.captions && !s.leadMode && AntRandChance(40))
				s.captionUntil = now + ANTFARM_CAPTION_MS;

			s.cutCount++;
			{
				int ar = AntFarmRegionOf(&s.areaPos);

				s.ctx->jer_log(s.ctx,
					"[antfarm] cut #%d -> area %d,%d region %d block %d/%d style %d%s (frame %d)\n",
					s.cutCount, s.areaPos.vx, s.areaPos.vz,
					ar, s.blockReady, s.blockUsable,
					s.style,
					(s.targetKind == ANTFARM_TARGET_CAR) ? " car" : "",
					FrameCnt);
			}
		}
		break;

	case ANTFARM_STATE_FADE_IN:
		s.fade = 255 - (int)((now - s.stateStart) * 255 /
			(unsigned long)(s.fadeInMs > 0 ? s.fadeInMs : ANTFARM_FADE_MS));

		if (s.fade <= 0)
		{
			s.fade = 0;
			s.state = ANTFARM_STATE_SHOW;
			s.stateStart = now;
		}
		break;
	}

	/* --- texture-area guard -------------------------------------------
	 * The engine streams texture pages per AREA keyed off camera_position,
	 * which it recomputes each frame - but a shot that travels (dolly,
	 * flyover, crane) crosses cells faster than the pager settles, and a page
	 * that misses its slot is the "scenery / palette did not load" look. When
	 * the camera enters a new cell during a live shot, ask for that cell's
	 * area data explicitly, exactly as the CUT does for a destination, so the
	 * pages are requested the moment they are needed. (The CUT already does
	 * this for the shot it is streaming in, so it is skipped there.) */
	if (s.active && s.state != ANTFARM_STATE_CUT && AntFarmMapReady() &&
		current_region >= 0 && current_region < regions_across * regions_down)
	{
		int cx = (camera_position.vx + units_across_halved) / MAP_CELL_SIZE;
		int cz = (camera_position.vz + units_down_halved) / MAP_CELL_SIZE;

		if (cx != s.lastCellX || cz != s.lastCellZ)
		{
			s.lastCellX = cx;
			s.lastCellZ = cz;

			CheckLoadAreaData(cx, cz);
			StartSpooling();
			UpdateSpool();
		}
	}

	/* --- world recovery trigger -----------------------------------------
	 * The void guard in the camera hook holds the previous frame while the
	 * camera's region is not resident. If that never resolves (a shot whose
	 * ground has no data, or a streamer that will not follow) the tour would
	 * simply sit there, so after ANTFARM_RECOVER_MS re-anchor on a road and
	 * re-plan. The CUT does its own streaming, so it is exempt. */
	if (s.active && s.state != ANTFARM_STATE_CUT && AntFarmMapReady())
	{
		if (!AntFarmRegionUnpacked(AntFarmRegionOf(&camera_position)))
		{
			if (s.stuckSince == 0)
				s.stuckSince = now;
			else if (now - s.stuckSince >= ANTFARM_RECOVER_MS)
				AntFarmRecoverToRoad();
		}
		else
		{
			s.stuckSince = 0;
		}
	}

	if (s.active)
		AntFarmPinPlayerCar();

	return JER_RESULT_CONTINUE;
}

/* Pin the player's car to the camera focus while the screensaver runs */
static void AntFarmPinPlayerCar(void)
{
	int carId;
	CAR_DATA* cp;

	if (MainPlayer.playerType != PLAYER_TYPE_CAR)
		return;

	carId = MainPlayer.playerCarId;

	if (carId < 0 || carId >= MAX_CARS)
		return;

	cp = &car_data[carId];

	{
		int maxX = units_across_halved - 2000;
		int maxZ = units_down_halved - 2000;
		int ground;

		if (s.targetPos.vx < -maxX)
			s.targetPos.vx = -maxX;

		if (s.targetPos.vx > maxX)
			s.targetPos.vx = maxX;

		if (s.targetPos.vz < -maxZ)
			s.targetPos.vz = -maxZ;

		if (s.targetPos.vz > maxZ)
			s.targetPos.vz = maxZ;

		ground = AntFarmMapHeight(s.targetPos.vx, s.targetPos.vz);

		if (s.targetPos.vy < ground - 100)
			s.targetPos.vy = ground;
	}

	cp->hd.where.t[0] = s.targetPos.vx;
	cp->hd.where.t[1] = s.targetPos.vy;
	cp->hd.where.t[2] = s.targetPos.vz;

	cp->st.n.fposition[0] = s.targetPos.vx << 4;
	cp->st.n.fposition[1] = s.targetPos.vy << 4;
	cp->st.n.fposition[2] = s.targetPos.vz << 4;

	cp->st.n.linearVelocity[0] = 0;
	cp->st.n.linearVelocity[1] = 0;
	cp->st.n.linearVelocity[2] = 0;
	cp->st.n.angularVelocity[0] = 0;
	cp->st.n.angularVelocity[1] = 0;
	cp->st.n.angularVelocity[2] = 0;

	cp->hd.speed = 0;

	{
		int g = AntFarmMapHeight(cp->hd.where.t[0], cp->hd.where.t[2]);

		if (cp->hd.where.t[1] < g)
			cp->hd.where.t[1] = g;

		cp->st.n.fposition[1] = cp->hd.where.t[1] << 4;
	}

	if (cp->controlType != CONTROL_TYPE_NONE)
	{
		s.savedPlayerCarControlType = cp->controlType;
		s.savedPlayerReservedSlot = reservedSlots[carId];
		cp->controlType = CONTROL_TYPE_NONE;
		reservedSlots[carId] = 1;
	}
}

/* render-time: take over the camera */
static int AntFarmOnCamera(void* userdata, void* args)
{
	JER_ARGS_CAMERA* a = (JER_ARGS_CAMERA*)args;
	VECTOR cam;
	SVECTOR ang;
	unsigned long now;

	(void)userdata;

	if (!s.active)
		return JER_RESULT_CONTINUE;

	now = AntTicks();

	MainPlayer.spoolXZ = &s.spool;

	/* During the CUT the shot's geometry is not final and the previous shot's
	 * road/car references are no longer resident (the spool has already moved),
	 * so hold the camera completely: it must not look at, or drift into,
	 * geometry that has not streamed. This is what keeps a cut black instead of
	 * flashing skybox/nodraw. */
	if (s.state == ANTFARM_STATE_CUT)
	{
		/* Keep streaming the SUBJECT while the screen is black: the new region
		 * will evict the old one, which is fine because nothing is visible.
		 *
		 * The camera is ALSO parked at the destination (x/z) instead of being
		 * left on the old shot, because the engine derives which TEXTURE AREAS
		 * to stream from camera_position (map.c ControlMap ends by recomputing
		 * the cells from camera_position before StartSpooling()). A camera still
		 * sitting at the old spot therefore streamed the old area's texture
		 * pages, and the new scenery faded in untextured - the "scenery textures
		 * sometimes don't load" bug. Y is left alone so the height stays sane. */
		s.spool = s.targetPos;

		camera_position.vx = s.targetPos.vx;
		camera_position.vz = s.targetPos.vz;
		camera_angle = s.camAngle;

		*(VECTOR*)a->cameraPosition = camera_position;
		*(SVECTOR*)a->cameraAngle = camera_angle;
		a->override = 1;

		/* The parked camera is over geometry the CUT just forced resident, so it
		 * is the last frame the void guard can safely hold if the shot's own
		 * camera turns out to be in a region that has not streamed yet (see the
		 * guard below). Without this the guard held the freshly-snapped shot
		 * camera - which IS the void - so the first frame of a hop's shot after
		 * a pause/level start / in an mp level showed nothing but the skybox. */
		s.holdPos = camera_position;
		s.holdAngle = camera_angle;

		return JER_RESULT_CONTINUE;
	}

	AntFarmComputeCamera(&cam, &ang);

	if (s.aimPos.vx == 0 && s.aimPos.vy == 0 && s.aimPos.vz == 0)
	{
		*(VECTOR*)a->cameraPosition = s.camPos;
		*(SVECTOR*)a->cameraAngle = s.camAngle;
		a->override = 1;
		return JER_RESULT_CONTINUE;
	}

	AntFarmPinPlayerCar();

	AntFarmClampToWorld(&cam);
	AntFarmClampToWorld(&s.aimPos);
	AntFarmClampAboveGround(&s.aimPos);

	/* Point the streamer at the camera BEFORE the guard below. The renderer
	 * culls from camera_position, so the camera's own region is what has to be
	 * resident; and if the hold returned first the spool would freeze with it,
	 * so the camera's region could never stream at all - a deadlock that pinned
	 * the camera for whole shots. (During the black CUT the spool instead tracks
	 * the planned subject, which is what has to stream in before the shot is
	 * shown.) */
	s.spool = cam;

	/* --- void guard -----------------------------------------------------
	 * If the camera sits in a region that has not streamed, the frame is
	 * skybox + nodraw, so hold the last camera that was over a RESIDENT region
	 * until the new one is. Only the CAMERA's region is checked: the aim is
	 * merely a direction and the renderer does not cull from it, so requiring it
	 * too caused needless holds whenever the subject drove across a boundary.
	 * The cap means a data-less region can never freeze the view forever.
	 *
	 * s.holdPos - not s.camPos - is what is held: camPos is snapped to the new
	 * shot on the first frame of a shot, so holding it held the very void this
	 * guard exists to hide ("blank void with just skybox" on the first frame of
	 * a shot after unpausing or in an mp level). */
	{
		int camReady = AntFarmRegionUnpacked(AntFarmRegionOf(&cam));

		if (!camReady && s.holdSince != 0 && now - s.holdSince > 4000)
			camReady = 1;	/* held long enough - take the shot anyway */

		if (!camReady)
		{
			if (s.holdSince == 0)
			{
				s.holdSince = now;
				s.voidHolds++;
				s.ctx->jer_log(s.ctx,
					"[antfarm] void guard: region not resident, holding camera (#%d)\n",
					s.voidHolds);
			}

			*(VECTOR*)a->cameraPosition = s.holdPos;
			*(SVECTOR*)a->cameraAngle = s.holdAngle;
			camera_position = s.holdPos;
			camera_angle = s.holdAngle;
			a->override = 1;

			return JER_RESULT_CONTINUE;
		}

		s.holdSince = 0;
	}

	{
		int ground = -AntFarmMapHeight(cam.vx, cam.vz);

		if (cam.vy > ground - 90)
			cam.vy = ground - 90;
	}

	s.camPos = cam;

	{
		SVECTOR tgt;

		PointAtTarget(&cam, &s.aimPos, &tgt);

		/* Road-following cameras tilt a touch further UP than the raw aim
		 * implies, so the frame reads more of the street and skyline instead
		 * of pointing too far down. This bias has to land HERE, on the angle
		 * the slew below actually reaches: the same correction computed in
		 * AntFarmComputeCamera writes a local that the slew then overwrites,
		 * so it never reached the screen. vx is 0 at level and grows
		 * downward, so subtracting tilts the view up. */
		if (s.targetKind == ANTFARM_TARGET_ROAD &&
			AntFarmModelIsRoadFacing(antStyleDefs[s.style].model))
			tgt.vx = (tgt.vx - ANTFARM_ROAD_PITCH_UP) & 0xfff;

		/* ...and never look at the ground. Clamp the rendered pitch for EVERY
		 * model and subject, so no archetype or table row can leave a shot
		 * staring at tarmac. vx is 0 at level and grows downward, so only
		 * values in (0, 2048) are "down" and are clamped; an upward tilt is
		 * left alone (the skyline is the point). */
		{
			int pv = tgt.vx;

			if (pv > 2048)
				pv -= 4096;

			if (pv > ANTFARM_PITCH_DOWN_MAX)
				pv = ANTFARM_PITCH_DOWN_MAX;

			if (pv < -ANTFARM_PITCH_UP_MAX)
				pv = -ANTFARM_PITCH_UP_MAX;

			tgt.vx = (short)(pv & 0xfff);
		}

		/* a barely-there horizon roll keeps the frame from feeling rigid */
		if (s.rollOn)
			tgt.vz = (short)(RSIN((AntTicks() / 400) & 4095) >> 7);

		{
			int cur, d;

			cur = s.camAngle.vx;
			d = tgt.vx - cur;

			if (d > 2048)
				d -= 4096;
			else if (d < -2048)
				d += 4096;

			s.camAngle.vx = (short)((cur + d * 18 / 100) & 0xfff);

			cur = s.camAngle.vy;
			d = tgt.vy - cur;

			if (d > 2048)
				d -= 4096;
			else if (d < -2048)
				d += 4096;

			s.camAngle.vy = (short)((cur + d * 18 / 100) & 0xfff);

			cur = s.camAngle.vz;
			d = tgt.vz - cur;

			if (d > 2048)
				d -= 4096;
			else if (d < -2048)
				d += 4096;

			s.camAngle.vz = (short)((cur + d * 18 / 100) & 0xfff);
		}

		ang = s.camAngle;
	}

	*(VECTOR*)a->cameraPosition = cam;
	*(SVECTOR*)a->cameraAngle = ang;

	camera_position = cam;
	camera_angle = ang;

	/* this frame IS over a resident region (the guard above passed), so it is
	 * the camera the guard may hold if the next frame's camera lands somewhere
	 * that has not streamed */
	s.holdPos = cam;
	s.holdAngle = ang;

	/* fold this frame into the shot's telemetry (reported at FADE_OUT) */
	if (s.state != ANTFARM_STATE_CUT)
	{
		int dist = AntFarmDist(camera_position.vx - s.targetPos.vx,
			camera_position.vz - s.targetPos.vz);

		if (dist < s.shotDistMin) s.shotDistMin = dist;
		if (dist > s.shotDistMax) s.shotDistMax = dist;

		if (s.fovCurrent < s.fovMin) s.fovMin = s.fovCurrent;
		if (s.fovCurrent > s.fovMax) s.fovMax = s.fovCurrent;

		/* the rendered camera tilt (signed: negative = up, 0 = level, positive
		 * = down). Reported so the road-camera upward tweak is measurable from
		 * the log, not just by eye. */
		{
			int pv = s.camAngle.vx;

			if (pv > 2048)
				pv -= 4096;

			if (pv < s.pitchMin) s.pitchMin = pv;
			if (pv > s.pitchMax) s.pitchMax = pv;
		}
	}

	/* breathe the lens between shots instead of snapping it, and let a zoom row
	 * push in and ease back out across the shot */
	s.fovCurrent += (AntFarmFovTarget() - s.fovCurrent) / 18;

	/* Keep the lens inside the module's own range. fovCurrent is seeded from
	 * the GAMEPLAY lens (scr_z) at activation - which the engine may have left
	 * anywhere from its floor to a distant telephoto - and AntFarmFovTarget()
	 * returns 0 until the first shot is planned, so without this clamp the
	 * first frames sweep the lens far outside 256..360 (measured: down to 17,
	 * i.e. a fisheye). That sweep is the "too extreme zoom out". */
	if (s.fovCurrent < ANTFARM_FOV_MIN)
		s.fovCurrent = ANTFARM_FOV_MIN;
	if (s.fovCurrent > ANTFARM_FOV_MAX)
		s.fovCurrent = ANTFARM_FOV_MAX;

	SetGeomScreen(scr_z = s.fovCurrent);

	if (s.targetKind == ANTFARM_TARGET_CAR && s.targetCarId >= 0 &&
		antStyleDefs[s.style].model == ANT_MODEL_FOLLOW)
		CameraCar = s.targetCarId;

	a->override = 1;

	return JER_RESULT_CONTINUE;
}

/* Silence the PLAYER's own car engine for as long as the screensaver runs.
 * The player's car is pinned and hidden (CONTROL_TYPE_NONE, so the renderer
 * skips it), but its engine channels keep looping - the idle in particular -
 * and that is the one sound a screensaver must not have. The engine's own
 * hook (gamesnd.c SoundTasks) hands us the in/out channel volumes for the
 * player's car just before they are placed, so forcing them silent is a
 * targeted mute: the rest of the city stays audible. -10000 is the PSX
 * "silent" volume (0 would be full). */
static int AntFarmOnCarEngineSound(void* userdata, void* args)
{
	JER_ARGS_CAR_ENGINE_SOUND* a = (JER_ARGS_CAR_ENGINE_SOUND*)args;

	(void)userdata;

	if (s.active)
	{
		a->idleVolume = -10000;
		a->revVolume = -10000;
	}

	return JER_RESULT_CONTINUE;
}

/* on-foot input: explicit kill switch */
static int AntFarmOnPedInput(void* userdata, void* args)
{
	JER_ARGS_PED_INPUT* a = (JER_ARGS_PED_INPUT*)args;

	(void)userdata;

	if (s.active)
		a->pad = 0;

	return JER_RESULT_CONTINUE;
}

/* START / the pause menu opening: SUSPEND rather than disable. The pause menu
 * takes over the frame and the camera, and the player's car has to be back for
 * it (and for a restart from the menu) - so hand the engine state back, but
 * remember the mode is still WANTED so it re-engages when the pause closes, on
 * whatever level is then running. Disabling here (as the module used to) is
 * what left the screensaver off and the camera confused after a pause or a
 * restart from the pause menu. Turning it off for good is the menu row / F9. */
static int AntFarmOnPauseMenu(void* userdata, void* args)
{
	JER_ARGS_PAUSE_MENU* a = (JER_ARGS_PAUSE_MENU*)args;

	(void)userdata;

	if (a->action == JER_PAUSE_OPEN && s.active)
	{
		AntFarmSuspend();
	}

	return JER_RESULT_CONTINUE;
}

/* display name for the level the player is in (see main.c bootLevelNames) */
static const char* AntFarmPlaceName(void)
{
	static const char* names[4] = { "Chicago", "Havana", "Las Vegas", "Rio" };

	if (GameLevel < 0 || GameLevel > 3)
		return "Driver 2";

	return names[GameLevel];
}

/* transition wash, optional letterbox, and an occasional place caption */
static int AntFarmOnDrawOverlay(void* userdata, void* args)
{
	POLY_F4* poly;
	int v;

	(void)userdata;
	(void)args;

	if (!s.active)
		return JER_RESULT_CONTINUE;

	/* --- transition wash --------------------------------------------------
	 * A fade through WHITE/grey was both harsh in a dark room and, worse, not
	 * what a dissolve should look like. This darkens instead: up to four
	 * stacked semi-transparent BLACK passes, each one halving what is left of
	 * the scene, so the transition goes dim -> dark -> black and then back out.
	 * Nothing bright is ever shown between two shots. */
	v = s.fade;

	if (v > 0)
	{
		int passes, i;

		if (v > 255)
			v = 255;

		passes = v / 64;		/* 1..3 darkening passes */

		for (i = 0; i < passes && i < 3; i++)
		{
			poly = (POLY_F4*)current->primptr;

			setPolyF4(poly);
			setSemiTrans(poly, 1);
			setRGB0(poly, 0, 0, 0);

#ifdef PSX
			setXYWH(poly, 0, 0, 320, 256);
#else
			setXYWH(poly, -500, 0, 1200, 256);
#endif

			addPrim(current->ot, poly);
			current->primptr += sizeof(POLY_F4);
		}

		if (v >= 250)
		{
			/* fully black at the bottom of the transition */
			poly = (POLY_F4*)current->primptr;

			setPolyF4(poly);
			setRGB0(poly, 0, 0, 0);

#ifdef PSX
			setXYWH(poly, 0, 0, 320, 256);
#else
			setXYWH(poly, -500, 0, 1200, 256);
#endif

			addPrim(current->ot, poly);
			current->primptr += sizeof(POLY_F4);
		}
	}

	/* --- soft letterbox: a barely-there cinematic frame --- */
	if (s.letterbox)
	{
		int i;

		for (i = 0; i < 2; i++)
		{
			int y = (i == 0) ? 0 : (256 - ANTFARM_LETTERBOX_H);

			poly = (POLY_F4*)current->primptr;

			setPolyF4(poly);
			setRGB0(poly, 0, 0, 0);

#ifdef PSX
			setXYWH(poly, 0, y, 320, ANTFARM_LETTERBOX_H);
#else
			setXYWH(poly, -500, y, 1200, ANTFARM_LETTERBOX_H);
#endif

			addPrim(current->ot, poly);
			current->primptr += sizeof(POLY_F4);
		}
	}

	/* --- occasional place-name caption, fading in and out --- */
	if (s.captions && s.captionUntil != 0)
	{
		unsigned long now = AntTicks();

		if (now < s.captionUntil)
		{
			unsigned long left = s.captionUntil - now;
			unsigned long shown = ANTFARM_CAPTION_MS - left;
			char line[24];
			int level;

			if (shown < 900)
				level = (int)(shown * 235 / 900);
			else if (left < 900)
				level = (int)(left * 235 / 900);
			else
				level = 235;

			if (level < 0) level = 0;
			if (level > 235) level = 235;

			snprintf(line, sizeof(line), "%s", AntFarmPlaceName());

			SetTextColour((u_char)level, (u_char)level, (u_char)level);
			PrintString(line, 12, 196);
		}
		else
		{
			s.captionUntil = 0;
		}
	}

	/* --- debug readout: what the camera is doing right now ---------------
	 * Bottom-right, like the place-name caption, and only when asked for
	 * (debug_hud in antfarm.ini): it takes the guesswork out of "what am I
	 * looking at" when a shot misbehaves (void, unscrolled scenery). */
	if (s.debugHud)
	{
		static const char* stNames[4] = { "show", "fade-out", "cut", "fade-in" };
		char line[72];
		int st = (s.state >= 0 && s.state < 4) ? s.state : 0;

		snprintf(line, sizeof(line), "antfarm: %s %s %s %s",
			antStyleDefs[s.style].key, AntFarmModelName(antStyleDefs[s.style].model),
			(s.targetKind == ANTFARM_TARGET_CAR) ? "car" : "road", stNames[st]);

		SetTextColour(140, 140, 140);
		PrintStringRightAligned(line, 316, 244);
	}

	return JER_RESULT_CONTINUE;
}

/* ------------------------------------------------------------------ */
/* pause menu                                                         */
/* ------------------------------------------------------------------ */

static void AntMenuLabel(void* userdata, char* out, int max)
{
	(void)userdata;

	/* "wanted" (running OR suspended by a pause), so the row shows ON while
	 * the pause menu has the mode on hold */
	snprintf(out, max, "Ant Farm: %s", (s.active || s.pendingEnable) ? "ON" : "OFF");
}

static int AntMenuToggle(void* userdata, int direction)
{
	(void)userdata;
	(void)direction;

	AntFarmToggle();

	return JER_PAUSE_QUIT_NONE;
}

static void AntIntervalLabel(void* userdata, char* out, int max)
{
	(void)userdata;

	snprintf(out, max, "Cut interval: %ds", AntIntervalMs() / 1000);
}

static int AntIntervalAdjust(void* userdata, int direction)
{
	int secs;

	(void)userdata;

	secs = AntIntervalMs() / 1000 + direction * 5;

	if (secs < ANTFARM_MIN_INTERVAL)
		secs = ANTFARM_MIN_INTERVAL;

	if (secs > ANTFARM_MAX_INTERVAL)
		secs = ANTFARM_MAX_INTERVAL;

	s.intervalMs = secs * 1000;
	jer_config_set_int(ANT_MOD_ID, "interval", secs);

	return JER_PAUSE_QUIT_NONE;
}

/* Style rows are generated from the archetype table, so a new camera style
 * shows up in the pause menu automatically (userdata carries the index). */
static void AntStyleLabelFn(void* userdata, char* out, int max)
{
	int style = (int)(size_t)userdata;

	snprintf(out, max, "%s: %s", antStyleDefs[style].label,
		s.stylesEnabled[style] ? "ON" : "OFF");
}

static int AntStyleToggleFn(void* userdata, int direction)
{
	int style = (int)(size_t)userdata;
	char key[24];

	(void)direction;

	s.stylesEnabled[style] = !s.stylesEnabled[style];

	snprintf(key, sizeof(key), "style_%s", antStyleDefs[style].key);
	jer_config_set_bool(ANT_MOD_ID, key, s.stylesEnabled[style]);

	return JER_PAUSE_QUIT_NONE;
}

static void AntLeadLabel(void* userdata, char* out, int max)
{
	(void)userdata;

	snprintf(out, max, "Rogue cars: %s", s.leadEnabled ? "ON" : "OFF");
}

static int AntLeadToggle(void* userdata, int direction)
{
	(void)userdata;
	(void)direction;

	s.leadEnabled = !s.leadEnabled;
	jer_config_set_bool(ANT_MOD_ID, "lead_mode", s.leadEnabled);

	return JER_PAUSE_QUIT_NONE;
}

static JER_PAUSE_MENU_ITEM antMenuItems[ANTFARM_STYLE_COUNT + 5];
static JER_PAUSE_MENU antFarmMenu;

static void AntFarmSetItem(int* n, void (*get_label)(void*, char*, int),
	int (*on_activate)(void*, int), void* userdata, int adjust)
{
	antMenuItems[*n].label = NULL;
	antMenuItems[*n].get_label = get_label;
	antMenuItems[*n].on_activate = on_activate;
	antMenuItems[*n].userdata = userdata;
	antMenuItems[*n].submenu = NULL;
	antMenuItems[*n].adjust = adjust;
	(*n)++;
}

/* Built at activation: item_count must equal the number of filled rows. */
static void AntFarmBuildMenu(void)
{
	int n = 0, i;

	AntFarmSetItem(&n, AntMenuLabel, AntMenuToggle, NULL, 0);
	AntFarmSetItem(&n, AntIntervalLabel, AntIntervalAdjust, NULL, 1);

	for (i = 0; i < ANTFARM_STYLE_COUNT; i++)
		AntFarmSetItem(&n, AntStyleLabelFn, AntStyleToggleFn, (void*)(size_t)i, 0);

	AntFarmSetItem(&n, AntLeadLabel, AntLeadToggle, NULL, 0);

	antFarmMenu.title = "Ant Farm";
	antFarmMenu.items = antMenuItems;
	antFarmMenu.item_count = n;
}

/* ------------------------------------------------------------------ */
/* boot + entry                                                       */
/* ------------------------------------------------------------------ */

static int AntFarmOnBoot(void* userdata, void* args)
{
	int secs, i;

	(void)userdata;
	(void)args;

	secs = jer_config_get_int(ANT_MOD_ID, "interval", ANTFARM_DEFAULT_INTERVAL);

	if (secs < ANTFARM_MIN_INTERVAL)
		secs = ANTFARM_MIN_INTERVAL;

	if (secs > ANTFARM_MAX_INTERVAL)
		secs = ANTFARM_MAX_INTERVAL;

	s.intervalMs = secs * 1000;

	for (i = 0; i < ANTFARM_STYLE_COUNT; i++)
	{
		char key[24];
		int def;

		snprintf(key, sizeof(key), "style_%s", antStyleDefs[i].key);

		/* chase is the least restful archetype, so it is off unless asked for;
		 * an archetype whose camera has not landed yet is off too */
		def = AntFarmStyleImplemented(antStyleDefs[i].model) &&
			(i != ANTFARM_STYLE_CHASE);

		s.stylesEnabled[i] = jer_config_get_bool(ANT_MOD_ID, key, def);
	}

	s.rollOn = jer_config_get_bool(ANT_MOD_ID, "roll", 1);
	s.letterbox = jer_config_get_bool(ANT_MOD_ID, "letterbox", 1);
	s.captions = jer_config_get_bool(ANT_MOD_ID, "captions", 1);
	s.debugHud = jer_config_get_bool(ANT_MOD_ID, "debug_hud", 0);
	s.leadEnabled = jer_config_get_bool(ANT_MOD_ID, "lead_mode", 0);
	s.leadChance = ANTFARM_LEAD_CHANCE;
	s.pendingEnable = jer_config_get_bool(ANT_MOD_ID, "enabled", 1);

	/* Build the road cache once at boot */
	AntFarmBuildRoadCache();

	{
		char styleList[220];  /* all 20 style keys fit - 80 silently truncated the log */
		int n = 0;

		styleList[0] = '\0';

		for (i = 0; i < ANTFARM_STYLE_COUNT && n < (int)sizeof(styleList) - 16; i++)
		{
			if (!s.stylesEnabled[i])
				continue;

			n += snprintf(styleList + n, sizeof(styleList) - (size_t)n, "%s%s",
				(n > 0) ? "," : "", antStyleDefs[i].key);
		}

		s.ctx->jer_log(s.ctx,
			"[antfarm] ready: interval %ds, styles %s, lead=%d\n",
			s.intervalMs / 1000, styleList, s.leadEnabled);
	}

	return JER_RESULT_CONTINUE;
}

JER_MODULE_ENTRY(jer_module_antfarm_entry)(JERICHO_CONTEXT* ctx)
{
	memset(&s, 0, sizeof(s));
	s.ctx = ctx;
	s.intervalMs = ANTFARM_DEFAULT_INTERVAL * 1000;

	ctx->jer_register_module(ctx,
		"antfarm",
		"Ant Farm Screensaver",
		"0.2.0",
		"REDRIVER2 community",
		"City-observer screensaver: diverse cinematic camera angles touring the whole map, a damped trail cam on traffic, and optional rogue-car chases.",
		"",
		JERICHO_SDK_VERSION);

	ctx->jer_register_hook(ctx, JER_EVENT_BOOT, AntFarmOnBoot, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_GAME_START, AntFarmOnGameStart, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_FRAME, AntFarmOnFrame, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_CAMERA, AntFarmOnCamera, NULL, 100);
	ctx->jer_register_hook(ctx, JER_EVENT_CAR_ENGINE_SOUND, AntFarmOnCarEngineSound, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_PED_INPUT, AntFarmOnPedInput, NULL, 10);
	ctx->jer_register_hook(ctx, JER_EVENT_PAUSE_MENU, AntFarmOnPauseMenu, NULL, 0);
	ctx->jer_register_hook(ctx, JER_EVENT_DRAW_OVERLAY, AntFarmOnDrawOverlay, NULL, 0);

	AntFarmBuildMenu();
	jer_pause_menu_register(&antFarmMenu);

	ctx->jer_log(ctx, "[antfarm] registered (SDK v%d)\n", ctx->sdkVersion);
}