# Cross-city vehicle imports

> **Format reference:** `FORMATS.md` in this folder documents the file layouts
> themselves — the `.LEV` container and its citylumps table, the 4-byte aligned
> segment walk, `LUMP_CAR_MODELS`, `LUMP_PALLET`, the `.LCF`, texture sets vs
> `texture_pages`/`texture_cluts`, the car draw path, and Python recipes to
> re-measure any of it. Read that first for how the bytes are laid out; this file
> is only about the import feature built on top of them.

Design notes for importing another city's vehicles into a level: what the feature
does, how it is wired, what it costs, and where it is honest about its limits.
Line references are into `src_rebuild/Game/`.

## What it does

A resident car slot can take its **geometry** and its **car colours** from a
*different* city's level file instead of the level's own — e.g. Chicago's school
bus driving in a Havana level. No external tool or data export is involved: the
other city's data is already in its `.LEV`.

It is **per slot**: the module names, for each resident slot, the city that slot's
model should come from, so one slot can be foreign while the rest of the level is
untouched. The per-slot city lives in `JER_ARGS_CAR_DATA_SOURCE.modelSource[]`
(`jer_events.h:521`), read back through `GetCarModelSourceCity(slot)`
(`mission.c:334`). `-1` means "the level's own city".

There is a second, level-wide lever: `sourceLevel` (`jer_events.h:518`) names one
city whose `LEVELS\<city>` folder the **loose-file** loaders (`.MDL`/`.COS`/`.DEN`)
read — that is the separate hand-made-car path, kept for a whole-city override
(`GetCarDataFolder`, `cars.c:1066`). It is not what puts a foreign vehicle in the
level; `modelSource[]` is.

## Where a level's car models actually live

Each city's car geometry is in **that city's own level file** — `LEVELS\<CITY>.LEV`
(single-player) or `MLEVELS\<CITY>.LEV` (multiplayer arenas). It is *not* in the
loose `LEVELS\<city>\CARMODEL_*` files: those are only an override the engine
consults when present (`gContentOverride`), and nothing in the tree currently
ships in the name the engine asks for.

So "a car from another city" means reading that city's level file.

## Reading a foreign level file

`InitCarImport` (`models.c:419`) calls `LoadCarImport` (`models.c:336`), which
uses plain stdio — no CD layer is involved on PC. The sequence:

1. `fopen(JerCityPath(city, ...), "rb")`; if that fails, retry with an `M`
   prefix for the multiplayer pool file (`models.c:349-356`). `JerCityPath` is
   the ONE place a city's file is resolved: the city's data root, the path the
   table (or, for a runtime bank, `cities.ini`) holds, and `FS_FixPathSlashes`.
   City order is CHICAGO, HAVANA, VEGAS, RIO, then Driver 1's MIAMI, FRISCO, LA,
   NEWYORK, NEWCASTLE, then any runtime bank (see "City banks" below).
2. `fseek(fp, 8, SEEK_SET)`, then read the 8-int (`4 × XYPAIR`) citylumps table
   (`models.c:362`). See `FORMATS.md` §1 for the table layout and the container
   fact that follows.
3. Take DATA1 from the table (`table[0]` = byte offset, `table[1]` = byte size);
   reject it if the offset is ≤ 0 or the size is ≤ 8 / > 4 MB (`models.c:368-371`).
4. `malloc` the DATA1 size and read it whole with one `fseek`+`fread`
   (`models.c:377-390`).
5. DATA1's body is itself a container, so its segment list starts 8 bytes in
   (`models.c:395`); `FindLumpSegment` (`models.c:253`) walks it using the
   4-byte-alignment rule of `FORMATS.md` §1 ("Walking segments") to find type 28
   (`LUMP_CAR_MODELS`) and type 25 (`LUMP_PALLET`).
6. The car colours come from a **separate** file, `gDataFolder +
   CosmeticFiles[city]` (`models.c:409`), read whole.

The file handle is closed before the walk; only the mallocs survive.

## City banks — an arbitrary car-data source

The nine cities above are *compiled* names: rows of the engine's `LevelNames` /
`LevelFiles` / `CosmeticFiles` tables. A bank of cars that is not one of those
names (a retexture pack, a private car set) can still be an import source — it
is registered at runtime from `JERICHO/CONFIG/cities.ini`:

```ini
[cities]
city_0 = BCCHI, ..\BetterCars\BCCHI.LEV, ..\BetterCars\BCCHI.LCF
```

`city_N` owns city index `11 + N`, the index is fixed for the process, and the paths
are relative to the game's data folder (`..` allowed, so a pack beside `DRIVER2\`
works). A bank is registered only when its `.LEV` is on disk, and the list is
re-scanned before every car list and every level load — install the files and it
appears, delete them and it is gone.

Nothing in carhacks needed a new code path for this: `import = 5:9:10` is the same
policy shape as `import = 5:2:10`. What *did* change is where the answers come from:

- `chkCityAssetsPresent` asks `JerCityRegistered` instead of keeping its own copy of
  the `DRIVER\D1CARS\*.LEV` names; that duplicate table used to be the reason a bank
  the engine could load was still invisible to every menu.
- `chkFillCarTableFromImport` asks `JerCityCarModels(city)` — the bank's own
  `LUMP_CAR_MODELS`, loaded on demand — so a bank's roster is exactly the models it
  carries (a retexture pack that replaces two cars offers two).
- Every list a player can see walks `chkCityCount()` and skips `chkCityRegistered()`
  rows: `CITY_COUNT` is a **capacity** (25 rows), and a configured-but-missing bank
  leaves a hole in the row range.

A sparse pack can also be COMPLETED from its host city's own level file, so the bank
carries the whole host car list: that is `tools/bankfill.py` — see
[`BANKFILL.md`](BANKFILL.md). Full detail, including what a bank's model block must
look like and the traps: [`city-registry.md`](../../../../src_rebuild/Game/C/JERICHO/docs/city-registry.md).

## What the import carries

Four pieces come from the foreign city, each behind a `GetCarImport*` getter:

| Piece | Where | Getter | Consumer |
|---|---|---|---|
| Car geometry (`LUMP_CAR_MODELS`, id 28) | foreign `.LEV` DATA1 | `GetCarImportModels(slot)` (`models.c:475`) | `ProcessCarModelLump` (`models.c:633`) |
| Car colours (`CAR_COSMETICS`) | foreign `<CITY>.LCF` | `GetCarImportCosmetics(slot)` (`models.c:529`) | `ProcessCosmeticsLump` (`cosmetic.c:71`) |
| Car palettes (`LUMP_PALLET`, id 25) | foreign `.LEV` DATA1 | `GetCarImportPallet(&size)` (`models.c:462`) | `ProcessImportedPalette` (`cars.c:1496`) |
| Wheel models (`LUMP_CAR_WHEELS`, id 200) | foreign `.LEV` DATA1 (D1 bakes only) | `GetCarImportWheel(city, kind)` | `DrawCarWheels` (`cars.c`) |

The wheel segment is optional and additive: a Driver 2 level has none, so its
imported cars keep the host's shared wheels. The D1 bake writes the city's
`CLEANWHEEL` / `DAMWHEEL` / `FASTWHEEL` as FT4 models, carries their pages in the
city's own `LUMP_TEXTUREINFO`, and the engine pins them with the car's pages.
`GetCarImportWheel` returns NULL for an absent variant. The renderer always uses
the host level's wheel MESH and takes only the texture set/id and UVs from the
imported model, so a D1 car wears its own wheel texture and palette without
importing a second wheel topology.

**D2 source cities keep the host wheel texture, deliberately.** A D2 city has no
named wheel model: HAVANA's `LUMP_MODELNAMES` is 42 `BASE*` strings and none is
`CLEANWHEEL`/`DAMWHEEL`/`FASTWHEEL`. The host wheel sprite lives on the host
level's car page: CHICAGO CLEAN is set 63/id 28 at UV (192,224)-(255,255) (64x32),
DAM is set 1/id 3 at (128,64)-(223,127) (96x64), and the DAM hubcap is set 0/id 4.
Mapping the host set through `carTpages` (HAVANA 51/10, VEGAS 32/41, RIO 60/55)
does not reproduce the sprite: those crops are different, and RIO/VEGAS CLEAN is
blank. An exact scan of every HAVANA/RIO/VEGAS page found no 64x32 or 64x64 copy
of the host wheel. HAVANA's only named wheel detail is `WHEEL` on set 20 at
(192,64), 64x64, which is different art and has no cross-city equivalent.
Therefore a D2 import logs `no CLEANWHEEL/DAMWHEEL/FASTWHEEL model; using the
host wheel texture` and keeps the host wheel. Do not wire a carTpages-derived
wheel page unless a crop comparison proves it is the wheel sprite.

For geometry, `ProcessCarModelLump` swaps only its **base pointer** (`models.c:642-651`)
— the foreign block has the same layout as the level's own, so the offset-table
walk is unchanged. The foreign bytes are only read during the build:
`GetCarModel`/`buildNewCarFromModel` **copy into the level heap** (`mallocptr`).
The source buffer itself is not freed after the build — see "Cost and lifetime".

## Palette mapping

The imported city's `LUMP_PALLET` is merged with **that city's** texture-set
mapping (`ProcessPalletLumpForCity(lump, size, city)`, `cars.c:1496`), and
`GetCarPalIndex` (`cars.c:1973`) falls back to the imported city's table for a
page the host level does not know — otherwise a foreign vehicle's pages would all
collapse to slot 0 and it would be painted with the **host's** palette.
`ProcessImportedPalette` (`cars.c:1584`) does this right after the level's own
`ProcessPalletLump` (`texture.c:1981-1982`). **The whole mechanism — `carTpages`,
`civ_clut`'s two banks, the row formula, and the CLUT strip — is owned by
`PALETTES.md`** (the byte layout stays in `FORMATS.md` §4).

## Cost and lifetime

The import mallocs and holds the **whole foreign DATA1 region**
(`imp->region`, `models.c:377`) — not just the car-models block it points into
(the block is a sub-range; `FORMATS.md` §1 sizes DATA1, §3 sizes the block) —
plus the foreign `.LCF` (4096 bytes on disk). All of it is held for the **whole
level**: it is freed only when the next level initialises the import again
(`FreeCarImport` at `models.c:424`), or on a failed load. Up to `CITY_COUNT` (**9**) cities' data can be resident at once
(`gCarImports[CITY_COUNT]`, `models.c:260`), one block per imported slot.

A stock level pays nothing: `gCarImportCity` stays `-1` and every `GetCarImport*`
getter answers NULL (`models.c:455-537`).

## The budget: what a SECOND (and third, fourth) city would cost

Measured end-of-run, one line per source city, by
`carhacks/tools/measure_cities.sh` (it reads the engine's own
`cross-city:`/JERICHO-VRAM/JERICHO-HEAP lines; `frames=90`, seed 7). The
`JERICHO-HEAP:` line prints the level heap and the car-poly pool at the end of a
run — main.c's own `malloctab` print is behind `#if DEBUG||PSX`, so a release
build shows it only through that line.

**Per city, held for the whole level (the C heap, `imp->region` + `.LCF`):**

| city | models | car palettes | cosmetics |
|---|---|---|---|
| CHICAGO | 123324 | 15576 | 4096 |
| HAVANA | 131412 | 14792 | 4096 |
| VEGAS | 132252 | 14808 | 4096 |
| RIO | 135688 | 15704 | 4096 |

so **~143–155 KB per city**, 4 cities ≈ 600 KB. On a PC that is nothing, and it is
*not* the wall.

**Per imported car, against a stock level of the same city:** the car build takes
the level heap from ~75 KB free to ~68 KB free and the poly counter from 1900 to
~2230 — i.e. **≈ +6–7 KB of level heap and ≈ +314 car polys per imported car**:

| run | heap used / free | car polys |
|---|---|---|
| HAVANA stock | 795608 / 74724 | 1900 |
| HAVANA + HAVANA m8 | 801796 / 68536 | 2214 |
| HAVANA + RIO m8 | 802156 / 68176 | 2232 |
| VEGAS + CHICAGO m8 | 788532 / 81800 | 2238 |
| CHICAGO + VEGAS m8 | 808252 / 62080 | 2280 |

The level heap (870332 B) has room for ~10 more imported cars, and the poly pool
(`carPolyBuffer`, a **fixed 3200 cap** shared by every built car) for ~4. **Neither
is the wall either.**

**The CLUT column is the wall.** It is the *only* one of the three that is already
full:

| run | CLUT rows used | safe free |
|---|---|---|
| any stock level | 172 | 38 |
| + one imported car | 210–220 | **0 — used to overflow into the level font** |

So the column accepted **one** imported car, and painted over rows 466..511 (the
level font) to do it — the import's rows were force-started at `y=480`, which is
inside the glyphs (`VRAM.md` §3, §6.1). A second city adds a whole second palette
table (~15 KB ≈ 40+ rows) with **no room at all**. That is why **one guest city's
PALETTES per level** is honest — the geometry side holds several cities
(`gCarImports[CITY_COUNT]`), but the palette side did not.

**This is no longer the constraint: the import's CLUTs come from the lower half pool.** Since
the bottom-half work landed, an import's palette rows are taken from the lower half pool's own
column at x960..1023 / rows 512..1023 (`firstFree = JER_VRAM_HALF_Y`), so the base
half's strip is the level's again, rows 466..511 are never written, and the
"no CLUT-safe room" refusal with its `y=480` fallback are deleted. Measured: a
3-city mix uses **28** lower half pool CLUT rows of 512, the strip reads "125 rows used, 85
safe free, no overflow", and the font region is byte-identical to a stock run
(`VRAM.md` §0).

**The cities' PALETTE TABLES needed the same move, and got it separately.** They are
a different path (`ProcessPalletLumpForRows`, which walks the foreign palette lump)
and they stayed on the base `clutpos` when the pin band moved — 32–38 rows per guest
city, landing at **381..448** in a two-guest mashup, which reaches into the CD-icon
band at 433..464 and leaves the strip only 18 free rows. They now take the lower half pool
column too. Measured against a stock run: the base CLUT column's rows 256..465 are
**0 differing texels**, the host's page slots are 0 differing, and the strip is back
to 114–124 rows used / 86–96 free. So more than one guest city's palettes now fit
comfortably; what is still open is the palette VARIANTS a spawned car gets, not room
(`VRAM.md` §7). `tools/hostdiff.py` is the check.

## Failure behaviour

Everything fails soft. If the file, the DATA1 region or the `LUMP_CAR_MODELS`
segment is missing, `LoadCarImport` returns 0 and the level keeps its own
vehicles (`models.c:441-445`, logged as `cross-city: no usable car data in …`).

A slot that asks for a **model the foreign city lacks** keeps the level's own car
too: `GetCarImportModels` returns NULL when the foreign offset table says `-1`
(no such model) or when the damaged/low variants are missing
(`models.c:508-522`), and `ProcessCarModelLump` falls back to its own `lump_ptr`.
It logs why (`models.c:638-640`), because otherwise it just looks like "the model
did not load".

## Traps

- **`-car slot9` = model 11 on a Chicago level crashes during load.** Chicago has
  no model 11 (the model-completeness table is `FORMATS.md` §3). A slot forced to
  a model the city lacks, with no fallback, is left with NULL model pointers —
  the state `CreateDentableCar`'s guard flags (`denting.c:224`, `:237`). The
  carhacks module lists this explicitly (`carhacks.c:33-40`).
- **The special slot ignores the per-city colours.** `car_cosmetics[SPECIAL_CAR_SLOT]`
  is not taken per model — it uses the cache `levelSpecCosmetics[model - 8]`,
  filled once for models 8..12 (`SetupSpecCosmetics`, `cosmetic.c:150-168`).
  `GetCarImportCosmetics()` is therefore consulted *before* either path, so an
  imported slot wears its own city's colours whichever slot it lands in
  (`cosmetic.c:71-78`).
- **Denting stays local.** There is no denting entry anywhere in the lump enum
  (`main.c:82-120`); `LoadCustomCarDentingFromFile` reads loose `.DEN` files
  (`denting.c:25-30`, called at `:454`, `:487`).
  **Decision (documented, not an oversight):** the level loads ONE denting lump, for
  the host level, and `ProcessDentLump` indexes it by `residentCarModels[i]` — a model
  number in the SOURCE city's numbering for an imported slot. So an imported model
  dents as its host slot would: the zones are the host's, applied to the imported
  geometry. Importing the source city's `.DEN` as well (a second lump keyed by the
  import's own model number) is the fix if the dent *shape* ever matters; it does not
  affect colour, which is what the dent-palette bug below was.
- **Denting must not touch the palette or the page.** The damage offset is added to the
  poly's UV words every frame (`plotCarPolyFT3` / `GT3` / `GT3Lit` / `GT3nolight`,
  `cars.c:171-500`). For FT polys it used to be added to the WHOLE `clut_uv0` /
  `tpage_uv1` word, so a dent on a poly whose uv pair sat within 128 of `0xFFFF`
  carried into the CLUT id (or the tpage id) — denting the car changed its *palette*.
  Both words are now masked to their low half before the offset is added, so the carry
  stays inside the uv pair where the dent wants it. This is the "the palette of a
  dented car goes wrong" report.

## Turning it on

In `JERICHO/CONFIG/carhacks.ini` (on by default — `carhacks.c:55`; set it to `0` to
run with the level's own city only):

```
cross_city_vehicles = 1
import = 2:0:10
```

`cross_city_vehicles` gates the config-driven half of the hack. A player's explicit
PICK is not gated by it: choosing a car in the frontend car screen, or in the
in-game `Vehicle Options` picker, is itself the request that imports it (the two
screens offer every city whenever `unlock_extra_vehicles` is on). `import` takes
comma-separated
`slot:city:model` entries (`carimport.c:251-345`) — here, Chicago's school bus
(model 10) into resident slot 2. City numbers are `0` CHICAGO, `1` HAVANA,
`2` VEGAS, `3` RIO (`system.c:130`). Slots 0..4 feed ambient traffic (the model
list is `modelRandomList`, `civ_ai.c:47`), 5.. up to count-2 are spare capacity
that stock levels leave empty, and the last slot (`SPECIAL_CAR_SLOT =
MAX_CAR_RESIDENT_MODELS - 1`, `dr2limits.h:29`, `:34`) is the special slot
(`jer_events.h:512`); several entries may name different cities.

> **Slot 11 is reserved — a footnote for later.** In the 12-resident build,
> `SPECIAL_CAR_SLOT` is **11** (`dr2limits.h:35` → `:40`). It is the engine's
> mission-special slot — the Vegas ambulance and its kin (`cars.c:3311`,
> `jer_events.h:512`). carhacks deliberately never touches it: `CHK_IMPORT_MAX_SLOTS`
> is `11`, i.e. the import pool is slots **0..10**, so a cross-city import can never
> evict whatever the engine puts there. We are keeping it that way on purpose — slot 11
> is the one resident slot with no importer contending for it, so if a feature ever
> wants a dedicated, never-evicted resident car (a scripted special, a boss vehicle,
> a shared ride), slot 11 is the place to put it.

Verified in the log by the size of the block that was actually read — with
`import = 2:0:10` on a **Havana** level:

```
[carhacks] import: slot 2 <- model 10 from CHICAGO
cross-city: car data from CHICAGO (123324 bytes of models, 15576 of car palettes, 4096 of cosmetics)
```

The 123324 is Chicago's car-models block, not Havana's own (which is larger), so
the foreign file really is what got loaded — `FORMATS.md` §3 owns those figures.

## Where this is implemented

- **`models.c`** owns the import: `InitCarImport()` (`:419`), the reader
  `LoadCarImport()` (`:336`), the aligned segment walker `FindLumpSegment()`
  (`:253`), and the getters `GetCarImportCity` / `GetCarImportPallet` /
  `GetCarImportModels` / `GetCarImportCosmetics` (`:455` / `:462` / `:475` / `:529`).
- **`mission.c`** fires `JER_EVENT_CAR_DATA_SOURCE` and calls `InitCarImport` right
  after (`:433-451`), and holds the per-slot city (`GetCarModelSourceCity`, `:334`).
- **`carhacks.c`** is the module: `ChkOnCarDataSource` reads
  `source_city` / `traffic_model` / `traffic_slot` and calls
  `chkImportLoadConfig` for the `import` list. It does not compute anything and does not
  choose the player's car —
  it just writes model numbers and source cities and lets the engine read them.
- **Consumers:** `ProcessCarModelLump` (`models.c:633`), `ProcessCosmeticsLump`
  (`cosmetic.c:71`), `ProcessImportedPalette` (`cars.c:1496`) + `GetCarPalIndex`
  (`cars.c:1933`).

Both `GetCarImportModels` and `GetCarImportCosmetics` answer NULL for every slot
the module did not import from, so a stock level takes exactly its old path.

## Status: geometry and palettes, not yet correct pixels

The import brings a foreign vehicle's **geometry** and its **car
colours/palettes**, and foreign vehicles are now **textured too**. The route, in
order — each step of it earned by a measurement rather than a guess:

1. **Which sets to load** come from the engine's own tables, never from inspecting
   polygons: `carTpages[srcCity][0..5]` for a civilian body, `specTpages[srcCity]`
   for a special one — exactly what `LoadPermanentTPages` does for the host's own
   cars. (A polygon walk was tried first and abandoned: it has to be **bounded**, and
   an earlier note blamed a *compressed* stream and a `PolySizes` entry of 0 "from
   polygon 5 onward" — car polies are not compressed; a zero-size step only appears
   once the walk runs past `num_polys`. `Find_TexID` being marked UNUSED in
   `texture.c` looks like the fossil of someone reaching the same conclusion.)
2. **Where the pages go**: the level's free slot indices, positioned by
   `tpagepos[slot]` — the slot-indexed mapping the spool itself uses
   (`spool.c:1722`). *Not* by the tail loop's `tpage` walk, which starts after the
   perm **and** special pages and is therefore usually already past the 19-entry
   list; every spare slot then shares one position and the last page wins.
3. **Host-owned numbers are re-indexed.** A `texture_set` can only mean one thing at
   a time, and the host city already owns some numbers the source city uses — VEGAS
   uses 54 and 62, which Chicago owns. Those pages load at a free index (110+) and
   the imported car's polys are translated onto it (`CarSetRemap`), armed **per car**
   in `buildNewCarFromModel` so host cars are never affected. Chicago's own set list
   contains 54, so a global remap would have retextured host cars.
4. **The pages are pinned.** They occupy the same VRAM rectangles the engine streams
   region pages into, and a later load pass memsets the slot table — so
   `CarImportPin`, called each frame, re-claims and re-uploads any page that was
   taken. Without it the car samples whatever streamed in over its page, which reads
   as wrong UVs or wrong colours.

## Enforcement, and what was fixed

**Imported pages now have the last word.** Every page upload funnels through
`LoadTPageAndCluts`, so the rule is enforced there: an upload aimed at a VRAM
rectangle an imported page occupies is refused, and the world re-streams elsewhere.
Brutish on purpose — the cost is that a world page meant for that rectangle goes
stale. Inert with no import: nothing is owned, the guard cannot fire, and a stock run
reports the same page state and `civ_clut` checksum as before.

Two later texture defects, both in `buildNewCarFromModel` (see `HACK.md`):

- **GT4 read `texture_pages[pgt4->texture_set]` raw**, while FT3/FT4/GT3 wrapped it in
  `CarSetRemap` — so a re-indexed set's quad sampled the wrong page. Now wrapped.
- **GT3/GT4 resolved their CLUT through the host's `civ_clut` rows**, keyed by the raw
  set. Imported cars now carry a direct CLUT from their own page instead
  (`plotCarGlobals.directClut`), so no host row is touched and the car wears its own
  colours.
- **A civilian import asked for six pages; the level leaves five.** The sixth never
  placed, and an unplaced page keeps the dummy `(960,0)` tpage — inside a live page —
  so the car showed another page's pixels. The import now pulls only the sets the
  model's own polygons name (`CarModelSetCount`/`CarModelSet`, recorded during
  `buildNewCarFromModel`): Havana model 0 in Rio asks for **2**, both place.

The player's car is chosen on the command line (`-car <model>`), not by the module.
Import a vehicle into a spare resident slot and pass its model number:

```
cross_city_vehicles = 1
import = 5:3:9      # RIO model 9 into spare resident slot 5
```

then launch with `-car 9`: the engine spawns the player in the first resident slot
holding model 9 — slot 5, the imported car.

Still open:

- **The thrash meter is the thing to watch.** If `page re-uploads` in the final page
  state grows with the frame count, something is still taking pages back — check the
  two `spool.c` sites first, since they bypass `LoadTPageAndCluts` by design.
- **Run `carhacks/tools/crosscheck.py` (or `carhacks/tools/chk_suite.sh`, which calls it) instead of reading the
  page state by eye.** It asserts the three things the engine's own summary cannot see
  (`carhacks/docs/HACK.md`, "Where an imported page may live now"): an imported page must not
  sit on the world's/scenery's rectangle, must not take a live local car's page, and its
  CLUTs must match the source city's file.
- Visual confirmation stays the user's: the logs prove pages are placed, claimed and
  kept — not that a car looks right. `-vramview` opens a second window showing the
  live VRAM so a page or CLUT can be watched as it changes, `carhacks/tools/cardump.py` renders
  last run's pages under each palette, and `tools/levpalette.py` gives the defaults to
  compare against.

## Seeing the imported cars (the `spawn_imports` lever)

An import fills a **resident model slot** and nothing more: it does not create a
vehicle. So a foreign car is invisible unless you drive it or the engine happens to
roll its slot -- and the engine's roll can never reach slots 5/6:

- traffic picks its model from `modelRandomList` (`civ_ai.c:47`), which names
  0/1/2/4 only;
- `residentCarModels[5]/[6]` (`mission.c:359`) are written and read by nobody;
- carhacks itself never spawns.

A level really can hold three cities' car data and show none of them. This lever is
for looking at them:

    # carhacks.ini
    spawn_imports = 1

With it on, `spawn.c` installs a FRAME hook that fires **once per level**, as soon
as the level is live and the player is in a car (`playerCarId` in range and
`controlType == CONTROL_TYPE_PLAYER` -- the codebase's own "in a game" test). It
Then one car per imported city, in a LINE AHEAD of the player down the road (not
fanned out to the side, where a spawn point's kerb or wall is):

    [carhacks] spawn: CHICAGO model 8 (resident slot 4) in CAR_DATA slot 2, palette 0, 900 ahead - player (24453,30,-497793) car (25353,30,-497794)
    [carhacks] spawn: HAVANA model 9 (resident slot 5) in CAR_DATA slot 3, palette 0, 1800 ahead - player (24453,30,-497793) car (26253,30,-497794)
    [carhacks] spawn: VEGAS model 10 (resident slot 6) in CAR_DATA slot 4, palette 0, 2700 ahead - player (24453,30,-497793) car (27154,30,-497795)
    [carhacks] spawn: 3 imported car(s) placed ahead of the player, 1500 units apart

The recipe is the one cainescrossfire's own opponent spawn already proves
(`ai/opponent.c:518-528,678`): the first `CAR_DATA` whose `controlType` is
`CONTROL_TYPE_NONE`, `InitCar(..., CONTROL_TYPE_CUTSCENE, ...)` at
`CD2_AI_SPAWN_OFFSET`-style steps along the player's FORWARD axis (the matrix's
third column -- `cop_ai.c:426-428` reads the same pair for a point 400 units ahead,
and `handling.c:788` derives `hd.direction` from it). The player's and the car's
world positions are logged, so the line can be checked by hand. The engine's palette
rule applies too -- `0..5` only for a
recolourable body (`0..4`), else `0` -- so a recolourable car gets a distinct colour
and a special body is not mis-tinted. `CONTROL_TYPE_CUTSCENE` is deliberate: nothing
drives the car, so it stays where it is put and can be looked at.

**Two honest limits.** The colours are NOT right yet: the import's CLUTs do come from the
lower half pool now, but a set with no palette row of its own still collapses onto its
city's block base row (PALETTES.md §7), so this lever proves **geometry and placement**,
not pixels. And it is a measurement lever, not a feature.

`tools/chk_all_cities.sh` runs it for every host level, setting `spawn_imports = 1`
and asserting `lumps 3/3, geometry 3/3, spawned 3/3`.

## The full-pool access violation, and what it actually was

`ProcessPalletLumpForRows` faulted (EXCEPTION_ACCESS_VIOLATION, `+0x300`) as soon as a
**recolourable** model (0..4) was imported — the models whose palettes use the `civ_clut`
import bank. `8/9/10/12` are specials and never reach this path, which is why the mashup
was fine until the pool was widened to "any vehicle".

What the dump plus a bounded probe established:

- `clut_number` is read straight out of the lump (`buffPtr[3]`) and used as
  `clutTable[clut_number]` with **no bound at all**. Once the walk desynchronised the
  value came out as `-1593258381`, a wild address — that is the fault.
- The walk (`while (*buffPtr != -1)`) trusted a terminator that is not always inside the
  lump it was handed, and it never consulted `lump_size`.
- `clutStored` grew past the 320 entries `clutSrc` / `clutDone` / `clutTable` hold, so
  the REFERENCE branch's `clut_number < clutStored` could itself index past the table.

All three are bounded now: the walk stops before the lump's end and says so, every index
is checked against the table *and* against what was actually stored, and `clutStored` is
clamped. The reproducer (`CHK_REPRO=1 chk_mashup.sh havana 4 60`) runs to `built 3/3,
spawned 3/3` with no dump.

**Follow-up (2026-10): the "no terminator" line was a false alarm, not a size error.**
A city's lump holds `header_total` inline CLUTs plus the reuse records that reference them,
and ends in a **lone 4-byte `-1`** (not a full 16-byte record — `levpalette.py` measures 4
bytes left over in each city). The walk always consumed the whole lump and read every
record; the summary line proves it (`200 CLUT(s) in the lump … 325 reusing an earlier CLUT`
= 525 records = the entire VEGAS lump). The old guard required 12 bytes of headroom and ran
*before* the terminator test, so it tripped 4 bytes early on every city and printed a false
"mis-sized" while reporting `clutStored` (the inline-CLUT count) as "entries read" — the
source of the "~2.6x stride" misreading. The guard now reads the lone `-1` terminator first
and only then requires the full record, so the false message is gone and the walk ends on
the real terminator.

## Related

The folder override (`GetCarDataFolder()`, driven by
`JER_EVENT_CAR_DATA_SOURCE.sourceLevel`) redirects the **loose-file** loaders only
(`.MDL` / `.COS` / `.DEN`). On its own it cannot produce foreign vehicles, because
there is no loose vehicle data to find. It stays as the hand-made-car path.


## The palette bank, measured (and the one thing a per-city fix must reconcile)

The `civ_clut` import bank is rows 8..15, and `CarPalIndexInCity` handed **every** guest
city the same row base (`CIV_CLUT_IMPORT_ROW`). `CarPalRowReport` (the palette map, see
README) makes what that costs explicit in a three-city mashup:

    palette map - resident slot 0 reads civ_clut rows 8..15 (HAVANA model 8)
    ...                                slot 6 reads civ_clut rows 8..15 (RIO model 12)
    palette map - civ_clut row 14 written by HAVANA
    palette map - civ_clut row 15 written by HAVANA
    palette map - 2 of the import bank's 8 rows written, 0 of them by more than one city

All six imported cars read the same eight rows, and only one city wrote - two rows. The
other two cities' palettes are REFUSED, so their cars read the first city's rows. Note
the direction: the residual colour fault is an **absence**, not a collision, which is why
it shows as "some vehicles" rather than as everything being wrong.

Demand is small: **2 rows per city**. The column has 41-53 rows free, so per-city banks
are not a VRAM budget problem - the gate is simply far stricter than the hardware.

**Resolved: a BLOCK per guest city.** `CarImportBankRow(city)` gives each guest city its
own 8-row block (`CIV_CLUT_IMPORT_ROW + band * CIV_CLUT_BLOCK_ROWS`, with `CIV_CLUT_ROWS`
grown 16 -> 32), and the pin builds `rowNeeded[]` from
`CarPalIndexInCityFor(sPinSet[i], sPinCity[i])` rather than `GetCarPalIndex(sPinSet[i])`.

Two traps, both paid for:

- **A block is 8 rows, not as many as the city fills.** `CarPalIndexInCity` returns
  `i + rowbase` where `i` spans `carTpages[city][0..7]`, so a 2-row band cannot hold
  `rowbase + 6`. The first attempt used 2-row bands and every city uploaded **0 rows** -
  the rows it needed were outside the band, so the filter matched nothing.
- **`GetCarPalIndex` cannot answer "which city owns this page".** It asks each held city
  in order and takes the first hit, which with three cities is simply the first city. That
  was harmless while one city owned one shared block and fatal the moment each city had
  its own: HAVANA uploaded, VEGAS and RIO uploaded 0. `sPinCity` already recorded each
  page's source city, so use it.

**The measured ceiling is 3 guest cities - that is, every city that can BE one** (there are
four cities and the level's own is not a guest). This paragraph used to say 2, and the
reasoning behind that number still holds for the world it was measured in: a city's palettes
cost about **36 column rows**, the CLUT-safe area is 210 rows (256..465) and the level's own
layout took ~157, so two fit, and three ran `clutpos` to 486 - **21 rows into the level font**.
That was before the palette tables moved to the lower half pool (above). Re-measured 2026-10
on a Rio level importing CHICAGO, VEGAS and HAVANA at once: the strip reads **171 rows used,
39 safe free, no overflow**, each guest holds its own civic CLUT rows (`8..15`, `16..23`,
`24..31`), and `cars.c` refuses nobody - no `NO PALETTE BLOCK` line. So
`CIV_CLUT_GUEST_CITIES`, which is `(CIV_CLUT_ROWS - CIV_CLUT_IMPORT_ROW) /
CIV_CLUT_BLOCK_ROWS` = `(32-8)/8` = **3**, is now the honest number rather than
aspirational, and the gate is no longer the column.
