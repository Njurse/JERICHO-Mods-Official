# How car palettes work, end to end

The canonical reference for **where a car's colour comes from**. Read this before
touching anything that resolves a colour, swaps a palette, or reasons about which
`civ_clut` row a set belongs to.

Line references are into `src_rebuild/Game/` and are the real thing as of the
commit that added this file — if a citation has drifted, fix it rather than
trusting it. The **byte layout** of a city's palette file lives in `FORMATS.md`
§4 (it owns the file formats); this file owns the *resolution* — which row, which
CLUT, and where in VRAM.

Everything below is measured off this install's data or read straight from the
engine's own runtime log, not guessed. Where a number is stated, a recipe to
re-measure it is in `FORMATS.md` §7 and in the tools section at the end.

---

## 1. The two tables a car's colour comes out of

A car polygon carries a **`texture_set`** and a **`texture_id`** (both one byte).
They are not addresses; they index two engine arrays that a level fills on load:

```c
u_short texture_pages[128];        // texture.c:95   set index -> VRAM tpage handle
u_short texture_cluts[128][32];    // texture.c:96   set index -> CLUT handle per texture id
u_char  tpageloaded[128];          // texture.c:97   0 = "not loaded" / slot+1 while loaded
```

and a car's *paint* comes out of a third table, `civ_clut`:

```c
u_short civ_clut[CIV_CLUT_ROWS][32][6];   // cars.c:104   [car palette row][texture id][colour slot]
```

with

```c
#define CIV_CLUT_ROWS        32   // cars.h:50   rows 0..7 host level, then one 8-row block per guest city
#define CIV_CLUT_IMPORT_ROW   8   // cars.h:51   the first guest city's block starts here
#define CIV_CLUT_BLOCK_ROWS   8   // cars.h:52   a city's range is carTpages' range
```

**The non-obvious bit.** A GT poly's `clut_uv0` high word is **not** a CLUT id —
it is an **index into `civ_clut`**. `buildNewCarFromModel` computes it and the
draw reads it back:

```
build:  carid = GetCarPalIndex(pgt3->texture_set);                  cars.c:1319
        clut  = (carid - 1) * 6 * 32 + pgt3->texture_id * 6;        cars.c:1320   (= (carid-1)*192 + texid*6)
        cp->clut_uv0 = M_INT_2(clut, uv0);                          cars.c:1326
draw:   pg->pciv_clut[(src->clut_uv0 >> 0x10) + palette]            cars.c:289
```

`pciv_clut` is not `civ_clut`; it is `&civ_clut[1]` (`cars.c:1046`) — i.e. offset
by one **row** (a row is `32*6 = 192` shorts). So

```
pciv_clut[k] = civ_clut_flat[192 + k]
```

and `(carid-1)*192 + texid*6` at `k` lands on `civ_clut_flat[carid*192 + texid*6]`,
i.e. exactly **`civ_clut[carid][texid][palette]`**. That one row offset is why the
`carid` name reads as a 1-based row and why the formula subtracts 1.

Three consequences worth internalising:

- **The row is chosen by `carid` = which of the *city's* eight car pages this set
  is** — see §3. It is not baked into the geometry; it is *computed*, so it can be
  re-pointed by changing which row a page maps to.
- **`texture_cluts` is the base slot.** Slot 0 of a row is filled per frame from
  the page's own CLUTs (`cars.c:1322`, `:1348`), slots 1..5 come from
  `LUMP_PALLET` (§4). A GT poly with `palette = 0` therefore draws the *page's*
  CLUT; `palette = N` draws the N-th paint variant.
- **FT polys differ.** FT3/FT4 emit `clut_uv0` **verbatim** from
  `texture_cluts[set][texid]` (`cars.c:1280`, `:1296`) — for an FT poly the high
  word really *is* a CLUT id, and no `civ_clut` row is read.

The `palette` in `… + palette` is the **car's colour choice**, not the row:
`DrawCarObject` passes `cp->ap.palette` (`cars.c:1887`, `:1913`), and a spawned
civilian picks it as `Random2(0) % 6` (`civ_ai.c:2278`). It selects one of the six
colour slots within the resolved row.

---

## 2. Where the CLUT *ids* in a row come from

`ProcessPalletLump` (`cars.c:1570`) walks the host level's `LUMP_PALLET` and
`ProcessImportedPalette` (`cars.c:1584`) walks an imported city's, both through
`ProcessPalletLumpForCity` (`cars.c:1496`). Per record the engine does one of two
things (`cars.c:1517-1562`):

```c
if (clut_number == -1)                      // the CLUT image follows inline
{
    LoadImage(&clutpos, (u_long*)buffPtr);          // cars.c:1539  upload the 32 bytes into VRAM
    clutValue = GetClut(clutpos.x, clutpos.y);      // cars.c:1542  the id of where it landed
    IncrementClutNum(&clutpos);                     // cars.c:1543  advance the strip cursor
}
else
    clutValue = clutTable[clut_number];             // cars.c:1551  reuse an earlier upload

civ_clut[palidx][texnum][palette + 1] = clutValue;  // cars.c:1560  NOTE: palette + 1
```

So a `LUMP_PALLET` entry carries either a CLUT image (which the engine uploads
into the shared strip and remembers the id of) or a back-reference to one it has
already uploaded. `palidx` is `CarPalIndexInCity(tpageindex, city)` (`cars.c:1555`)
— the **same** row rule the draw uses, which is what keeps writer and reader in
step.

`load_civ_palettes` (`texture.c:742`) is a **no-op** (`return;`) — the palette
area is filled by `LUMP_PALLET` alone.

---

## 3. `carTpages` / `specTpages`: a page number means a different thing per city

Which of the eight rows a page maps to is a **per-city table**. Every city
renumbers its own art onto the same eight slots, so a `texture_set` number is only
meaningful together with the city:

```c
char carTpages[CITY_COUNT][8];    // texture.c:72   [city][palette slot] -> texture_set
char specTpages[CITY_COUNT][12];  // texture.c:37   [city] -> 6 special bodies x 2 pages
```

(`CITY_COUNT` is 11 — CHICAGO/HAVANA/VEGAS/RIO and Driver 1's seven car-data cities —
since the registry grew; these were `[4][…]` literals.)

`CarPalIndexInCity` (`cars.c:1954`) is nothing more than "which of `carTpages[city][0..7]`
equals this set", plus the import bank:

```c
rowbase = (city == GetCarImportCity() && city != GameLevel) ? CIV_CLUT_IMPORT_ROW : 0;  // cars.c:1962
for (i = 0; i < 8; i++)
    if (tpage == carTpages[city][i]) return i + rowbase;                                // cars.c:1964-1968
```

and `GetCarPalIndex` (`cars.c:1973`) is the host's table, falling back to the
imported city's table, then `0`:

```c
idx = CarPalIndexInCity(tpage, GameLevel);      // cars.c:1975
if (idx >= 0) return idx;
idx = CarPalIndexInCity(tpage, GetCarImportCity());   // cars.c:1991  an imported page
return (idx >= 0) ? idx : 0;                    // cars.c:1997  not a car page anywhere
```

Measured car-page sets (from each city's `LUMP_PALLET` `tpageindex` field):

| City | car texture sets |
|---|---|
| CHICAGO | 1, 50, 62, 63, 65 |
| HAVANA | 10, 20, 35, 37, 51 |
| RIO | 55, 57, 58, 60, 68 |
| VEGAS | 17, 32, 41, 54, 62 |

Only **62** is shared (CHICAGO/VEGAS), so `GetCarPalIndex` must check the host
table first or a host car would be repainted with a foreign row.

**A trap that matters for imports:** `LoadPermanentTPages` *overwrites* two of the
host's entries at runtime —

```c
carTpages[GameLevel][6] = page1;   // texture.c:2025  the host's special body's own two pages
carTpages[GameLevel][7] = page2;   // texture.c:2026
```

so slots 6/7 of the host's table are the special car's pages, not `carTpages[]`
entries parsed from data. And a **special** body's pages come from `specTpages`,
which is a *different* table — for a long time `CarPalIndexInCity` only scanned
`carTpages`, so a `specTpages` page was found in neither city and `GetCarPalIndex`
returned **0** — the host's row, which `CarImportPin` then overwrote. **Fixed:**
`CarPalIndexInCity` now scans `specTpages` too and maps the pair onto the bank's last
two rows (`rowbase + 6 + (i & 1)`), which is exactly where the host's own pair sits
(`cars.c:1954-1998`). A set that is in *neither* table still answers 0 — as it does for
a host car — so the pin refuses to write that row and logs it (§5).

---

## 4. The `clutpos` strip: one column, carved in a fixed order

`clutpos` (`texture.c:102`) is a cursor into the **CLUT column at the right of
VRAM**: `x = 960..1023` (four CLUTs per scanline, 16 px each) and `y = 256..511`.
`IncrementClutNum` (`texture.c:125`) advances by one CLUT, wrapping to the next
scanline:

```c
clut->x += 16;
if (clut->x >= 1024) { clut->x = 960; clut->y += 1; }
```

`LoadPermanentTPages` (`texture.c:1935`) fills this column **in this order**, and
each step starts where the previous one stopped:

| # | Step | Where |
|---|---|---|
| 1 | `clutpos` = (960,256) | `texture.c:1962-1965` |
| 2 | two increments, then `fontclutpos = clutpos` | `texture.c:1977-1980` |
| 3 | host car palettes (`ProcessPalletLump`) | `texture.c:1981` |
| 4 | **imported car palettes** (`ProcessImportedPalette`) | `texture.c:1982` |
| 5 | `load_civ_palettes` — no-op | `texture.c:1984` |
| 6 | the level's permanent page CLUTs | `texture.c:1996-2005` |
| 7 | the special body's page CLUTs | `texture.c:2044-2072` |
| 8 | realign x to 960, y++ | `texture.c:2081-2085` |
| 9 | **the streamed-slot band**: `slot_clutpos[i] = clutpos`, then `clutpos.y += 8` per slot | `texture.c:2088-2100` |

So the **streamed slots' CLUT rows begin strictly below everything the level and
the import uploaded**, and each of the 19 texture slots gets an 8-row band. The
`mapclutpos` / `fontclutpos` RECTs (`texture.c:103-104`) share the same column but
are separate cursors.

`slot_clutpos[]` is read back by the streamer when it uploads a region page's
CLUTs: `SendTPage` uses `slot_clutpos[slot]` (`spool.c:491-492`) and
`SpecClutsSpooled` uses `slot_clutpos[specialSlot]` (`spool.c:1712-1713`).

**Why this matters:** the strip is a single 256-row budget shared by the host
palettes, the import's palettes, the level's page CLUTs and the world's streamed
CLUTs. Measured end-of-load `clutpos`: **428 stock, 485 with a Havana->Rio import**
(the import's palettes and page CLUTs consumed 57 of the 256 rows, leaving 27). `CAR_CLUT_IMPORT_LIMIT` is the last row above the level font image
(**465** = `CD2_CLUT_SAFE_LAST`, `cars.h:110-112`; it used to be the literal 476, which
was *inside* the font) and exists only to stop an import walking the cursor into the band the
per-frame pin reserves — past it, `ProcessPalletLumpForCity` reuses the city's
first palette for the remaining entries and logs how many (`cars.c:1532-1536`,
`:1564-1566`). That is a band-aid: the import and the world are competing for one
budget.

> The column's geometry, the whole VRAM budget around it, and the collision it has
> with the level font image are in **`VRAM.md`** — including the measured
> `clutpos.y` for a stock level (428) and with an import (485), and the section of
> `tools/vrammap.py` that prints which claims sit in the import's reserved rows.

---

## 5. The per-frame re-point (the load-time cache is stale)

`buildNewCarFromModel` runs at **load** time and caches slot 0 of each row from
`texture_cluts[set][texid]` (`cars.c:1322`, `:1348`). At that moment an *imported*
page has not been uploaded yet, so `texture_cluts[set]` still holds the dummy
`(960,16)` and the cached id is the dummy's own id (`043c`). The page's real CLUTs
only exist after the import uploads it at draw time, so `CarImportPin`
(`texture.c:1332`) re-points the row:

```c
int row = GetCarPalIndex(sPinSet[i]);                 // texture.c:~1566

if (row < CIV_CLUT_IMPORT_ROW)                        // a HOST row: refuse, and say so
    printInfo("cross-city: pin - set %d resolves to civ_clut row %d (a HOST row): not re-pointing, palette leak avoided\n", ...);
else
    for (j = 0; j < 32; j++)
        civ_clut[row][j][0] = texture_cluts[sPinIndex[i]][j];
```

That single line is the load-time/draw-time seam. It is safe while `row` is one of
the import's own rows (8..15) — and it is a **leak** when `row` comes back 0 for a
special-body import (§3), because row 0 is the host's.

The import's own CLUT rows come from the **lower half pool's** own cursor
(`JerLowerPoolClutCursor`, `texture.c`), which starts at `JER_VRAM_HALF_Y` (**512**) and
walks the lower half of the CLUT column, so the imported *pages*' CLUTs never land in the
level's (base-half) band. The old `sPinClutCursor` and its `max(clutpos.y + 4, 480)` start
belonged to the base-half band that predates the pool.

---

## 6. The check that is supposed to catch all this — and doesn't

`LoadPermanentTPages` hashes `civ_clut` into the log as the cross-city invariant
(`texture.c:2110-2117`):

```c
for (i = 0; i < CIV_CLUT_ROWS * 32 * 6; i++)
    clutSum = clutSum * 31 + ((u_short*)civ_clut)[i];
printInfo("cross-city: level page state - slotsused=%d nperms=%d nspecpages=%d tpage=(%d,%d) clutpos=(%d,%d) civclut=%08x\n", ...);
```

It now prints **two** sums: `civclut` for rows 0..7 (the HOST's rows — the number that
means the same thing across builds, so a stock run must print the same value before and
after a change) and `civclut16` for all `CIV_CLUT_ROWS` rows (so the import bank is
visible too, comparable only within one build). What neither does:

A useful run proves three things instead:

1. no imported set resolves into a *host* `civ_clut` row;
2. no imported page occupies a VRAM rectangle the world streams into;
3. a world set's `texture_pages[]` / `texture_cluts[]` agree with the pixels
   actually at its rectangle (see `carhacks/tools/vramdump.py`).

---

## 7. The tools

| what | how |
|---|---|
| what a city's car palettes *should* look like | `tools/levpalette.py <CITY>.LEV` — reads `LUMP_PALLET` and writes a swatch sheet per city + the raw rows (`--out DIR`) |
| what a car's texture looks like under **each** of its palettes, from the **last run** | `carhacks/tools/cardump.py` — takes the run's `vram_dump.tga` (`JERICHO_DUMPVRAM=1`) plus the run's log, and blits each imported car's texture page(s) through each palette to one PNG per palette |
| whether a run's palettes/pages actually behaved | `carhacks/tools/crosscheck.py <run text> [--tga vram_dump.tga] [--lev SRC.LEV]` — asserts the invariants in §6, now INV1–INV4 (exit 0 held / 1 violated / 2 no import) |
| what is actually in VRAM right now | `-vramview [frames]` (live window) / `carhacks/tools/vramdump.py vram_dump.tga --png out.png` |
| which sets/rows a level uses | the engine's own lines: `cross-city: level page state …`, `cross-city: %s set %d -> index %d …`, `cross-city: pinned set %d index %d: slot=%d, rect=(%d,%d) …` |
| which car bakes a fallback row, and for which set | `cross-city: palette - slot %d (%s model %d) sets [ … ] have no %s palette row -> baking base row %d` — always on, one line per built car, deduped per slot by the set list. This is the line the open palette item needed: it names the car and the exact set from the log alone (`cars.c`, `PalBakeSetsDiag`). |

The exporter tools are how a fix is shown *visually*: `levpalette.py` gives the
expected colours offline, `cardump.py` gives what the last run actually drew under
each palette, and the two are meant to be compared side by side. `crosscheck.py` is
how it is shown *measurably* — it is the check §6 says the engine's own summary is
missing.

> **Which log file?** The session log is `<appName>.log`, and this build's app name is
> JERICHO (`PsyX_Initialise("JERICHO", …)`, `PsyX_main.cpp:380`), so the live file is
> `JERICHO.log`. A stale `REDRIVER2.log` from an older build name may still be in the
> folder — do not grep it. Capturing the run's stdout works just as well (and is what
> `chk_suite.sh` does) because `printInfo` writes both.

---

## 8. Gotchas, collected

- A GT `clut_uv0` high word is a `civ_clut` **index** (`(carid-1)*192 + texid*6`),
  not a CLUT id; an FT one **is** a CLUT id. `pciv_clut = &civ_clut[1]` (one
  *row*) makes the GT formula land on `civ_clut[carid][texid][palette]`.
- `LUMP_PALLET` writes `palette + 1`; slot 0 of a row is the page's own CLUT and is
  refilled per frame (`cars.c:1322`, `:1348`, `texture.c:1511`).
- `carTpages[GameLevel][6..7]` are **overwritten** with the special body's pages at
  runtime (`texture.c:2025-2026`).
- A `specTpages` page is not in `carTpages` — that used to make `GetCarPalIndex`
  answer 0 (the host's row); it is now scanned and mapped onto the bank's last two rows.
- A set in **neither** table answers row 0, exactly as a host car's does — the pin
  refuses to *write* that row and logs it.
- Two sets imported in one load saw `110` free for both and both took it, collapsing a
  car's two pages onto one index; `FindFreeSetIndex` now reserves what it hands out.
- `ProcessPalletLumpForCity` for an import uploads into the **shared** `clutpos`
  strip (the world's streamed CLUTs are carved from the same column) and can be
  truncated by `CAR_CLUT_IMPORT_LIMIT`.
- `JerichoMakeClutRow` (`texture.c:153`, team/ped dye) allocates rows from the same
  runtime `clutpos` cursor (`texture.c:342-345`), guarded only by `clutpos.y > 511`.
- The cross-city invariant hashes `civ_clut` (all rows now) and says nothing about VRAM.
- The session log is `JERICHO.log` in this build, **not `REDRIVER2.log`**; a stale
  `REDRIVER2.log` can sit in the same folder.

## History — the fix log (read as the trail, not the state)

The dated sections below are the development history: each records what was measured
and fixed at that point, some of which a later section supersedes. The **current** open
state is `VRAM.md` §7.3 (the one thing still imperfect is a spawned imported car's colour
*variants*); the running summary of what the code does *today* is §1–§8 above. Read the
trail only when a "why" needs the original measurement.

## The import's model rows and its lump rows are disjoint (measured 2026-10-01)

`civ_clut` rows are now instrumented with the colour columns each row actually got
(`CivClutRowMaxSlot`/`CivClutTexMaxSlot`, recorded at the one write site in
`ProcessPalletLumpForRows`, printed by `CarPalRowReport` as "has colour variants" vs
"slot 0 only"). That census and a per-city row comparison immediately found a gap the
row filter cannot explain:

```
civ_clut 8..15 (HAVANA): uploading for 2 of its block's 8 rows
  row 14: READ by the built model, but 0 of the lump's entries map to it
  row 15: READ by the built model, but 0 of the lump's entries map to it
  rows  8..13: the lump holds 30/120/125/125/140 entries the model does NOT read
```

- The **built model** baked rows `base+6`/`base+7` (14/15) for its special-body pages —
  that is the `specTpages` scan in `CarPalIndexInCity`, which maps a special page onto
  the bank's last two rows.
- The **lump** holds no entry whose `tpageindex` resolves there. Its entries resolve to
  rows `base..base+5` (8..13) via `carTpages`, which the model does not read.
- So the row filter drops every one of them (`wanted=0`), the two rows the model *does*
  read stay empty, and those polys draw colourless. **Uploading the whole block would not
  help** — the data for rows 14/15 is not in the lump at all.

Consequence for the earlier plan: "stop row-filtering the upload" is *not* the fix for
this symptom. The disagreement is between how the model *maps* a page to a row
(`specTpages` → the bank's last two) and how the lump's entries map (via `carTpages` →
`base..base+5`). Either the model should read the rows the lump fills, or the special
pair needs its own lump. A `cross-city: ... those polys draw colourless` line is now
emitted per row so this stays visible instead of being rediscovered as "some cars still
look wrong".

### The whole-block upload, and the three rows no city can fill (same day)

Done: the mask now marks **every row of every held city's block**
(`CarImportPaletteBlockBase`, texture.c), not just the rows the built models named. An
as-needed import holds only the cities it took a car from, and a block is 8 of the
column's 32 rows, so the whole block is affordable — and it is what makes a spawned car's
**colour variant** reachable, because a variant is a *column* within a row and `civ_ai`
picks `ap.palette` 0..5 on spawn, not at build time.

Measured on a three-city mashup (HAVANA/VEGAS/RIO into CHICAGO), before → after:

| | before | after |
|---|---|---|
| rows uploaded per city | 2 of 8 | **8 of 8** |
| rows offering colour variants | 0 | **10 of 24** |
| per-slot block | — | slot 4 → 8..15, slot 5 → 16..23, slot 6 → 24..31 |

The pattern in what stays empty is now unmistakable: **rows `base+1`, `base+6` and
`base+7` are empty for every city**, and `base+6`/`base+7` are exactly the special-body
pair the `specTpages` scan maps onto. So the remaining colourless polys are not a space
problem and not a filter problem — the lump has no entry resolving to those three rows,
while 30..140 of its entries resolve to the rows beside them. Either the model should read
the rows the lump fills, or those pages need their own lump; that is the open fork.

(A diagnostic detail fixed here: the palette map reported the HOST city's own car as
reading the import bank, because `CarImportBankRow` answers that for a city with no band.
The host reads rows 0..7 and the map now says so.)

### The draw-time clamp, and what it did not prove

`CarClutVariant` (cars.c) bounds the column the draw reads: it decodes the row from the GT
clut index (`clut_uv0 >> 16` is `(carid-1)*192 + texid*6`, `pg->pciv_clut` is
`&civ_clut[1]`), and if that row is in the import bank it clamps the spawned variant to
`CivClutTexMaxSlot(row, texid)`. Slot 0 is the page's own CLUT and is always refilled, so 0
is always a valid answer. Rows 0..7 are left alone deliberately — those are the host's own
car palettes, filled by a path that records no coverage, and clamping them would pin every
stock car to one colour.

`CarPalRowReport` counts the clamps, and on a stock level the count is meaningless because
the report never runs without an import — so the invariant "the clamp never touches the
host" rests on the early return for `row < CIV_CLUT_IMPORT_ROW`, not on a measurement.

**The clamp did not fire in any run measured: 0 over 400 frames of a three-city mashup.**
The rows that *do* have no coverage (base+1, base+6, base+7) belong to models that were not
drawn in that window with a variant above 0. So this is a guard against the case where a
spawned car picks a column its row does not hold — it is not a demonstrated fix, and a run
that exercises those models (a special body spawned and respawning) is what would prove it.

## The empty column IS reached: a draw-time fallback (measured 2026-10-02)

The section above left the clamp unproven ("a run that exercises those models is what would
prove it"). It is now measured, and the guard was in the wrong place.

`CarClutVariant` deliberately does not touch the HOST rows (0..7), so a stock car whose
spawned `ap.palette` names a column the city's lump never filled reads
`civ_clut[..][..][slot] == 0`. A CLUT word of 0 is `GetClut(0,0)` — **the display
framebuffer** — so the car's body polys paint themselves with whatever is on screen, i.e.
the car is invisible, while the FT/B polys (underside, wheel arcs, mirrors) draw. That is
exactly the "the wheel wells and side mirrors render but not the rest of the car" report.

Measured with `JERICHO_DIAG_CARDRAW=1` (a per-model page/CLUT census in `DrawCarObject`), on
an antfarm-only run of a rainy dusk Chicago:

```
car=6 model=2 pal=3 polys=238 pg 000e:210/0000>473f 000b:28/00af>00af ...
car=7 model=1 pal=4 polys=60  pg 001b:58 /0000>4ebf 000b:2 /421d>421d ...
```

The body group's raw CLUT is `0000` and resolves to a real CLUT; the second group's is
already valid and is left alone.

The fix is `CarClutLookup(pg, ci, palette)` (cars.c), now used by the three GT3 plotters in
place of the bare `pciv_clut[ci + CarClutVariant(...)]`: if the looked-up CLUT is 0 it falls
back to the group's own slot 0 (`pciv_clut[ci - 1 .. ci + 4]`, "the page's own CLUT, always
refilled"), and only if the whole group is empty does it leave 0. A block where the palette
is valid is unchanged, so nothing that already drew correctly moves.

Measured after the fix: **0 body groups left on the framebuffer**, and the fallback fired
**64500** times over one 700-frame rainy-dusk run — so the empty column is not a corner
case, it is the common one for palettes above what a city's lump names.

(Note: the host rows are still not clamped — that would pin every stock car to one colour.
The fallback is draw-time only, and only when the column is empty.)

## REGRESSION (2026-09-30 → 2026-10-02): the host palette walk read ZERO entries

After the fix above the cars were visible but **every vehicle of a model was the same
colour**. That is a second, older break, and it is the more serious one.

`ProcessPalletLumpForRows` gained a bounds guard on 2026-09-30 (`7def90605`) to stop a walk
that ran past the end of a deferred IMPORT lump and read heap as entry fields:

`if ((char*)buffPtr + 12 > (char*)lump_ptr + lump_size) break;`

But the LEVEL's own lump has always been passed with **size 0** - stock has called
`ProcessPalletLump(palette_lump, 0)` (texture.c) since 2020, and that walk is bounded by the
lump's own header count and its `-1` terminator, not by a size. With size 0 the guard tripped
on the first iteration, so the host walk processed **nothing**:

```
cross-city: CHICAGO palettes: 219 CLUT(s) in the lump, 0 row(s) taken (rows 256 -> 256)
cross-city: CHICAGO palettes: no terminator within 0 bytes (0 entries read) - the lump is mis-sized; stopping
```

`civ_clut`'s per-palette columns were therefore never filled, and every car of a model drew
from the one CLUT the model build had put in slot 0. Measured with `JERICHO_DIAG_PAL=1`
(dumps the lump entries): the lump holds **palette fields 0..4 for every (row, texnum)**
group, so the variety was there all along - we simply stopped reading it.

**Fix:** bound the walk by whichever limit the caller actually supplied. `lump_size > 0`
(a deferred import) keeps the exact byte check; `lump_size == 0` (the level's own lump) is
bounded by the header count (`entriesRead >= total_cluts`). Measured after:

```
CHICAGO palettes: 219 CLUT(s) in the lump, 26 row(s) taken (rows 256 -> 282), 116 reusing ...
CARDRAW  model=0 ci=264 raw[ci-1..ci+5] 437f 573c 433f 437c 437d 437e 437f
         -> res0..5 573c 433f 437c 437d 437e 437f      (six DISTINCT colours)
```

Verified antfarm-only across chicago/havana/lasvegas/rio: PASS, no new dump, 15-30 rows
taken per city (the font at 466 is untouched) and the lower-half pool still fully reserved.

**Still open (unchanged, and NOT this bug):** some models still resolve to a single colour -
their groups are the special-body pages whose rows the lump's entries do not reach. That is
the earlier fork: either the model should read the rows the lump fills, or those pages need
their own lump. The draw-time fallback keeps them *visible* rather than framebuffered.

**Diagnostics added for the next reader:** `JERICHO_DIAG_PAL=1` (the lump's entries, with the
computed row/texnum/palette) and `JERICHO_DIAG_CARDRAW=1` (per-model page/CLUT census and the
six resolved palette CLUTs, in `DrawCarObject`). Both off by default.

---

## 7. An empty row is left EMPTY (the fabricated alias is gone)

`ProcessImportedPaletteRows` used to FABRICATE a row a built model reads but the city's lump
cannot fill: it copied the first row in the block that HAS data into every empty needed row,
six colour columns wholesale **including slot 0**. That was `ad62815f`, added for "several
corrupted palettes" on an imported special.

It was the wrong trade, and it produced the opposite of its intent. Slot 0 is the poly's own
page CLUT - written at build from `texture_cluts[set][texid]` and re-pointed by
`CarImportPin` - and `CarClutLookup` accepts ANY non-zero slot. So a copied FOREIGN CLUT was
drawn as if it were this page's paint: "some panels correct, most wrong, on cars from every
city".

The row is now left empty and reported. Empty is already handled end to end:

* `CarImportPin` fills slot 0 with the poly's OWN page CLUT;
* `CarClutVariant` clamps a spawned palette to the row's real coverage (none -> slot 0);
* `CarClutLookup` falls back to the group's slot 0, never to the framebuffer.

This is only reachable because a bake never numbers a car page 0 any more (see
`d1cars/docs/DRIVER1.md`): with the sentinel set back, the pin takes every set a model names,
so slot 0 is always filled. Verified: a RIO level importing CHICAGO model 8 passes all three
`crosscheck.py` invariants, INV3 included (its CLUT rows still MATCH `CHICAGO.LEV`), and
`cardump.py` reports those pages as "only the page's own CLUT applies (no leak)".

**Still open (the "extra panels" corruption).** A guest city gets EIGHT `civ_clut` rows
(`CIV_CLUT_BLOCK_ROWS`) and `CarPalIndexInCity` resolves a set to a row by searching
`carTpages[city][0..7]`. A Driver 1 city bakes 11-13 sets (MIAMI 11, NEWYORK 13) across its
cars, so the sets past the eighth resolve to `-1` and `CarPalIndexForBuild` sends them to the
block base row - those panels draw their own PINNED page but the FIRST page's palette. That is
the visible "minor corruption on vehicles with extra panels" (VEGAS ambulance, large SUVs,
long cars). Two candidate fixes, neither tried: fill `carTpages`' unused zero slots with the
city's remaining sets (D1 cities use only 5 of the 8 today, so it recovers three), or assign
rows per MODEL at build time from `CarModelSet`/`CarModelSetCount` instead of from the
city-wide table. The second is the real fix, because 8 rows cannot hold 13 sets.

### The lump's own coverage decides which case you have (measured 2026-10-11)

An empty row is not one thing, and the difference decides whether anything should change:

* **A row whose SET the lump never mentions is a FACT.** Measured on CHICAGO: its
  `LUMP_PALLET` carries palettes only for page sets **{1, 50, 62, 63, 65}**
  (`levpalette.py`, one line per set), while its page table is
  `[1,58,65,62,50,63,54,55]`. So sets **58, 54, 55** have no palette data *anywhere*,
  and rows base+1 / base+6 / base+7 stay on slot 0. The imported special (CHICAGO
  model 8) is built from sets {54, 55, 1}, so two of its three pages legitimately
  keep the page's own CLUT. That is the honest answer, not a mapping bug — a guest's
  sets are simply not always laid out the way its page table's order implies.
  `crosscheck.py` reports it as a **WARN**, never a FAIL.
* **A set with NO row of its own is a DEFECT** — the "extra panels" case above:
  several sets share the block base row, so those panels wear the first page's
  palette. `crosscheck.py` **INV4** fails on exactly this
  (`palette - slot N (CITY) sets [...] have no CITY palette row -> baking base row M`),
  and on any `civ_clut` row two cities both wrote.

**INV2 is a hard FAIL now too.** The pin refuses to re-point a HOST row and logs it;
that refusal *is* the violation (the guard is what stops an import repainting a local
car), so `crosscheck.py` no longer files it as a note.

### The bank holds THREE guest cities, and Driver 1 has seven of them (measured 2026-10-12)

The other half of the same problem, and the worse half: it takes out whole cities rather
than panels. `CIV_CLUT_ROWS` is 32 (`cars.h:72`), `CIV_CLUT_IMPORT_ROW` is 8 and a guest
city's block is `CIV_CLUT_BLOCK_ROWS` 8, so `CIV_CLUT_GUEST_CITIES` (`cars.c:142`) is
**3**. Past that `CarImportBankRow` returns -1 and the import refuses the city out loud:

```
cross-city: FRISCO palettes: REFUSED - civ_clut affords 3 guest cities and the others
            have them (rows 8..31 are the import bank)
cross-city: palette - slot 5 (FRISCO model 8) sets [6, 7] have no FRISCO palette row
            -> baking base row 0
```

**`base row 0` is the tell that the whole city lost its bank.** Every city that has a real
block reports that block's own base — 8, 16, 24 for MIAMI, FRISCO, LA — while a **0** means
there is no block at all, so every row the city's cars name resolves to the HOST's first
row. That is not a panel wearing the wrong colour; it is a city's entire car list wearing
the level's colours.

Driver 1 has seven car-data cities (MIAMI 4, FRISCO 5, LA 6, NEWYORK 7, NEWCASTLE 8, IVIEW 9, TRAIN 10 — the
same seven `DRIVER\D1CARS\<CITY>.LEV` files `carimport.c` loads), so the bank is already
oversubscribed. Measured when there were five (2026-10-12): importing all five at once
refused **FRISCO and LA**, and every page check in the same run still reads `N of N polys
resolve to a pinned imported page` — the cars load perfectly and come out the wrong colour.
This is what "some of the Driver 1 cars have broken palettes" is: the more cities are
mixed, the more of them lose their colours at once. IVIEW and TRAIN make the pressure
worse — mixing more than three guest cities is still where colours are lost.

**The lump has the rows; the table is what cannot reach them.** For MIAMI:

* its `LUMP_PALLET` carries `total_cluts=68` and 68 records covering texture ids
  **0..12** (four palette slots each) — including ids 6 and 7, the sets the log says have
  "no MIAMI palette row";
* its `carTpages` is **`[1,2,3,0,0,0,4,5]`** — eight entries, three of them zero, so the
  table names five sets and leaves three slots unused.

So the extra-panel case is not missing data either. `CarPalIndexInCityFor` searches that
eight-entry table, answers -1 for a set it does not list, and `CarPalIndexForBuild` sends
it to the block base. The rows exist in the lump and the table cannot address them — and
the same eight-row table is what fixes the bank at three cities, because the column is
carved into fixed 8-row blocks whether a city fills them or not.

**The design (implemented 2026-10-15).** A guest city's `set → civ_clut row` mapping is a
**dynamic per-`(city, set)` dictionary** fed from a shared pool of rows `8..31`, replacing
the fixed 8-entry `carTpages[city][0..7]` scan for guests. The host level keeps the table
scan (rows `0..7`).

- **Measured this pass** (`JERICHO_DIAG_PALBAKE=1`): a baked Driver 1 model names **2–4
  distinct `texture_set`s**, and the sets past the five live `carTpages` entries
  (`6..13`) resolve to `-1` → the block base row — so those panels wear the first page's
  palette (the "extra panels" corruption). A 4th/5th D1 city is refused a block entirely
  (FRISCO/LA → every set collapses to host rows `0/1/2`).
- **Why per-`(city,set)`, not per-model:** two models of one city that share a set read the
  *same* `(set, texnum)` palette (the lump keys by set), so they should share one row.
  Sharing is correct and uses fewer rows than a per-car run.
- **Allocation:** `CarAllocSetRow(set, city)` runs from the build path
  (`CarPalIndexForBuild`) the first time a built model names that set; it takes the next
  free row from `sPoolNextRow` (starts at `CIV_CLUT_IMPORT_ROW`). `CarPalIndexInCity` is
  **lookup-only** for guests, so the deferred lump walk and the pin never allocate a row
  nobody reads.
- **Lifetime:** rows are sticky per `(city, set)` while a live car names that set. When the
  last live model naming it goes away, `CarImportReclaimRows` gives the row back to the
  pool and forgets everything keyed by it — contents, upload flag, colour-column coverage
  and the bake/collision census (`CarImportPaletteRowForget`) — so the next owner re-uploads
  instead of wearing the previous car's palette. The deferred palette lump is KEPT after an
  upload (it used to be NULLed, which made the forget a no-op); it is released at level
  reset by `CarImportPaletteReset`.
- **Wheel palette rows (sets 125..127):** their row mapping and contents are reclaimed like
  any other, but the VRAM CLUT id cached in `sWheelPalClut[city][hub]` deliberately survives
  a switch. It is allocated from the lower pool's write-once CLUT cursor region
  (`JerLowerPoolClutCursor` / `JerLowerPoolClutAdvance`), which nothing hands back or
  reuses, so the id stays valid for the next car of that city. Clearing it would make every
  switch burn a fresh CLUT row and walk the column to its end.
- **Capacity:** a 5-city mix is 5 slots × 2–4 sets ≈ **10–20 rows ≤ 24**. The worst case
  (7 slots × 4 = 28) overruns the pool, so exhaustion refuses cleanly: the set falls back
  to the city's first allocated row, or `CIV_CLUT_IMPORT_ROW` — never below row 8, so no
  host-row leak.
- **Collision-free by construction:** a set only ever takes a row that no other live
  `(city,set)` owns (`CarRowInUse`), and a reclaimed row is handed out only after it has
  been forgotten, so two live sets cannot share a row; the exit report's `COLLISION` line
  becomes a canary rather than a thing that fires.
- **The extra-panels fix is a consequence:** set 6 (and 7, 8, …) get a row of their own,
  so `CarImportPin` re-points that row's slot 0 to the set's *own* page CLUT and the panel
  stops wearing the first page's palette. Sets whose lump carries colour-variant data still
  get those rows filled; sets with none keep slot 0 (the page's own CLUT), which is already
  handled end to end.

**Readiness is a gate, not a hope.** `JerCarSlotState` is the one decision on whether a slot
can be handed out (cars.h). For an imported slot it now requires more than a built mesh:
every set the model names must have a live pin for that city (`CarPinRecord`) and a mapped
import-bank `civ_clut` row (`CarAllocSetRow`), otherwise it answers `JER_CAR_SLOT_NOT_READY`.
The draw path is one step stricter (`JerCarSlotDrawable`, after `CarImportPin`): the row must
be uploaded and the page placed. Traffic/player spawn paths already consult
`JerCarSlotUsable`, so they cannot choose an unready slot; a car already on the road shows
mp's host-car-1 grey stand-in (extended to single-player) until its slot is drawable, then
repoints back. One log line per NOT_READY transition names the slot, city, model and sets.

**The dump that explains a failure** is `JERICHO_DIAG_SLOT_MAP=1`: on a readiness transition
and at exit, every imported resident slot prints `set -> civ_clut row -> pinned page index`
with `placed` (pool/world/unplaced), `row uploaded/NOT uploaded` and `no live pin` detail.
The per-slot `slotmap - ... NOT READY` line and the exit
`slotmap: N body set(s) ... are NOT READY` summary print even without the lever, which is
what the rig fails on.

**The rig that keeps this honest** is `tools/chk_d1_cities.sh`: nothing else in the tree
enumerates cities past 3, so a Driver 1 defect could not have been seen at all. It imports
cities 4–11 (including the Euro-43 beta, city 11) and fails on a short page check, a refused
block, a palette gap *or* a slotmap miss, which is how the five-city case above was found.
