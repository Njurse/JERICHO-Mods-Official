# dediserver — a headless dedicated server for the mp mod

A real multiplayer session with **no game window**. It accepts players, hands out
ids, relays car-state and chat, **broadcasts the roster** (so every client sees who
else is in the match, on the cadence a real host uses), answers `PING` with `PONG`,
and beacons on UDP so the in-game LAN browser lists it. Use it to leave a host up for
a while, or to give a client something to join on a machine that has no game build at
all — the server is pure Python and never loads the game.

    JERICHO\MODS\mp\tools\mp_dedi.bat                 # from a checkout, the quick way
    python JERICHO/MODS/mp/tools/servers/dediserver/dediserver.py

Then join it from anywhere:

    JERICHO_dev.exe -nointro -nofmv -join 127.0.0.1
    JERICHO_dev.exe -nointro -nofmv -join 127.0.0.1:1400

## The console

Run it in a shell and it has a command line; `help` lists what it takes. When stdin
is not a terminal (a service, a container without `-it`, a captured run) it says so
once and stays out of the way — `JER_CONSOLE=on` forces it on, which is how a
supervisor (or a test) can pipe commands in.

| command | what it does |
| --- | --- |
| `status` | name, session port, city, gamemode, rules (readable), players, uptime, beacon, master |
| `list` | connected players: id, name, address, how long connected |
| `say <text>` | one line into every player's console, prefixed `SERVER:` |
| `kick <id> [reason]` | drop a player — the protocol's own kick message; with a reason they see "Kicked by admin: <reason>" (cut to 63 bytes) and chat is told |
| `beacon [on|off]` | the LAN beacon's state, or turn it off (a LAN you do not want to appear on) |
| `master` | discovery registration: the URL, whether registered, what last happened |
| `stop` | close the server (unregisters from the master, closes players) |

## Options

```
--config FILE        JSON config (default: dediserver.json beside this script; created
                     from dediserver.example.json on the first start if missing)
--port N             TCP session port (default 1318)
--name "..."         name shown in the browser / registered with the master
--city N             GameLevel the clients should load (0..3)
--gamemode N
--max-players N      slots 1..N-1 are given to clients (0 belongs to the server)
--beacon / --no-beacon
--beacon-ms N        beacon cadence (default 1000)
--idle-drop S        seconds of real silence that drop a client (0 = never)
--cops / --no-cops   police cars spawn (default: on)
--cop-difficulty N   0..2 (default 1)
--cop-immunity       cops exist but never come after anyone
--invulnerable       cars take no damage
--log-level debug|info|warning|error
--log-file FILE      also append logs to FILE
--master URL         register with a master discovery service; http://host:8100, or a
                     bare host (the port defaults to the master's 8100)
--master-name "..."  name to register (default: --name)
--master-interval S  heartbeat cadence (default 20; keep well under the master's ttl)
--advertise-host H   the address PLAYERS reach us on, if that is not the address the
                     master sees. Behind NAT this is your public IP or hostname; the
                     listing is unusable without it
--advertise-port N   the public port players dial, when the router REMAPS ours
                     (0 = --port). Only needed when the forward is not 1:1
```

The session rules are readable keys in `dediserver.json`: `"cops": true`,
`"cop_difficulty": 1`, `"cop_immunity": false`, `"invulnerable": false` (the same
defaults as an in-game host). They are packed for the wire exactly like the game's
`MP_RULES_PACK`. An older config with only the packed `"rules"` int still works (the
server logs a deprecation line); note `"rules": 0` means cops OFF, so replace it with
the readable keys to get cops.

CLI flags override the config file. The config file is optional — with none, the
built-in defaults are used.

## `dediserver.json`

`dediserver.json` is **yours and not tracked by git**: the repo and the release
packages ship `dediserver.example.json`, and the server copies it to
`dediserver.json` the first time it starts without one (it never overwrites an
existing file). Updates and `git pull` therefore leave your settings alone.

> **Upgrading a git checkout from before this change:** pulling the commit that
> untracks the file deletes an *unmodified* tracked `dediserver.json`, and a
> modified one blocks the checkout. Back it up first:
> `cp dediserver.json ~/dediserver.json.bak && git checkout -- dediserver.json && git checkout GETRDUN-JERICHO && git pull && cp ~/dediserver.json.bak dediserver.json`
> (run in this folder; afterwards `git status` does not list it -- it is ignored).

```jsonc
{
  "port": 1318,
  "name": "Dedicated",
  "city": 0,
  "gamemode": 0,
  "max_players": 16,        // 16 is the protocol cap (MP_MAX_PLAYERS); slot 0 is the server
  "motd": "Welcome to JERICHO - drive safe, mind the traffic.",
                            // said to each joiner as a SERVER chat line. One line only:
                            // the chat field holds 95 characters (a longer greeting
                            // WRAPS on the client's console). "" sends nothing.
  "motd_color": "#7FE8FF",  // that line's colour, "#RRGGBB"
  "beacon": true,
  "beacon_ms": 1000,
  "idle_drop_s": 30.0,      // 0 = never drop a silent client
  "live": true,             // advertise as a live match (the level is always up)
  "mod_check": 0,           // 0 = admit anyone, 1 = the enabled mod IDS must match,
                            // 2 = ids AND versions (see "Mod lists" below)
  "mods": [],               // the ids a client must have enabled when mod_check is on
  "mod_versions": {},       // id -> version, only consulted by mod_check 2
  "log_level": "info",
  "log_file": "",
  "master": "http://jerichomp.animetiddi.es:8100",  // "" disables registration.
                            // A bare host works too ("jerichomp.animetiddi.es") and
                            // means the master's own port, 8100 -- not 80.
  "master_name": "",
  "advertise_host": "",
  "advertise_port": 0,
  "master_interval_s": 20.0,
  "master_timeout_s": 5.0
}
```

## Chat commands and admins

Players type commands in chat, starting with `!` (or `/`). A command is not shown to
the other players; the reply comes back privately. `!help` lists what *you* can run.

| command | who | what it does |
| --- | --- | --- |
| `!help [command]` | everyone | the commands you can use, or one command's details |
| `!whoami` | everyone | your slot, name and **player id** |
| `!who` | everyone | who is connected (admins also see player ids and addresses) |
| `!login <password>` / `!logout` | everyone | admin for this session, if `admin_password` is set |
| `!kick <slot\|name> [reason]` | admin | remove a player; a reason is shown to them ("Kicked by admin <you>: <reason>"), announced in chat and logged |
| `!cops on\|off`, `!difficulty 0-2` | admin | session rules: apply from the next level load; the discovery listing updates at once |
| `!time dawn\|day\|dusk\|night`, `!weather clear\|rain\|wet` | admin | time of day / weather, from the next level load |
| `!admin add\|remove <slot\|name\|uuid>`, `!admin list` | admin | manage the admins list; **saved to dediserver.json** |
| `!motd [text\|save]` | admin | show or set the join greeting; `!motd save` writes it to the file |
| `!say <text>` | admin | a line from the server to everyone |
| `!vote <city>` / `!vote` / `!vote cancel` | everyone / admin to cancel | vote to switch city (see below) |

`cops`, `difficulty`, `time`, `weather`, `motd` and `admin` also work at the server
console. Every admin command is logged with who ran it. Joins and leaves are
announced in chat (`"announce_joins": false` turns that off). Saving rewrites
`dediserver.json` atomically and keeps your other keys, but not comments or layout.

### Voting for a city

`!vote <city>` starts a vote (or votes yes in the one running). City is `0`-`3` or
`chicago`, `havana`, `vegas`, `rio`. One vote per player id. It passes as soon as
**more than half** the connected players have voted yes, or fails after 30 s; the
next vote can start 60 s after one ends. Admins can `!vote cancel`.

On a pass the city is saved to `dediserver.json`, becomes the session city and the
discovery listing updates. **Everyone is then disconnected with the KICK's rejoin
flag** (the game cannot change level under a running session). Current clients show
"Server changing city - reconnecting...", rejoin the same server by themselves after
~2.5 s (retrying for ~20 s; Esc or joining/hosting anything else cancels), load the
new city and put their previous car back through Change car (cross-city works; if
the car can't be used there they keep the default, and the log says why). Older
clients just see "Kicked by vote: server switched to ... - rejoin" and rejoin by hand.
Plugins can do the same with `kick(player, reason, rejoin=True)`.

Keys: `"vote"` (`false` turns `!vote` off), `"vote_duration"` (seconds, 30),
`"vote_threshold"` (fraction that must be exceeded, 0.5), `"vote_cooldown"` (60).

Session settings in `dediserver.json`: `"time_of_day"` (`dawn`, `day`, `dusk`,
`night`) and `"weather"` (`clear`, `rain`, `wet`), or `--time-of-day` / `--weather`.
Players read them (and the cops rules) as they load a level, so a change reaches a
player the next time they join or load.

### Making yourself an admin

1. Get your player id, a UUID such as `0f8e2a4c-1d3b-4a5e-9c7d-112233445566`. Your
   game creates it at first launch and keeps it in `JERICHO/CONFIG/player.id`.
   Any of these shows it:
   - join any server and type `!whoami`;
   - the game log, line `[mp] player id ...` at launch;
   - `python JERICHO/MODS/mp/tools/player_id.py` in the game folder (or give it the
     path of a `player.id` copied from the player's PC).
2. Put it in `dediserver.json`: `"admins": ["0f8e2a4c-1d3b-4a5e-9c7d-112233445566"]`
   (dashed or plain hex, any case). Restart the server.
3. When you join it says *You are an admin on this server*. From then on you can
   add others in game with `!admin add <name>`.

Or set `"admin_password"` and use `!login <password>` (3 wrong tries in 60 s lock
`!login` for 5 minutes).

**Security:** there is no account server. The player id is a *bearer secret*:
anyone who copies your `CONFIG/player.id` is "you" to this server. Game traffic is not
encrypted, so the id and a `!login` password can be read by anyone on the network
path. The file is obfuscated and checksummed so it can't be casually read or
edited, but the key ships in the game, so that is not real protection. Fine for a hobby server; don't reuse the password anywhere else.

## Plugins

The server is a small core (`dedi/core.py`) plus plugins. Built-ins live in
`dedi/builtin/` (`commands`, `admin`); your own go in `plugins/` beside
`dediserver.py` (or the folder named by `"plugins_dir"`). Updates add files but do
not delete yours (keep your own names; `example_hello.py` is overwritten).

```json
"plugins": null,                 // null = every plugin found, built-ins first
"plugins_disabled": ["example"], // ... minus these
"plugins_dir": "plugins"
```

`"plugins": ["commands", "admin", "mine"]` loads exactly those, in that order. A
plugin that fails to import or raises is logged and disabled; the server keeps
running. The console's `plugins` command shows what loaded and what was disabled.

### Writing one

A plugin is a `.py` file; every hook is optional. `plugins/example_hello.py`
(disabled by default) is a working starting point:

```python
ENABLED_BY_DEFAULT = False      # only load when listed in "plugins"
_server = None

def on_load(server):            # server: dedi.plugins.ServerAPI
    global _server
    _server = server
    server.register_command("hello", lambda caller, args: "hello, %s!" % caller.name)

def on_player_join(player):     # player.id .name .addr .player_id .admin .state
    _server.send_private(player, "Welcome, %s!" % player.name)

def on_chat(player, text):      # return True to swallow the line
    return False
```

Hooks: `on_load(server)`, `on_unload()`, `on_player_join(player)`,
`on_player_leave(player)`, `on_chat(player, text)`, `on_tick()` (about once a
second). `server` offers `players()`, `find_player(slot|name)`,
`send_private(player, text, color)`, `broadcast(text, color)`, `kick(player, reason=None, by="admin", announce=True)` (a reason is shown to the player as "Kicked by <by>: <reason>"),
`config_get/config_set`, `set_rules(cops=, cop_difficulty=, cop_immunity=,
invulnerable=)`, `set_cops`, `set_difficulty`, `readvertise()`, `log`, and
`register_command(name, handler, admin=False, help="", console=False)` where
`handler(caller, args)` returns the reply text. Hooks run on the server's threads:
keep them quick and don't block.

## Mod lists

The client sends its **mod manifest** in the handshake, and this server applies the
same policy the game's own host does:

| `mod_check` | what it does |
| --- | --- |
| `0` (default) | admit anyone. A mismatch is not an error; set the below if it is |
| `1` | the set of **enabled mod ids** must equal `mods` (versions ignored, because the same mod's version differs between a dev and a release build) |
| `2` | as 1, **and** the versions in `mod_versions` must match |

A server that names no `mods` matches everyone, so leaving the check on is harmless.
A client that does not match is refused with `REJECT: MODS` and the text "mod list
does not match the server", which the game shows as a toast — and the refusal is
written so the reason actually arrives (the socket is half-closed before it is
closed; see TESTING.md F3).

**What it does not do:** there is no `modHash` in the registration, so a browser
cannot pre-warn about a mismatch — the check happens at join. The dedi logs what
each client declared (`declares mods: mp 0.1.0, carhacks 1.0.0`) and the verdict
(`modsMatched`), which is what to read when someone says they were refused.

**Text chat** is relayed: a client's `JPCX` line goes to every other client, and
`say <text>` in the console sends one from the server itself (`SERVER: ...`).

## Docker

On a server or VPS, [`../docker-compose.yml`](../docker-compose.yml) runs this and
the master together (`docker compose up -d --build`), with `--port`, `--name`,
`--master` and `--advertise-host` set from the environment. See
[`../README.md`](../README.md#running-it-on-a-server-docker).

## Ports

| Port | Protocol | Direction | Needed for |
| --- | --- | --- | --- |
| `port` (1318) | TCP | **inbound** | the session itself — every client connects here |
| `port` (1318) | UDP | inbound + outbound | the LAN discovery beacon, so the in-game browser lists the server |
| master port (8100) | TCP | **outbound** | only with `--master`: registering for the internet listing |

* **LAN play:** open nothing. The beacon and the session both work on the local
  network as-is.
* **Internet play (direct connect):** forward **TCP 1318** to the server. Add
  **UDP 1318** only if you also want LAN clients on the server's own network to
  find it in the browser; it is not needed for internet clients.
* **Internet listing:** with `--master`, the server makes an outbound TCP
  connection to the master, so no inbound port for that. Players reach it from
  the game's **Multiplayer -> Online** screen, which lists the master's servers
  once `master_url` is set in `mp.ini`.
  * **Behind NAT, set `--advertise-host`** (your public IP or hostname). The
    master records the address it sees the registration come FROM, which behind
    NAT is the server's private address -- the listing would name somewhere no
    player can reach. This does not affect LAN play: the beacon's address is
    taken from the packet, not from the listing.
  * Forward the **session port (TCP)** on the same address. `advertise_host` says
    WHERE to connect. The port in the listing is `--port`, unless the router hands
    out a different public port -- then `--advertise-port` says what players dial.

## Running it for a long time

* **It is self-contained.** No game, no assets, no display. Run it on any machine
  with Python 3.
* **Log to a file.** Set `log_file` (or `--log-file`) so a dropped client is
  still legible in the morning; the file is appended, never truncated.
* **`--idle-drop 0`** if you would rather never drop a quiet client than drop a
  client that is merely paused or loading. The default (30 s) matches the game's
  own idle timeout.
* **Restart on crash** with whatever your platform offers (a service unit, a
  `while true` loop, Task Scheduler). It is stateless: a restart is just a fresh
  session. If it registered with a master, it re-registers on start.
* **A clean stop unregisters.** `Ctrl-C`, `SIGTERM` or Windows `Ctrl-Break` closes
  the sockets and removes the server from the master's listing at once, instead of
  leaving it to lapse.

## Reading the log

Every line is timestamped and levelled. The ones that matter:

```
[INFO] listening on TCP/1318 (city 0, up to 8 players); Ctrl-C to stop
[INFO] player 1 'Bob' joined from 192.168.1.44:53120 (mods=2, build 0x74cc)
[INFO] player 1 'Bob' left (0/8)
[WARNING] player 1 'Bob' timed out (30s silent)
[WARNING] refused 192.168.1.44:53122: server is full (8/8)
[INFO] registered with master http://master.example.com:8100 as 203.0.113.5:1318
[WARNING] master ... unreachable (...); retrying in 4s
```

A client that **never** appears has a transport problem (firewall, wrong address).
A client that joins and then leaves on its own has a client-side problem. That
distinction is the whole point of logging joins and leaves.

## Liveness

The server answers a client's `PING` with a `PONG` echoing the tick, and pings on
its own timer so a quiet client is never given up just for being quiet. A client
that gets nothing after the handshake drops itself at its idle timeout; the server
does the same after `idle_drop_s`.

## Testing

`../rigs/test_e2e.py` starts this server and the master together on loopback and
checks registration, heartbeat, a client handshake, re-registration after a
master restart, and unregister-on-shutdown — no game, no assets:

```sh
python JERICHO/MODS/mp/tools/servers/rigs/test_e2e.py
```
