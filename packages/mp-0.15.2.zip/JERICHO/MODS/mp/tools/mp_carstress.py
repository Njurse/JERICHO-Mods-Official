"""Car-path stress test: every seat cycles through every car, flat out.

    python tools/mp_carstress.py                       # 3 seats, 60 s, a change every 700 ms
    python tools/mp_carstress.py --seconds 30           # quick
    python tools/mp_carstress.py --players 2 --interval-ms 250

One host plus N-1 clients on THIS machine, each walking the whole list of cars the session
can offer in its OWN random order, as fast as asked. Three seats at 700 ms is a car change
somewhere in the session every ~230 ms - far past anything a player does - which is where
slot reuse, the palette rows, the texture pages and the peer folds either hold or start to
leak, go invisible, or refuse.

It uses mp_localpair.py for the session and MP_TEST_CARCYCLE for the driving, so the changes
go through the same call the pause menu's Apply row makes. The list is the session's own
(MpCarListForCity), not a guess at model numbers.

The LEVEL is rolled per run (chicago / havana / vegas / rio). This rig used to inherit
mp_localpair's `rio` default, so it only ever exercised rio's hot-load path - and those
symptoms are level-specific (which resident slots a level holds, what it streams, which cars
its list offers), so a run on one level says nothing about another. The roll and its seed are
printed: `SEED=<n>` replays it, `--level <city>` pins it.

What it reports, per seat: how many cars it actually drove, how many DISTINCT ones (the
coverage claim - "every car" is only true if this reaches the whole list), how many passes it
finished, and every sign of trouble:

  MISSING ....... a car whose mesh is not built: the invisible car, named
  no spare ...... the session ran out of resident slots
  not loaded .... a peer's car this machine could not hold
  keeping slot .. a car drawn from another car's slot
  refused ....... a change the session said no to

Exit code is 0 only when every seat cycled its whole list with none of the above.
"""

import argparse
import collections
import os
import random
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PAIR = os.path.join(HERE, "mp_localpair.py")

SEATS = ["host", "client", "client1", "client2", "client3", "client4", "client5", "client6"]

# The mp levels a pair can boot into (mp_localpair's --level). Rolled per run: the
# hot-load path's symptoms differ by level, so a rig pinned to one level only ever
# finds that level's.
LEVELS = ("chicago", "havana", "vegas", "rio")

TROUBLE = (
    ("MISSING", re.compile(r"MISSING")),
    ("not loaded", re.compile(r"is not loaded here")),
    ("keeping slot", re.compile(r"keeping slot \d+")),
    ("refused", re.compile(r"could not be built|cannot load the car", re.I)),
)

# Not trouble: work the session did on purpose. A pick that could not fit is remembered and
# retried (MP_DEFER_*), and at a stress cadence most of them are superseded before a slot
# frees - that is the mechanism working, and the numbers say whether it keeps up.
# "retried" is the carhacks fold's own retry (a peer's car whose slot is busy, or whose
# hot-load did not fit yet): it heals on a later beat, so a first refusal is not trouble.
HANDLED = (
    ("no room", re.compile(r"no spare resident slot")),
    ("retried", re.compile(r"is busy right now - retrying|could not build it yet - retrying")),
    ("waited", re.compile(r"is waiting for a free slot")),
    ("landed", re.compile(r"a slot freed up after")),
    ("gave up", re.compile(r"gave up on a resident slot")),
)

CHANGE = re.compile(r"\[mp\] change car: we asked for (\w+) model (\d+)")
STATUS = re.compile(r"car status: driving model (\d+) \(resident (-?\d+), source (\w+)\)")
PASS = re.compile(r"car cycle PASS (\d+) done")
STARTED = re.compile(r"car cycle: (\d+) car\(s\), a change every (\d+) ms")
VERDICT = re.compile(r"\[pair\] verdict: (.*)")


def read(path):
    if not os.path.exists(path):
        return ""

    with open(path, "rb") as f:
        return f.read().decode("utf-8", "replace")


def summarise(text):
    """Everything one seat's log says about the cycling."""
    cars = set()
    missing = []

    for m in STATUS.finditer(text):
        # (source city, model) is the car's identity; the source is the CITY it came from.
        cars.add((m.group(3), int(m.group(1))))

        if "MISSING" in text[m.start():text.find("\n", m.start())]:
            missing.append(m.group(0))

    passes = [int(x) for x in PASS.findall(text)]
    started = STARTED.search(text)
    trouble = []
    handled = []

    for label, rx in TROUBLE:
        hits = len(rx.findall(text))

        if hits:
            trouble.append((label, hits))

    for label, rx in HANDLED:
        hits = len(rx.findall(text))

        if hits:
            handled.append((label, hits))

    return {
        "changes": len(CHANGE.findall(text)),
        "distinct": len(cars),
        "passes": len(passes),
        "offered": int(started.group(1)) if started else None,
        "trouble": trouble,
        "handled": handled,
        "missing": missing,
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--players", type=int, default=3, help="one host plus this many - 1 (default 3)")
    ap.add_argument("--seconds", type=int, default=60)
    ap.add_argument("--interval-ms", type=int, default=1000,
                    help="how often each seat changes car (default 1000ms, ~3/s across three "
                         "seats -- hot-loading faster than this makes the game crawl and no "
                         "player changes that fast anyway)")
    ap.add_argument("--game-dir", default=os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(HERE)))),
        "src_rebuild", "bin", "Release_dev"))
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--bot", default="off", help="leave it off: a parked car is a still picture")
    ap.add_argument("--level", default=None, choices=LEVELS,
                    help="the mp level to run on. Default: a RANDOM one, because the hot-load "
                         "path's symptoms differ by level and a rig pinned to one only ever "
                         "finds that level's. The roll and its seed are printed")
    ap.add_argument("--seed", type=int, default=None,
                    help="pin the level roll (default: the SEED environment variable, else a "
                         "fresh roll). Printed either way, so any run can be replayed")
    a = ap.parse_args()

    if not os.path.exists(PAIR):
        print("cannot find %s" % PAIR)
        return 2

    # Roll the level (or honour --level / SEED=). Seeded means deterministic, and the seed is
    # printed either way, so a pasted-back SEED is worth something.
    seed = a.seed
    if seed is None:
        env = (os.environ.get("SEED") or "").strip()
        seed = int(env) if env.lstrip("-").isdigit() else None
    if seed is None:
        seed = random.randrange(1, 1 << 30)

    rng = random.Random(seed)
    rolled = a.level is None
    level = a.level if a.level is not None else rng.choice(LEVELS)

    seats = SEATS[:a.players]
    cmd = [sys.executable, PAIR,
           "--game-dir", a.game_dir,
           "--players", str(a.players),
           "--seconds", str(a.seconds),
           "--level", level,
           "--bot", a.bot]

    for s in seats:
        cmd += ["--seat-env", "%s=MP_TEST_CARCYCLE=%d" % (s, a.interval_ms)]

    # --keep IS NOT OPTIONAL HERE. This rig summarises the seat logs AFTER the pair has
    # exited, and mp_localpair deletes its run dirs on the way out unless --keep is given.
    # Without this the summary reads directories that no longer exist: every seat prints
    # `offered ?`, 0 changes and no trouble, and the rig concludes NOTHING CYCLED however
    # well the session actually drove the whole roster. The rig's own --keep still decides
    # whether the logs are LEFT BEHIND afterwards (see the end of main).
    cmd.append("--keep")

    print("stress: %d seat(s) on %s, a change every %d ms each (~%d ms somewhere in the session)"
          % (a.players, level, a.interval_ms, max(1, a.interval_ms // a.players)))
    print("        level %s (%s, seed %d - SEED=%d replays this run)"
          % (level, "rolled" if rolled else "pinned with --level", seed, seed))
    print("        " + " ".join(cmd))
    print()
    cmd.append("--vramview")
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    verdict = VERDICT.search(out)

    # The rig writes a/b/c...; the seat names are in the same order.
    run_root = os.path.join(a.game_dir, ".mp-pair")
    names = ["a", "b", "c", "d", "e", "f", "g", "h"]

    print("%-8s %8s %9s %7s %9s  %s" % ("seat", "changes", "distinct", "passes", "offered", "handled / trouble"))
    print("-" * 92)

    totals = collections.Counter()
    bad = 0
    coverage = []

    for s, d in zip(seats, names):
        info = summarise(read(os.path.join(run_root, d, "JERICHO.log")))
        handed = ", ".join("%s x%d" % t for t in info["handled"]) or "-"
        trouble = ", ".join("%s x%d" % t for t in info["trouble"]) or "-"

        print("%-8s %8d %9d %7d %9s  %s%s" % (
            s, info["changes"], info["distinct"], info["passes"],
            info["offered"] if info["offered"] is not None else "?",
            handed, (" | " + trouble) if trouble else ""))

        totals["changes"] += info["changes"]
        totals["distinct"] = max(totals["distinct"], info["distinct"])

        if info["offered"] is not None:
            coverage.append((s, info["distinct"], info["offered"]))

        if info["trouble"] or info["missing"]:
            bad += 1

    print()
    print("%d car change(s) in %ds = %.1f/s somewhere in the session"
          % (totals["changes"], a.seconds, totals["changes"] / max(1, a.seconds)))
    # Repeated here so the roll travels with the verdict: a caller that keeps only the tail of
    # this output (run_gate.py keeps 12 lines) would otherwise lose which level ran.
    print("level %s (%s) - SEED=%d replays this run"
          % (level, "rolled" if rolled else "pinned with --level", seed))

    # A run that cycled NOTHING is not a pass. This rig's whole job is to cycle cars,
    # and with zero changes the per-seat lines are vacuous -- measured: a 40 s run
    # reported "every seat cycled its whole list" having changed no car at all, because
    # the lever never fired. That is how a run which exercised nothing reads as clean,
    # which is the same failure this rig exists to catch in the game.
    if totals["changes"] == 0:
        print("\nRESULT: NOTHING CYCLED - 0 car changes in %ds. The rig exercised nothing, "
              "so its clean lines mean nothing either. Give it more seconds (the level load "
              "comes first) rather than reading this as a pass." % a.seconds)
        return 1

    if coverage:
        for s, got, want in coverage:
            if got < want:
                print("!! %s drove %d of the %d car(s) on offer - the list did not get covered"
                      % (s, got, want))
                bad += 1
            else:
                print("   %s drove every one of its %d car(s)" % (s, want))

    if verdict:
        print("pair verdict: %s" % verdict.group(1))

    if bad:
        print("\nRESULT: trouble above - read the seat logs in %s" % run_root)
        return 1

    print("\nRESULT: every seat cycled its whole list, no trouble in any seat's log")
    return 0


if __name__ == "__main__":
    sys.exit(main())
